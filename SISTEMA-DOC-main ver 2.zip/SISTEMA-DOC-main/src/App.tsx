/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Building, 
  Menu, 
  X, 
  User, 
  PlusCircle, 
  FileText, 
  LayoutDashboard,
  ShieldAlert,
  Coins,
  HardHat,
  ChevronDown,
  PenTool
} from 'lucide-react';

import { Document, DEPARTMENTS, DocumentStatus, AppUser } from './types';
import { INITIAL_DOCUMENTS } from './sampleData';
import { TODAY_DATE, formatDate, getLiveStatus } from './utils';

import Sidebar from './components/Sidebar';
import DashboardStats from './components/DashboardStats';
import DocumentForm from './components/DocumentForm';
import DocumentList from './components/DocumentList';
import DocumentDetail from './components/DocumentDetail';
import Login from './components/Login';
import MasterConsole from './components/MasterConsole';
import DigitalSignatureTab from './components/DigitalSignatureTab';
import LoadingScreen from './components/LoadingScreen';

export default function App() {
  // Municipalities management state
  const [municipalities, setMunicipalities] = useState<string[]>(() => {
    const cached = localStorage.getItem('1doc_registered_municipalities_v2');
    if (cached) {
      try {
        return JSON.parse(cached);
      } catch (e) {
        console.error(e);
      }
    }
    return ['Cutias', 'Macapá', 'Santana', 'Itaubal'];
  });

  const [currentMunicipality, setCurrentMunicipality] = useState<string>(() => {
    return localStorage.getItem('1doc_current_municipality_v2') || 'Cutias';
  });

  const [isMunicipalityChosen, setIsMunicipalityChosen] = useState<boolean>(() => {
    return sessionStorage.getItem('1doc_master_municipality_chosen') === 'true';
  });

  // Database / LocalStorage sync state
  const [documents, setDocuments] = useState<Document[]>(() => {
    const cached = localStorage.getItem('1doc_cutias_documents_v1');
    if (cached) {
      try {
        return JSON.parse(cached);
      } catch (err) {
        console.error('Failed to parse cached draft', err);
      }
    }
    return INITIAL_DOCUMENTS;
  });

  // Navigation states
  const [currentTab, setCurrentTab] = useState<'dashboard' | 'enviar' | 'documentos' | 'master' | 'assinatura'>('dashboard');
  const [selectedDocId, setSelectedDocId] = useState<string | null>(null);

  // Transition expectations state
  const [transitioning, setTransitioning] = useState<boolean>(false);
  const [transitionMessage, setTransitionMessage] = useState<string>('');
  const [transitionCallback, setTransitionCallback] = useState<(() => void) | null>(null);

  const startTransition = (callback: () => void, message?: string) => {
    setTransitionMessage(message || '');
    setTransitionCallback(() => callback);
    setTransitioning(true);
  };

  const navigateToTab = (tab: 'dashboard' | 'enviar' | 'documentos' | 'master' | 'assinatura') => {
    startTransition(() => {
      setCurrentTab(tab);
      setSelectedDocId(null);
      setMobileMenuOpen(false);
    }, `Acessando painel de ${tab === 'dashboard' ? 'Monitoramento de Gestão' : tab === 'enviar' ? 'Envio de Processos' : tab === 'documentos' ? 'Repositório de Documentos' : tab === 'master' ? 'Console Master de TI' : 'Assinaturas Digitais'}...`);
  };

  // Filter shortcuts
  const [activeListFilter, setActiveListFilter] = useState<DocumentStatus | 'All'>('All');

  // Authenticated user state
  const [currentUser, setCurrentUser] = useState<AppUser | null>(() => {
    const cachedUser = localStorage.getItem('1doc_cutias_logged_user_v1');
    if (cachedUser) {
      try {
        return JSON.parse(cachedUser);
      } catch (err) {
        console.error('Failed to parse cached user', err);
      }
    }
    return null;
  });

  // Registered custom users
  const [registeredUsers, setRegisteredUsers] = useState<AppUser[]>(() => {
    const cachedReg = localStorage.getItem('1doc_registered_users_v1');
    if (cachedReg) {
      try {
        return JSON.parse(cachedReg);
      } catch (err) {
        console.error('Failed to parse registered users', err);
      }
    }
    return [];
  });

  // Non-Interference Filter states
  const [onlyMyDepartment, setOnlyMyDepartment] = useState<boolean>(true);
  const [selectedDept, setSelectedDept] = useState<string>('all');

  // Suspended municipalities state
  const [suspendedMunicipalities, setSuspendedMunicipalities] = useState<string[]>(() => {
    const cached = localStorage.getItem('1doc_suspended_municipalities_v2');
    if (cached) {
      try {
        return JSON.parse(cached);
      } catch (e) {
        console.error(e);
      }
    }
    return [];
  });

  // Mobile navigation drawer toggle
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Sync current user to local cache
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('1doc_cutias_logged_user_v1', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('1doc_cutias_logged_user_v1');
    }
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('1doc_registered_municipalities_v2', JSON.stringify(municipalities));
  }, [municipalities]);

  useEffect(() => {
    localStorage.setItem('1doc_current_municipality_v2', currentMunicipality);
  }, [currentMunicipality]);

  useEffect(() => {
    sessionStorage.setItem('1doc_master_municipality_chosen', isMunicipalityChosen ? 'true' : 'false');
  }, [isMunicipalityChosen]);

  useEffect(() => {
    localStorage.setItem('1doc_suspended_municipalities_v2', JSON.stringify(suspendedMunicipalities));
  }, [suspendedMunicipalities]);

  // Handle registration
  const handleRegisterUser = (newUser: AppUser) => {
    setRegisteredUsers((prev) => {
      const updated = [...prev, newUser];
      localStorage.setItem('1doc_registered_users_v1', JSON.stringify(updated));
      return updated;
    });
  };

  const handleSuspendMunicipality = (name: string) => {
    setSuspendedMunicipalities((prev) => {
      if (prev.includes(name)) return prev;
      return [...prev, name];
    });
  };

  const handleReactivateMunicipality = (name: string) => {
    setSuspendedMunicipalities((prev) => prev.filter((m) => m !== name));
  };

  const handleAddStaffMember = (newUser: AppUser) => {
    handleRegisterUser(newUser);
  };

  const handleDeleteStaffMember = (id: string) => {
    setRegisteredUsers((prev) => {
      const updated = prev.filter((u) => u.id !== id);
      localStorage.setItem('1doc_registered_users_v1', JSON.stringify(updated));
      return updated;
    });
  };

  // Handle logout
  const handleLogout = () => {
    startTransition(() => {
      setCurrentUser(null);
      setSelectedDocId(null);
      setOnlyMyDepartment(true);
      setCurrentTab('dashboard');
      setIsMunicipalityChosen(false);
      setCurrentMunicipality('Cutias');
    }, 'Processando encerramento de sessão segura de servidor...');
  };

  // Save documents modifications back to Cache
  useEffect(() => {
    localStorage.setItem('1doc_cutias_documents_v1', JSON.stringify(documents));
  }, [documents]);

  // Dynamic visible documents filtered by department and privacy rules (without interference)
  const visibleDocuments = documents.filter((doc) => {
    if (!currentUser) return false;
    
    // Check municipality matching (defaults to Cutias to remain backward compatible)
    const docMunicipality = doc.municipality || 'Cutias';
    const activeMunicInput = currentMunicipality || 'Cutias';
    if (docMunicipality.toLowerCase() !== activeMunicInput.toLowerCase()) {
      return false;
    }
    
    // If onlyMyDepartment is ON, filter documents where user's department is the origin OR destination
    if (onlyMyDepartment) {
      const userDeptLow = currentUser.department.toLowerCase();
      const originLow = doc.origin.toLowerCase();
      const destLow = doc.destination.toLowerCase();
      return originLow.includes(userDeptLow) || 
             userDeptLow.includes(originLow) || 
             destLow.includes(userDeptLow) || 
             userDeptLow.includes(destLow);
    }
    
    return true;
  });

  const handleAddDocument = (newDoc: Document) => {
    const docWithMunicipality = {
      ...newDoc,
      municipality: currentMunicipality
    };
    setDocuments((prev) => [docWithMunicipality, ...prev]);
    // Redirect context
    setActiveListFilter('All');
  };

  const handleUpdateDocument = (updatedDoc: Document) => {
    setDocuments((prev) => prev.map((d) => (d.id === updatedDoc.id ? updatedDoc : d)));
  };

  const handleDeleteDocument = (id: string) => {
    setDocuments((prev) => prev.filter((d) => d.id !== id));
    if (selectedDocId === id) {
      setSelectedDocId(null);
    }
  };

  const handleResetDatabase = () => {
    setDocuments(INITIAL_DOCUMENTS);
    localStorage.setItem('1doc_cutias_documents_v1', JSON.stringify(INITIAL_DOCUMENTS));
    setSelectedDocId(null);
  };

  // Switch to detail view of a single document
  const handleViewDoc = (id: string) => {
    startTransition(() => {
      setSelectedDocId(id);
      setMobileMenuOpen(false);
    }, 'Inspecionando dados regimentais do documento e histórico de despachos...');
  };

  // Interactive dashboard cards filters shortcuts handler
  const handleQuickStatusFilter = (status: DocumentStatus | 'All') => {
    startTransition(() => {
      setActiveListFilter(status);
      setCurrentTab('documentos');
      setSelectedDocId(null);
    }, `Buscando e indexando trâmites com status ${status === 'All' ? 'Geral' : status}...`);
  };

  // Find currently active document for Detail View
  const selectedDoc = documents.find((doc) => doc.id === selectedDocId);

  // Dynamic label for topbar title
  const getTabTitle = () => {
    if (selectedDocId) return 'Visualizador de Trâmite Oficial';
    if (currentTab === 'dashboard') return `Monitor de Gestor de ${currentMunicipality}`;
    if (currentTab === 'enviar') return 'Instaurar Novo Processo / Trâmite';
    if (currentTab === 'documentos') return 'Repositório de Documentos';
    return 'DOC';
  };

  // Session authentication guard
  if (!currentUser) {
    return (
      <div className="relative">
        {transitioning && (
          <LoadingScreen
            message={transitionMessage}
            onFinished={() => {
              if (transitionCallback) {
                transitionCallback();
                setTransitionCallback(null);
              }
              setTransitioning(false);
            }}
          />
        )}
        <Login
          onLoginSuccess={(user) => {
            startTransition(() => {
              setCurrentUser(user);
            }, `Efetuando login seguro. Inicializando painel de servidor de ${user.municipality}...`);
          }}
          registeredUsers={registeredUsers}
          onRegisterUser={handleRegisterUser}
          municipalities={municipalities}
          suspendedMunicipalities={suspendedMunicipalities}
        />
      </div>
    );
  }


  return (
    <div className="min-h-screen bg-slate-50 flex text-slate-900 font-sans selection:bg-emerald-200 font-sans">
      
      {transitioning && (
        <LoadingScreen
          message={transitionMessage}
          onFinished={() => {
            if (transitionCallback) {
              transitionCallback();
              setTransitionCallback(null);
            }
            setTransitioning(false);
          }}
        />
      )}
      
      {/* Lateral Navigation Sidebar */}
      <Sidebar
        currentTab={currentTab}
        setCurrentTab={(tab) => {
          navigateToTab(tab);
        }}
        currentUser={currentUser}
        onlyMyDepartment={onlyMyDepartment}
        setOnlyMyDepartment={setOnlyMyDepartment}
        onLogout={handleLogout}
        selectedDept={selectedDept}
        setSelectedDept={setSelectedDept}
        allDepts={DEPARTMENTS}
        currentMunicipality={currentMunicipality}
      />

      {/* Main Content Layout Block */}
      <div className="flex-1 flex flex-col min-h-screen">
        
        {/* Top Header branding ribbon with responsive support */}
        <header className="sticky top-0 z-40 bg-white border-b border-slate-300 py-2 px-5 flex items-center justify-between shadow-xs">
          
          <div className="flex items-center gap-2">
            {/* Mobile toggles */}
            <button
              id="mobile-nav-toggle"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-1 hover:bg-slate-100 rounded md:hidden text-slate-700"
              title="Menu Lateral"
            >
              <Menu className="w-5 h-5" />
            </button>

            <div>
              {currentUser.role === 'master' ? (
                <div className="flex items-center gap-1.5 mb-0.5">
                  <span className="text-[9px] text-amber-700 font-extrabold uppercase tracking-widest hidden sm:inline-block">Auditar Cidade:</span>
                  <select
                    value={currentMunicipality}
                    onChange={(e) => {
                      const selected = e.target.value;
                      if (suspendedMunicipalities.includes(selected)) {
                        alert(`O município de ${selected} encontra-se SUSPENSO. Reative-o no Console Master para liberar o acesso.`);
                        return;
                      }
                      setCurrentMunicipality(selected);
                    }}
                    className="bg-amber-50 border border-amber-300 text-[#003366] text-[10px] font-black uppercase rounded px-1.5 py-0.5 focus:outline-none cursor-pointer"
                  >
                    {municipalities.map((mun) => (
                      <option key={`header-mun-${mun}`} value={mun}>
                        📍 {mun} {suspendedMunicipalities.includes(mun) ? '(SUSPENSO)' : ''}
                      </option>
                    ))}
                  </select>
                </div>
              ) : (
                <p className="text-[9px] text-[#003366] font-extrabold uppercase tracking-widest hidden sm:block">Prefeitura Municipal de {currentMunicipality} (AP)</p>
              )}
              <h2 className="font-sans font-extrabold text-[#003366] text-xs sm:text-sm uppercase tracking-wide">
                {getTabTitle()}
              </h2>
            </div>
          </div>

          {/* Quick Context actions and clocks */}
          <div className="flex items-center gap-3">
            
            {/* Live Indicator of Date */}
            <div className="hidden lg:flex flex-col items-end text-neutral-500 line-height-tight">
              <span className="text-[8px] uppercase font-bold tracking-wider text-slate-400">Data e Hora Oficial</span>
              <span className="text-[11px] font-mono font-bold text-slate-700">{formatDate(TODAY_DATE)}</span>
            </div>

            {/* Authenticated user profile badge */}
            <div className="flex items-center gap-2 border-l border-slate-300 pl-3">
              <div className="w-7 h-7 rounded bg-blue-50 border border-blue-250 flex items-center justify-center text-[#003366] font-extrabold text-xs shrink-0 font-mono">
                {currentUser.role === 'master' ? 'M' : currentUser.role === 'gestor' ? 'G' : 'S'}
              </div>
              <div className="hidden sm:block text-left max-w-[140px]">
                <p className="text-[11px] font-bold text-slate-800 leading-none truncate">
                  {currentUser.name}
                </p>
                <p className="text-[8px] text-slate-450 font-semibold leading-none mt-0.5 truncate uppercase">
                  {currentUser.role === 'master' ? 'Master Auditor' : currentUser.role === 'gestor' ? 'Gestor' : 'Servidor'} • {currentUser?.department.split('(')[1]?.replace(')', '') || currentUser?.department}
                </p>
              </div>
              <button
                id="header-logout-btn"
                onClick={handleLogout}
                className="bg-red-50 hover:bg-red-100 text-red-650 border border-red-200 px-2 py-0.5 rounded text-[9px] font-bold uppercase transition-all shadow-2xs shrink-0 cursor-pointer"
                title="Sair do Sistema"
              >
                Sair
              </button>
            </div>

          </div>

        </header>

        {/* Mobile menu navigation drawer dialog */}
        {mobileMenuOpen && (
          <div id="mobile-menu" className="fixed inset-0 bg-slate-950/40 backdrop-blur-xs z-50 md:hidden animate-fade-in">
            <div className="w-72 bg-slate-900 h-full p-5 space-y-6 flex flex-col justify-between text-slate-100">
              
              <div>
                <div className="flex justify-between items-center pb-4 border-b border-slate-800 mb-4">
                  <span className="font-bold text-white text-base">DOC Cutias Navigation</span>
                  <button 
                    onClick={() => setMobileMenuOpen(false)}
                    className="p-1.5 hover:bg-slate-850 rounded-lg text-slate-400"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <nav className="space-y-2">
                  <button
                    onClick={() => navigateToTab('dashboard')}
                    className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-bold transition-colors ${
                      currentTab === 'dashboard' && !selectedDocId ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:bg-slate-800'
                    }`}
                  >
                    <LayoutDashboard className="w-4 h-4" />
                    <span>Painel Monitor de Gestor</span>
                  </button>

                  <button
                    onClick={() => navigateToTab('documentos')}
                    className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-bold transition-colors ${
                      currentTab === 'documentos' && !selectedDocId ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:bg-slate-800'
                    }`}
                  >
                    <FileText className="w-4 h-4" />
                    <span>Repositório de Documentos</span>
                  </button>

                  <button
                    onClick={() => navigateToTab('enviar')}
                    className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-bold transition-colors ${
                      currentTab === 'enviar' && !selectedDocId ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:bg-slate-800'
                    }`}
                  >
                    <PlusCircle className="w-4 h-4" />
                    <span>Iniciar Novo Envio</span>
                  </button>

                  <button
                    onClick={() => navigateToTab('assinatura')}
                    className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-bold transition-colors ${
                      currentTab === 'assinatura' && !selectedDocId ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:bg-slate-800'
                    }`}
                  >
                    <PenTool className="w-4 h-4 text-emerald-400" />
                    <span>Assinar Documentos</span>
                  </button>

                  {currentUser.role === 'master' && (
                    <button
                      onClick={() => navigateToTab('master')}
                      className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-bold transition-colors ${
                        currentTab === 'master' && !selectedDocId ? 'bg-amber-600 text-white' : 'text-amber-500 hover:bg-slate-800'
                      }`}
                    >
                      <ShieldAlert className="w-4 h-4 text-amber-500 shrink-0" />
                      <span>Console Master TI</span>
                    </button>
                  )}
                </nav>
              </div>

              {/* Mobile active profile user badge */}
              <div className="p-4 bg-slate-950/40 rounded border border-slate-800 space-y-2">
                <span className="text-[9px] uppercase font-bold text-slate-400 block tracking-widest font-mono">Usuário Conectado</span>
                <p className="text-xs font-bold text-white truncate">{currentUser.name}</p>
                <p className="text-[10px] text-blue-300 truncate font-semibold uppercase">
                  {currentUser.role === 'gestor' ? 'Gestor' : 'Servidor'} • {currentUser.department.split('(')[1]?.replace(')', '') || currentUser.department}
                </p>
                <button
                  onClick={() => {
                    handleLogout();
                    setMobileMenuOpen(false);
                  }}
                  className="w-full bg-red-900/50 hover:bg-red-800 text-red-205 border border-red-700 font-bold py-1 px-2 rounded text-[10px] uppercase transition-all tracking-wide cursor-pointer text-center"
                >
                  Sair do DOC
                </button>
              </div>

            </div>
          </div>
        )}

        {/* Dynamic Inner Tab Router Panel */}
        <main className="flex-1 p-5 md:p-8 overflow-y-auto max-w-7xl w-full mx-auto">
          
          {selectedDocId && selectedDoc ? (
            <DocumentDetail
              document={selectedDoc}
              onBack={() => setSelectedDocId(null)}
              onUpdateDocument={handleUpdateDocument}
              currentUser={currentUser}
            />
          ) : (
            <>
              {currentTab === 'dashboard' && (
                <div className="space-y-4">
                  {/* Top quick tip */}
                  <div className="bg-[#003366] text-white p-4 rounded border border-blue-900 shadow-sm text-left flex flex-col md:flex-row md:items-center justify-between gap-3">
                    <div className="space-y-0.5">
                      <p className="text-[9px] text-blue-200 font-extrabold uppercase tracking-wide">Gestão Desburocratizada de {currentMunicipality}-AP</p>
                      <h3 className="font-sans font-extrabold text-sm sm:text-base uppercase tracking-tight">
                        Monitor de Atendimento de Ofícios e Processos Internos
                      </h3>
                      <p className="text-[10px] text-blue-100 max-w-3xl leading-snug">
                        Mecanismo de monitoramento regimental de prazos e fluxo de despachos eletrônicos. Utilize os cartões de status abaixo para filtrar instantaneamente.
                      </p>
                    </div>

                    <div className="flex gap-2">
                      <button
                        id="quick-start-tramite"
                        onClick={() => navigateToTab('enviar')}
                        className="bg-white hover:bg-slate-100 text-[#003366] font-extrabold py-1.5 px-3 rounded text-[10px] transition-all shrink-0 uppercase tracking-tight shadow-sm cursor-pointer"
                      >
                        🚀 Novo Trâmite
                      </button>
                    </div>
                  </div>

                  {/* Core Statistics counters */}
                  <DashboardStats
                    documents={visibleDocuments}
                    selectedDept={selectedDept}
                    onFilterClick={handleQuickStatusFilter}
                    onViewDoc={handleViewDoc}
                    currentMunicipality={currentMunicipality}
                  />
                </div>
              )}

              {currentTab === 'enviar' && (
                <DocumentForm
                  onAddDocument={handleAddDocument}
                  currentUser={currentUser}
                />
              )}

              {currentTab === 'documentos' && (
                <div className="space-y-3">
                  <div className="flex justify-between items-center flex-wrap gap-2 pb-1.5 border-b border-slate-300">
                    <div>
                      <h2 className="text-xs font-bold text-slate-900 uppercase tracking-tight flex items-center gap-1">
                        <FileText className="w-3.5 h-3.5 text-[#003366]" />
                        Repositório de Consulta DOC
                      </h2>
                      <p className="text-[9px] text-slate-500">Localização e busca de relatórios ou ofícios oficiais em trâmite.</p>
                    </div>

                    {activeListFilter !== 'All' && (
                      <button
                        id="clear-list-filter"
                        onClick={() => setActiveListFilter('All')}
                        className="text-[10px] text-red-700 bg-red-50 border border-red-300 hover:bg-red-100 font-bold px-2 py-0.5 rounded cursor-pointer uppercase"
                      >
                        Limpar Filtro ({activeListFilter})
                      </button>
                    )}
                  </div>

                  <DocumentList
                    documents={visibleDocuments}
                    selectedDept={selectedDept}
                    onViewDoc={handleViewDoc}
                    initialFilterStatus={activeListFilter}
                  />
                </div>
              )}

              {currentTab === 'master' && (
                <MasterConsole
                  documents={documents}
                  onUpdateDocument={handleUpdateDocument}
                  onDeleteDocument={handleDeleteDocument}
                  onResetDatabase={handleResetDatabase}
                  currentUser={currentUser}
                  municipalities={municipalities}
                  currentMunicipality={currentMunicipality}
                  onAddMunicipality={(name) => {
                    setMunicipalities((prev) => {
                      const trimmed = name.trim();
                      if (prev.some(p => p.toLowerCase() === trimmed.toLowerCase())) return prev;
                      return [...prev, trimmed];
                    });
                  }}
                  onSelectMunicipality={(name) => {
                    setCurrentMunicipality(name);
                  }}
                  suspendedMunicipalities={suspendedMunicipalities}
                  onSuspendMunicipality={handleSuspendMunicipality}
                  onReactivateMunicipality={handleReactivateMunicipality}
                  registeredUsers={registeredUsers}
                  onAddStaffMember={handleAddStaffMember}
                  onDeleteStaffMember={handleDeleteStaffMember}
                  onBulkUpdateDocuments={(allDocs) => setDocuments(allDocs)}
                  onBulkUpdateUsers={(allUsers) => setRegisteredUsers(allUsers)}
                />
              )}

              {currentTab === 'assinatura' && (
                <DigitalSignatureTab
                  documents={documents}
                  onUpdateDocument={handleUpdateDocument}
                  currentUser={currentUser}
                />
              )}
            </>
          )}

        </main>

        {/* Global Footer info bar */}
        <footer className="bg-white border-t border-slate-300 py-3 px-5 text-center text-[10px] text-slate-500 font-semibold uppercase tracking-wider">
          <p>© 2026 Prefeitura Municipal de {currentMunicipality} (AP). Secretaria Administrativa Geral — Integração Eletrônica DOC.</p>
        </footer>

      </div>

    </div>
  );
}
