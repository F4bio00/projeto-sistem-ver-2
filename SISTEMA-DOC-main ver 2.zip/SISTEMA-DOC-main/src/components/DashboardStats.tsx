/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  FileText, 
  Clock, 
  AlertTriangle, 
  CheckCircle, 
  FileCheck,
  CalendarDays,
  ArrowRight
} from 'lucide-react';
import { Document, DocumentStatus } from '../types';
import { getRemainingDays, getLiveStatus, formatDate } from '../utils';

interface DashboardStatsProps {
  documents: Document[];
  selectedDept: string;
  onFilterClick: (status: DocumentStatus | 'All') => void;
  onViewDoc: (id: string) => void;
  currentMunicipality?: string;
}

export default function DashboardStats({
  documents,
  selectedDept,
  onFilterClick,
  onViewDoc,
  currentMunicipality = 'Cutias'
}: DashboardStatsProps) {
  // Filter documents based on active department if not 'all'
  const filteredDocs = selectedDept === 'all' 
    ? documents 
    : documents.filter(doc => doc.destination.includes(selectedDept) || doc.origin.includes(selectedDept));

  // Compute live statuses
  const stats = filteredDocs.reduce((acc, doc) => {
    const liveStatus = getLiveStatus(doc);
    acc.total += 1;
    if (liveStatus === 'Pendente') acc.pending += 1;
    if (liveStatus === 'Em Análise') acc.inAnalysis += 1;
    if (liveStatus === 'Atrasado') acc.delayed += 1;
    if (liveStatus === 'Concluído') acc.completed += 1;
    return acc;
  }, { total: 0, pending: 0, inAnalysis: 0, delayed: 0, completed: 0 });

  // Filter out those critical documents that need immediate attention
  const criticalDocuments = filteredDocs
    .filter(doc => {
      const liveStatus = getLiveStatus(doc);
      if (liveStatus === 'Concluído') return false;
      const daysInfo = getRemainingDays(doc.deadlineDate);
      return liveStatus === 'Atrasado' || daysInfo.days <= 2;
    })
    .sort((a, b) => {
      const bDays = getRemainingDays(b.deadlineDate).days;
      const aDays = getRemainingDays(a.deadlineDate).days;
      return aDays - bDays; // Sort so more overdue are first
    });

  // Department breakdown list
  const docTypes = filteredDocs.reduce((acc: { [key: string]: number }, doc) => {
    acc[doc.type] = (acc[doc.type] || 0) + 1;
    return acc;
  }, {});

  const typeEntries = Object.entries(docTypes);

  return (
    <div className="space-y-4">
      {/* Alert Header if there are overdue documents */}
      {stats.delayed > 0 && (
        <div id="stats-alert-banner" className="bg-red-50 border border-l-4 border-red-650 border-slate-300 p-3 rounded flex items-start gap-2.5">
          <AlertTriangle className="w-4 h-4 text-red-700 shrink-0 mt-0.5" />
          <div>
            <h3 className="text-xs font-bold text-red-950 leading-tight">ALERTA DE PRODUTIVIDADE: Prazos Expirados</h3>
            <p className="text-[11px] text-red-800 mt-0.5">
              Há <strong className="font-bold">{stats.delayed} documento(s) com o prazo de resposta expirado</strong> {selectedDept !== 'all' ? `no setor ${selectedDept}` : 'regulamentares na prefeitura'}. Despache com prioridade máxima.
            </p>
          </div>
        </div>
      )}

      {/* Main KPI Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        {/* Total Card */}
        <button
          onClick={() => onFilterClick('All')}
          className="bg-white border border-slate-300 hover:border-slate-400 p-3 rounded shadow-xs transition-all text-left group"
        >
          <div className="flex justify-between items-center mb-1">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Total Geral</span>
            <div className="p-1 px-1.5 bg-slate-100 rounded text-slate-700 font-bold group-hover:bg-slate-200 transition-all text-[11px] flex items-center gap-1">
              <FileText className="w-3 h-3" />
            </div>
          </div>
          <p className="text-xl font-bold font-sans text-slate-900 leading-tight">{stats.total}</p>
          <p className="text-[10px] text-slate-400 mt-0.5 group-hover:text-blue-700 transition-all font-semibold">Exibir base completa ➔</p>
        </button>

        {/* Pendentes */}
        <button
          onClick={() => onFilterClick('Pendente')}
          className="bg-white border border-slate-300 hover:border-slate-400 p-3 rounded shadow-xs transition-all text-left group"
        >
          <div className="flex justify-between items-center mb-1">
            <span className="text-[10px] font-bold text-blue-700 uppercase tracking-widest">Pendentes</span>
            <div className="p-1 px-1.5 bg-blue-50 rounded text-blue-700 font-bold text-[11px] flex items-center gap-1">
              <Clock className="w-3 h-3" />
            </div>
          </div>
          <p className="text-xl font-bold font-sans text-blue-900 leading-tight">{stats.pending}</p>
          <p className="text-[10px] text-slate-400 mt-0.5 group-hover:text-blue-700 transition-all font-semibold">Aguardando anexos ➔</p>
        </button>

        {/* Em Análise */}
        <button
          onClick={() => onFilterClick('Em Análise')}
          className="bg-white border border-slate-300 hover:border-slate-400 p-3 rounded shadow-xs transition-all text-left group"
        >
          <div className="flex justify-between items-center mb-1">
            <span className="text-[10px] font-bold text-amber-700 uppercase tracking-widest">Em Análise</span>
            <div className="p-1 px-1.5 bg-amber-50 rounded text-amber-700 font-bold text-[11px] flex items-center gap-1">
              <CalendarDays className="w-3 h-3" />
            </div>
          </div>
          <p className="text-xl font-bold font-sans text-amber-900 leading-tight">{stats.inAnalysis}</p>
          <p className="text-[10px] text-slate-400 mt-0.5 group-hover:text-amber-700 transition-all font-semibold font-semibold">Em instrução técnica ➔</p>
        </button>

        {/* Atrasados */}
        <button
          onClick={() => onFilterClick('Atrasado')}
          className="bg-white border border-slate-300 hover:border-red-400 p-3 rounded shadow-xs transition-all text-left group relative"
        >
          <div className="flex justify-between items-center mb-1">
            <span className="text-[10px] font-bold text-red-700 uppercase tracking-widest">Atrasados</span>
            <div className="p-1 px-1.5 bg-red-50 rounded text-red-700 font-bold border border-red-100 text-[11px] flex items-center gap-1">
              <AlertTriangle className="w-3 h-3" />
            </div>
          </div>
          <p className="text-xl font-bold font-sans text-red-700 leading-tight">{stats.delayed}</p>
          <p className="text-[10px] text-red-500 mt-0.5 group-hover:text-red-700 transition-all font-bold">Bloqueando trâmites ➔</p>
        </button>

        {/* Concluídos */}
        <button
          onClick={() => onFilterClick('Concluído')}
          className="bg-white border border-slate-300 hover:border-slate-400 p-3 rounded shadow-xs transition-all text-left group"
        >
          <div className="flex justify-between items-center mb-1">
            <span className="text-[10px] font-bold text-emerald-700 uppercase tracking-widest">Concluídos</span>
            <div className="p-1 px-1.5 bg-emerald-50 rounded text-emerald-700 font-bold text-[11px] flex items-center gap-1">
              <CheckCircle className="w-3 h-3" />
            </div>
          </div>
          <p className="text-xl font-bold font-sans text-emerald-900 leading-tight">{stats.completed}</p>
          <p className="text-[10px] text-slate-400 mt-0.5 group-hover:text-emerald-700 transition-all font-semibold">Concluídos/Arquivados ➔</p>
        </button>
      </div>

      {/* Grid with Deadlines Control & Document Categorization */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        
        {/* Left Column: List of Deadlines and Critical Tasks */}
        <div className="lg:col-span-2 bg-white rounded border border-slate-300 p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3 border-b border-slate-200 pb-2">
              <div>
                <h3 className="font-sans font-bold text-slate-900 text-xs flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-slate-650" />
                  CONTROLE DE PRAZOS E ADVERTÊNCIAS TEMPORAIS
                </h3>
                <p className="text-[10px] text-slate-500">Documentos ordenados por emergência de prazo de despacho</p>
              </div>
              <span className="text-[10px] bg-slate-100 font-bold px-2 py-0.5 text-slate-600 border border-slate-300 rounded">
                {criticalDocuments.length} Pendência(s)
              </span>
            </div>

            {criticalDocuments.length === 0 ? (
              <div className="flex flex-col items-center justify-center p-6 text-center bg-slate-50 rounded border border-dashed border-slate-300">
                <FileCheck className="w-8 h-8 text-emerald-600 mb-1.5" />
                <p className="text-xs font-bold text-slate-800">CUMPRIMENTO DAS METAS DE PRAZO</p>
                <p className="text-[11px] text-slate-500 max-w-xs mt-0.5">Nenhum documento atrasado ou prestes a vencer para o setor ativo.</p>
              </div>
            ) : (
              <div className="space-y-1.5 max-h-72 overflow-y-auto pr-1">
                {criticalDocuments.slice(0, 5).map((doc) => {
                  const daysLeft = getRemainingDays(doc.deadlineDate);
                  const daysAbs = Math.abs(daysLeft.days);
                  return (
                    <div 
                      key={doc.id}
                      className="p-2 bg-slate-50 hover:bg-slate-100/80 border border-slate-200 rounded flex items-center justify-between transition-colors gap-3"
                    >
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-[10px] font-mono font-bold text-[#003366] bg-blue-50/60 px-1 border border-blue-200 rounded">{doc.protocol}</span>
                          <span className={`text-[9px] font-bold px-1 rounded border uppercase ${daysLeft.badgeColor}`}>
                            {daysLeft.label}
                          </span>
                        </div>
                        <h4 className="text-[12px] font-bold text-slate-850 mt-1 truncate">{doc.title}</h4>
                        <p className="text-[10px] text-slate-500 truncate mt-0.5">Origem: <span className="font-semibold text-slate-700">{doc.origin}</span> ➔ Destino: <span className="font-semibold text-slate-700">{doc.destination}</span></p>
                      </div>

                      <button
                        onClick={() => onViewDoc(doc.id)}
                        className="p-1 hover:bg-blue-100 text-[#003366] rounded hover:text-blue-900 group transition-colors shrink-0 border border-transparent hover:border-blue-300"
                        title="Abrir Trâmite"
                      >
                        <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                      </button>
                    </div>
                  );
                })}
                {criticalDocuments.length > 5 && (
                  <p className="text-[10px] text-center text-slate-500 italic pt-1">
                    + {criticalDocuments.length - 5} outros documentos prioritários regulamentados
                  </p>
                )}
              </div>
            )}
          </div>
          
          <div className="mt-3 pt-2.5 border-t border-slate-205 flex items-center justify-between text-[11px] text-slate-500">
            <span>Setor Ativo Filtro: <strong className="font-bold text-[#003366] uppercase">{selectedDept === 'all' ? 'Administração Geral' : selectedDept}</strong></span>
            <span>Urgentes de Setor: <strong className="font-bold text-red-650">{criticalDocuments.length}</strong></span>
          </div>
        </div>

        {/* Right Column: Types Breakdown visual representation */}
        <div className="bg-white rounded border border-slate-300 p-4 flex flex-col justify-between">
          <div>
            <h3 className="font-sans font-bold text-slate-900 text-xs mb-3 border-b border-slate-200 pb-2 uppercase tracking-wide">
              VOLUMETRIA REGISTRADA POR GÊNERO
            </h3>
            
            {typeEntries.length === 0 ? (
              <p className="text-[11px] text-slate-500 italic p-6 text-center">Nenhum documento registrado no banco de dados.</p>
            ) : (
              <div className="space-y-3">
                {typeEntries.map(([type, value]) => {
                  const percentage = Math.round((value / stats.total) * 100) || 0;
                  // High Density Professional Colors
                  let barColor = 'bg-[#003366]';
                  if (type === 'Memorando') barColor = 'bg-slate-700';
                  if (type === 'Ofício') barColor = 'bg-blue-600';
                  if (type === 'Portaria') barColor = 'bg-orange-500';
                  if (type === 'Comunicação Interna') barColor = 'bg-indigo-600';

                  return (
                    <div key={type} className="space-y-0.5">
                      <div className="flex justify-between text-[11px]">
                        <span className="font-bold text-slate-700">{type}</span>
                        <span className="font-bold text-slate-900">{value} <span className="text-slate-400 font-normal">({percentage}%)</span></span>
                      </div>
                      <div className="h-1.5 w-full bg-slate-100 border border-slate-200 rounded-sm overflow-hidden">
                        <div 
                          className={`h-full ${barColor}`} 
                          style={{ width: `${percentage}%` }}
                        ></div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div className="bg-slate-50 border border-slate-200 p-2.5 rounded mt-4 animate-fade-in">
            <h4 className="text-[10px] font-bold text-slate-600 uppercase tracking-widest">Contingenciamento {currentMunicipality}</h4>
            <p className="text-[10px] text-slate-500 leading-normal mt-0.5">
              Portal do Município de {currentMunicipality}. O uso do protocolo eletrônico é obrigatório para correspondências oficiais internas, eliminando transporte físico de processos.
            </p>
          </div>
        </div>

      </div>
    </div>
  );
}
