import React, { useState, useRef, useEffect } from 'react';
import {
  PenTool,
  CheckCircle2,
  AlertCircle,
  Clock,
  Key,
  Lock,
  FileText,
  Shield,
  Search,
  Check,
  X,
  Award,
  Hash,
  Fingerprint,
  Users,
  Building
} from 'lucide-react';
import { Document, AppUser, DigitalSignature } from '../types';
import { formatDate } from '../utils';

interface DigitalSignatureTabProps {
  documents: Document[];
  onUpdateDocument: (updated: Document) => void;
  currentUser: AppUser;
}

export default function DigitalSignatureTab({
  documents,
  onUpdateDocument,
  currentUser
}: DigitalSignatureTabProps) {
  // Navigation tabs inside Signature screen
  const [activeSubTab, setActiveSubTab] = useState<'pending' | 'signed' | 'validator'>('pending');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Selection state for Batch signatures
  const [selectedDocIds, setSelectedDocIds] = useState<string[]>([]);
  
  // Signature form state
  const [pinCode, setPinCode] = useState('');
  const [signatureType, setSignatureType] = useState<'cloud' | 'token' | 'simple'>('cloud');
  const [signingPassword, setSigningPassword] = useState('');
  
  // Signature Drawing Canvas state
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [canvasHasDrawing, setCanvasHasDrawing] = useState(false);

  // Verification tool state
  const [verifyHashInput, setVerifyHashInput] = useState('');
  const [verificationResult, setVerificationResult] = useState<{
    found: boolean;
    doc?: Document;
    sig?: DigitalSignature;
    searched: boolean;
  } | null>(null);

  // Feedback states
  const [isSigningLoading, setIsSigningLoading] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Run initial setup for drawing canvas if visible
  useEffect(() => {
    if (activeSubTab === 'pending' && selectedDocIds.length > 0 && canvasRef.current) {
      initCanvas();
    }
  }, [selectedDocIds, activeSubTab]);

  const initCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.strokeStyle = '#0f172a'; // slate-900
    ctx.lineWidth = 2.5;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    
    // Draw guide line
    ctx.strokeStyle = '#cbd5e1'; // slate-300 grid
    ctx.beginPath();
    ctx.setLineDash([4, 4]);
    ctx.moveTo(30, canvas.height - 40);
    ctx.lineTo(canvas.width - 30, canvas.height - 40);
    ctx.stroke();
    ctx.setLineDash([]); // clear dash
    ctx.strokeStyle = '#1e3a8a'; // dark-blue drawing ink
    setCanvasHasDrawing(false);
  };

  const clearCanvas = () => {
    initCanvas();
  };

  // Canvas drawing handlers (mouse & touch support)
  const getCoordinates = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    
    if ('touches' in e) {
      if (e.touches.length === 0) return { x: 0, y: 0 };
      return {
        x: e.touches[0].clientX - rect.left,
        y: e.touches[0].clientY - rect.top
      };
    } else {
      return {
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
      };
    }
  };

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const coords = getCoordinates(e);
    ctx.beginPath();
    ctx.moveTo(coords.x, coords.y);
    setIsDrawing(true);
    setCanvasHasDrawing(true);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    e.preventDefault();
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;

    const coords = getCoordinates(e);
    ctx.lineTo(coords.x, coords.y);
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  // Highlight message toast
  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 5000);
  };

  // Helper to check ifcurrentUser department has access or is related to a doc
  const canUserSignedDoc = (doc: Document) => {
    // Check if document is already signed by this user
    const alreadySigned = doc.signatures?.some(sig => sig.userName === currentUser.name);
    if (alreadySigned) return false;
    
    // To allow high ease of testing, any user can sign processes assigned to their department OR they sent.
    // If master, we can sign absolutely everything for audit validation!
    if (currentUser.role === 'master') return true;

    const userDeptLow = currentUser.department.toLowerCase();
    const originLow = doc.origin.toLowerCase();
    const destLow = doc.destination.toLowerCase();

    return originLow.includes(userDeptLow) || 
           userDeptLow.includes(originLow) || 
           destLow.includes(userDeptLow) || 
           userDeptLow.includes(destLow);
  };

  // Filter documents according to Sub-Tab
  const itemsPendingSignature = documents.filter(doc => {
    const matchesSearch = doc.protocol.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          doc.title.toLowerCase().includes(searchQuery.toLowerCase());
    const isSignable = canUserSignedDoc(doc);
    return isSignable && matchesSearch && doc.status !== 'Concluído';
  });

  const itemsSignedByMe = documents.filter(doc => {
    const matchesSearch = doc.protocol.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          doc.title.toLowerCase().includes(searchQuery.toLowerCase());
    const alreadySigned = doc.signatures?.some(sig => sig.userName === currentUser.name);
    return alreadySigned && matchesSearch;
  });

  // Toggle selection for code signature selection checklist
  const handleToggleDocSelect = (docId: string) => {
    setSelectedDocIds(prev => 
      prev.includes(docId) 
        ? prev.filter(id => id !== docId) 
        : [...prev, docId]
    );
  };

  const handleSelectAllPending = () => {
    if (selectedDocIds.length === itemsPendingSignature.length) {
      setSelectedDocIds([]);
    } else {
      setSelectedDocIds(itemsPendingSignature.map(d => d.id));
    }
  };

  // Perform cryptographic batch signing
  const handleBatchSignSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedDocIds.length === 0) {
      triggerToast('Nenhum documento selecionado para assinar.');
      return;
    }

    setIsSigningLoading(true);

    // Simulate cryptographic processing (RSA asymmetric key calculation + ICP Stamp registry)
    setTimeout(() => {
      selectedDocIds.forEach(docId => {
        const doc = documents.find(d => d.id === docId);
        if (!doc) return;

        // Generate mock signature metadata matching brazilian government standards
        const randomHex = Array.from({ length: 16 }, () => 
          Math.floor(Math.random() * 16).toString(16)
        ).join('');
        const signatureHash = `ICP-BR-SHA256-${doc.protocol}-${randomHex}-${Date.now().toString().slice(-6)}`.toUpperCase();

        const newSignature: DigitalSignature = {
          id: `sig-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
          userName: currentUser.name,
          userRole: currentUser.role === 'master' ? 'Master Auditor' : currentUser.role === 'gestor' ? 'Gestor' : 'Servidor',
          userDepartment: currentUser.department,
          signedAt: new Date().toISOString(),
          ipAddress: `177.85.${Math.floor(Math.random()*120)}.${Math.floor(Math.random()*240)}`,
          certificateAuthority: signatureType === 'cloud' 
            ? 'ICP-Brasil Autoridade Certificadora Gov.br (A1)'
            : signatureType === 'token'
              ? 'ICP-Brasil Token Físico Criptográfico (A3)'
              : 'Assinatura Eletrônica Simples Decreto Municipal 12/2024',
          hash: signatureHash
        };

        const updatedHistory = [
          ...doc.history,
          {
            id: `h-sig-${Date.now()}`,
            date: new Date().toISOString(),
            user: currentUser.name,
            action: 'ASSINATURA DIGITAL REGISTRADA',
            notes: `Processo assinado digitalmente nos padrões ICP-Brasil por meio de autenticação de credencial. Ref Hash: ${signatureHash.substring(0, 15)}...`
          }
        ];

        // Also if status is Pendente or Em Análise, move closer to conclusion
        let nextStatus = doc.status;
        if (doc.status === 'Pendente') {
          nextStatus = 'Em Análise';
        }

        const updatedDoc: Document = {
          ...doc,
          status: nextStatus,
          signatures: [...(doc.signatures || []), newSignature],
          history: updatedHistory
        };

        onUpdateDocument(updatedDoc);
      });

      setIsSigningLoading(false);
      triggerToast(`${selectedDocIds.length} documento(s) assinado(s) digitalmente com sucesso!`);
      setSelectedDocIds([]);
      setPinCode('');
      setSigningPassword('');
      setCanvasHasDrawing(false);
      // Switch back or refresh canvas if elements remaining
    }, 1800);
  };

  // Verify any SHA-256 digital stamp receipt
  const handleVerifySignatureHash = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanInput = verifyHashInput.trim().toUpperCase();
    if (!cleanInput) return;

    let foundDoc: Document | undefined = undefined;
    let foundSig: DigitalSignature | undefined = undefined;

    for (const doc of documents) {
      if (doc.signatures) {
        const sig = doc.signatures.find(s => s.hash.toUpperCase().includes(cleanInput) || cleanInput.includes(s.hash.toUpperCase()));
        if (sig) {
          foundDoc = doc;
          foundSig = sig;
          break;
        }
      }
    }

    // fallback try checking protocol directly instead of signature code
    if (!foundDoc) {
      foundDoc = documents.find(d => d.protocol.toUpperCase() === cleanInput);
      if (foundDoc && foundDoc.signatures && foundDoc.signatures.length > 0) {
        foundSig = foundDoc.signatures[0];
      }
    }

    setVerificationResult({
      found: !!foundDoc && !!foundSig,
      doc: foundDoc,
      sig: foundSig,
      searched: true
    });
  };

  return (
    <div className="space-y-6">
      
      {/* Dynamic Action Toasts */}
      {toastMessage && (
        <div className="fixed bottom-4 right-4 z-50 bg-emerald-900 border border-emerald-500 text-white font-bold p-4 rounded shadow-2xl flex items-center gap-2.5 max-w-sm animate-fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span className="text-xs">{toastMessage}</span>
        </div>
      )}

      {/* Hero Certificate branding */}
      <div className="bg-gradient-to-r from-emerald-700 via-teal-800 to-slate-950 text-white rounded p-6 shadow-md border-b-4 border-emerald-500">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-white/10 backdrop-blur-md rounded flex items-center justify-center p-2 text-emerald-300 shrink-0">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <h2 className="font-sans font-extrabold text-lg sm:text-xl uppercase tracking-wider flex items-center gap-1.5">
                <span>Assinatura Digital Corporativa</span>
                <span className="text-[9px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-450 px-1.5 py-0.5 rounded uppercase font-mono tracking-widest">ICP-Brasil SEC</span>
              </h2>
              <p className="text-xs text-emerald-100">Assinatura formal de memorandos, ofícios e portarias municipais. Segurança criptográfica jurídica sem papelada.</p>
            </div>
          </div>
          <div className="text-right">
            <span className="text-[10px] text-emerald-250 block font-bold font-mono uppercase">Lotação Atual</span>
            <span className="text-xs font-bold text-white bg-slate-900/60 border border-emerald-800 px-2.5 py-1 rounded block mt-0.5 max-w-[200px] truncate uppercase">
              {currentUser.department.split('(')[1]?.replace(')', '') || currentUser.department}
            </span>
          </div>
        </div>
      </div>

      {/* Sub tabs bar */}
      <div className="flex border-b border-slate-350">
        <button
          onClick={() => { setActiveSubTab('pending'); setSearchQuery(''); setSelectedDocIds([]); }}
          className={`px-4 py-2.5 text-xs font-extrabold uppercase tracking-wider transition-all flex items-center gap-2 border-b-2 ${
            activeSubTab === 'pending'
              ? 'border-emerald-600 text-emerald-850 bg-emerald-50/25'
              : 'border-transparent text-slate-500 hover:text-slate-800 bg-transparent'
          }`}
        >
          <PenTool className="w-4 h-4 text-emerald-600" />
          <span>Aguardando Assinatura ({itemsPendingSignature.length})</span>
        </button>
        <button
          onClick={() => { setActiveSubTab('signed'); setSearchQuery(''); }}
          className={`px-4 py-2.5 text-xs font-extrabold uppercase tracking-wider transition-all flex items-center gap-2 border-b-2 ${
            activeSubTab === 'signed'
              ? 'border-emerald-600 text-emerald-850 bg-emerald-50/25'
              : 'border-transparent text-slate-500 hover:text-slate-800 bg-transparent'
          }`}
        >
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>Meus Documentos Assinados ({itemsSignedByMe.length})</span>
        </button>
        <button
          onClick={() => { setActiveSubTab('validator'); setVerificationResult(null); setVerifyHashInput(''); }}
          className={`px-4 py-2.5 text-xs font-extrabold uppercase tracking-wider transition-all flex items-center gap-2 border-b-2 ${
            activeSubTab === 'validator'
              ? 'border-emerald-600 text-emerald-850 bg-emerald-50/25'
              : 'border-transparent text-slate-500 hover:text-slate-800 bg-transparent'
          }`}
        >
          <Shield className="w-4 h-4 text-emerald-600" />
          <span>Validador de Recibo Digital</span>
        </button>
      </div>

      {/* Screen Panels */}
      {activeSubTab === 'pending' && (
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
          
          {/* Left panel list (Checked select) */}
          <div className="xl:col-span-7 space-y-4">
            
            {/* Search Input filter bar */}
            <div className="flex items-center gap-2 bg-white rounded border border-slate-300 p-2.5 shadow-sm">
              <Search className="w-4 h-4 text-slate-400 shrink-0" />
              <input
                type="text"
                placeholder="Pesquisar por assunto ou código de protocolo..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-transparent text-xs outline-none text-slate-800 placeholder-slate-400"
              />
            </div>

            {/* Document Checkbox Table */}
            <div className="bg-white border border-slate-300 rounded overflow-hidden shadow-2xs">
              <div className="p-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
                <div className="flex items-center gap-20">
                  <label className="flex items-center gap-2 cursor-pointer text-[10px] font-extrabold text-slate-500 uppercase tracking-wider select-none">
                    <input
                      type="checkbox"
                      checked={itemsPendingSignature.length > 0 && selectedDocIds.length === itemsPendingSignature.length}
                      onChange={handleSelectAllPending}
                      disabled={itemsPendingSignature.length === 0}
                      className="rounded text-emerald-600 border-slate-300 focus:ring-emerald-500 focus:ring-opacity-50 h-3.5 w-3.5 cursor-pointer"
                    />
                    <span>Selecionar Todos</span>
                  </label>
                </div>
                <div className="text-[10px] font-bold text-emerald-800 block uppercase font-mono">
                  {selectedDocIds.length} selecionado(s) para lote
                </div>
              </div>

              {itemsPendingSignature.length === 0 ? (
                <div className="p-8 text-center space-y-2">
                  <CheckCircle2 className="w-9 h-9 text-emerald-650 mx-auto opacity-75" />
                  <p className="text-xs font-bold text-slate-800 uppercase">Tudo Assinado!</p>
                  <p className="text-[11px] text-slate-500 max-w-sm mx-auto">Não há nenhum processo pendente de assinatura associado às suas permissões ou enviadas pelo seu setor de atuação.</p>
                </div>
              ) : (
                <div className="divide-y divide-slate-200 divide-y max-h-[460px] overflow-y-auto scrollbar-thin">
                  {itemsPendingSignature.map((doc) => {
                    const isChecked = selectedDocIds.includes(doc.id);
                    return (
                      <div
                        key={doc.id}
                        onClick={() => handleToggleDocSelect(doc.id)}
                        className={`p-3.5 flex items-start gap-3.5 hover:bg-slate-50 cursor-pointer transition-colors ${
                          isChecked ? 'bg-emerald-50/30' : ''
                        }`}
                      >
                        <div className="pt-0.5" onClick={(e) => e.stopPropagation()}>
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => handleToggleDocSelect(doc.id)}
                            className="rounded text-emerald-600 border-slate-300 focus:ring-emerald-500 h-4 w-4 cursor-pointer"
                          />
                        </div>
                        <div className="min-w-0 flex-1 space-y-1">
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-xs font-mono font-extrabold text-emerald-850">{doc.protocol}</span>
                            <span className={`text-[8px] font-bold uppercase border px-1.5 py-0.5 rounded ${
                              doc.priority === 'Urgente' || doc.priority === 'Alta'
                                ? 'bg-red-50 text-red-700 border-red-100'
                                : 'bg-slate-50 text-slate-500 border-slate-200'
                            }`}>
                              {doc.priority}
                            </span>
                          </div>
                          <p className="text-xs font-bold text-slate-850 truncate">{doc.title}</p>
                          <div className="flex items-center gap-3 text-[10px] text-slate-405 font-medium uppercase font-mono">
                            <span>Tipo: {doc.type}</span>
                            <span>•</span>
                            <span>Prazo: {formatDate(doc.deadlineDate)}</span>
                          </div>
                          <div className="flex items-center gap-1.5 pt-1 text-[9px] text-slate-500 uppercase">
                            <Building className="w-3 h-3 text-slate-400" />
                            <span>Origem de Envio: {doc.origin.includes('(') ? doc.origin.split('(')[1]?.replace(')', '') : doc.origin}</span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          {/* Right Signature Checkout Panel */}
          <div className="xl:col-span-5">
            <div className="bg-white border border-slate-300 rounded p-5 shadow-sm space-y-4">
              <div className="border-b border-slate-100 pb-2">
                <h3 className="text-xs font-black text-[#003366] uppercase tracking-wide flex items-center gap-1.5">
                  <Key className="w-4 h-4 text-emerald-650" />
                  <span>Cofre de Assinatura Eletrônica</span>
                </h3>
                <p className="text-[10px] text-slate-500">Insira suas credenciais corporativas e desenhe sua rubrica digital para submeter em lote.</p>
              </div>

              {selectedDocIds.length === 0 ? (
                <div className="bg-slate-50 border border-dashed border-slate-300 rounded p-6 text-center text-xs text-slate-505 leading-relaxed space-y-2">
                  <Lock className="w-8 h-8 text-slate-400 mx-auto" />
                  <p className="font-bold uppercase text-slate-700">Aguardando Seleção de Lote</p>
                  <p>Marque um ou mais documentos na caixa de listagem à esquerda para habilitar o painel de validação ICP-Brasil.</p>
                </div>
              ) : (
                <form onSubmit={handleBatchSignSubmit} className="space-y-4 animate-in fade-in-60 duration-200">
                  <div className="bg-emerald-50/50 border border-emerald-100 p-3 rounded">
                    <span className="text-[9px] font-extrabold uppercase text-emerald-850 block">Documentos Selecionados para Assinar</span>
                    <div className="mt-1.5 space-y-1 max-h-[140px] overflow-y-auto scrollbar-thin">
                      {selectedDocIds.map(id => {
                        const target = documents.find(d => d.id === id);
                        return target ? (
                          <div key={id} className="text-[11px] font-bold text-slate-800 flex items-center justify-between gap-2.5">
                            <span className="truncate max-w-[200px]">{target.title}</span>
                            <span className="text-[9px] font-mono shrink-0 text-emerald-800">{target.protocol}</span>
                          </div>
                        ) : null;
                      })}
                    </div>
                  </div>

                  {/* Signature Type */}
                  <div className="space-y-1.5">
                    <label className="block text-[10px] font-bold text-slate-700 uppercase">Modalidade de Certificado Autorizador</label>
                    <div className="grid grid-cols-3 gap-1.5">
                      <button
                        type="button"
                        onClick={() => setSignatureType('cloud')}
                        className={`p-1.5 border rounded text-[10px] font-extrabold uppercase transition-all flex flex-col items-center justify-center text-center gap-1 ${
                          signatureType === 'cloud' 
                            ? 'bg-emerald-50 border-emerald-500 text-emerald-900 shadow-2xs' 
                            : 'bg-white border-slate-300 text-slate-500 hover:text-slate-900'
                        }`}
                      >
                        <Fingerprint className="w-3.5 h-3.5" />
                        <span>Nuvem A1</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setSignatureType('token')}
                        className={`p-1.5 border rounded text-[10px] font-extrabold uppercase transition-all flex flex-col items-center justify-center text-center gap-1 ${
                          signatureType === 'token' 
                            ? 'bg-emerald-50 border-emerald-500 text-emerald-900 shadow-2xs' 
                            : 'bg-white border-slate-300 text-slate-500 hover:text-slate-900'
                        }`}
                      >
                        <Shield className="w-3.5 h-3.5" />
                        <span>Token A3</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setSignatureType('simple')}
                        className={`p-1.5 border rounded text-[10px] font-extrabold uppercase transition-all flex flex-col items-center justify-center text-center gap-1 ${
                          signatureType === 'simple' 
                            ? 'bg-emerald-50 border-emerald-500 text-emerald-900 shadow-2xs' 
                            : 'bg-white border-slate-300 text-slate-500 hover:text-slate-900'
                        }`}
                      >
                        <PenTool className="w-3.5 h-3.5" />
                        <span>Simples</span>
                      </button>
                    </div>
                  </div>

                  {/* Draw Signature Canvas Box */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <label className="block text-[10px] font-bold text-slate-700 uppercase">Desenhe sua Rubrica/Assinatura Manual</label>
                      <button
                        type="button"
                        onClick={clearCanvas}
                        className="text-[9px] text-[#003366] font-bold hover:underline cursor-pointer"
                      >
                        Redesenhar
                      </button>
                    </div>
                    
                    <div className="border border-slate-300 bg-slate-50 rounded overflow-hidden">
                      <canvas
                        ref={canvasRef}
                        width={320}
                        height={100}
                        onMouseDown={startDrawing}
                        onMouseMove={draw}
                        onMouseUp={stopDrawing}
                        onMouseLeave={stopDrawing}
                        onTouchStart={startDrawing}
                        onTouchMove={draw}
                        onTouchEnd={stopDrawing}
                        className="w-full bg-slate-50/75 cursor-crosshair touch-none block"
                        title="Escreva sua rubrica digital com o mouse ou o indicador"
                      />
                    </div>
                    <p className="text-[8px] text-slate-405 italic">O traçado acima é vetorizado e criptografado para geração do termo visual oficial da ICP-Brasil.</p>
                  </div>

                  {/* Validation inputs */}
                  <div className="space-y-2 pb-1">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-700 uppercase mb-1">Confirme seu Código PIN da Carteira Gov.br *</label>
                      <input
                        type="password"
                        required
                        value={pinCode}
                        onChange={(e) => setPinCode(e.target.value)}
                        placeholder="Insira o PIN de 4 dígitos"
                        className="w-full bg-slate-50 border border-slate-300 text-xs p-1.5 rounded font-mono font-bold focus:outline-none focus:border-emerald-600 focus:bg-white"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-700 uppercase mb-1">Senha de Entrada do DOC *</label>
                      <input
                        type="password"
                        required
                        value={signingPassword}
                        onChange={(e) => setSigningPassword(e.target.value)}
                        placeholder="Senha de confirmação de sessão"
                        className="w-full bg-slate-50 border border-slate-300 text-xs p-1.5 rounded font-bold focus:outline-none focus:border-emerald-600 focus:bg-white"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={isSigningLoading || !canvasHasDrawing}
                    className={`w-full py-2 px-4 rounded text-xs font-black uppercase tracking-wider text-white shadow-md flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                      isSigningLoading || !canvasHasDrawing
                        ? 'bg-slate-400 cursor-not-allowed opacity-75'
                        : 'bg-emerald-600 hover:bg-emerald-700'
                    }`}
                  >
                    {isSigningLoading ? (
                      <>
                        <div className="w-3.5 h-3.5 border-2 border-white/40 border-t-white rounded-full animate-spin"></div>
                        <span>Processando Assinatura em Lote...</span>
                      </>
                    ) : (
                      <>
                        <PenTool className="w-4 h-4" />
                        <span>Confirmar e Assinar {selectedDocIds.length} Processo(s)</span>
                      </>
                    )}
                  </button>
                  {!canvasHasDrawing && (
                    <p className="text-[8.5px] text-center text-red-650 font-bold block">
                      ⚠️ Você precisa desenhar sua rubrica de segurança no quadro acima para assinar!
                    </p>
                  )}
                </form>
              )}
            </div>
          </div>

        </div>
      )}

      {activeSubTab === 'signed' && (
        <div className="space-y-4 animate-in fade-in-50 duration-250">
          <div className="flex items-center gap-2 bg-white rounded border border-slate-300 p-2.5 shadow-sm">
            <Search className="w-4 h-4 text-slate-400 shrink-0" />
            <input
              type="text"
              placeholder="Pesquisar por assunto ou código de protocolo nos seus assinados..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-transparent text-xs outline-none text-slate-800 placeholder-slate-400"
            />
          </div>

          {itemsSignedByMe.length === 0 ? (
            <div className="bg-slate-50 border border-dashed border-slate-300 p-8 rounded text-center text-slate-400 text-xs">
              Nenhum documento assinado digitalmente por você foi localizado no banco atual da prefeitura.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {itemsSignedByMe.map((doc) => {
                const mySig = doc.signatures?.find(s => s.userName === currentUser.name);
                return (
                  <div key={doc.id} className="bg-white border border-slate-300 rounded p-4 flex flex-col justify-between hover:border-emerald-400 hover:shadow-2xs transition-all">
                    <div>
                      <div className="flex items-center justify-between border-b border-slate-100 pb-2 mb-2">
                        <span className="text-xs font-mono font-extrabold text-[#003366]">{doc.protocol}</span>
                        <span className="text-[8px] font-mono bg-emerald-50 text-emerald-800 border border-emerald-250 font-extrabold px-2 py-0.5 rounded uppercase">
                          Criptografado
                        </span>
                      </div>
                      <h4 className="text-xs font-extrabold text-slate-800 uppercase line-clamp-2 mb-1">{doc.title}</h4>
                      <div className="text-[10px] text-slate-500 font-medium font-mono uppercase">Matéria: {doc.type}</div>
                      
                      {mySig && (
                        <div className="mt-4 p-2.5 bg-emerald-50/50 border border-emerald-150 rounded space-y-1">
                          <div className="flex items-center gap-1.5 text-emerald-900 text-[9px] font-extrabold uppercase tracking-wide">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                            <span>Assinado Legalmente por Mim</span>
                          </div>
                          <p className="text-[10px] text-slate-705 leading-tight">
                            Reg. IP {mySig.ipAddress} via {mySig.certificateAuthority}
                          </p>
                          <p className="text-[9px] text-slate-500 font-mono flex items-center gap-1">
                            <Hash className="w-3 h-3 text-slate-400" />
                            <span className="truncate" title={mySig.hash}>HASH: {mySig.hash}</span>
                          </p>
                          <p className="text-[8px] text-slate-450 font-bold font-mono">DATA DE DEPÓSITO: {formatDate(mySig.signedAt)}</p>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {activeSubTab === 'validator' && (
        <div className="bg-white border border-slate-300 rounded p-5 shadow-sm space-y-5">
          <div className="max-w-xl space-y-2">
            <h3 className="text-xs font-black text-[#003366] uppercase tracking-wide">Painel de Auditoria de Chave ICP-Brasil</h3>
            <p className="text-xs text-slate-505 leading-relaxed">
              Todos os documentos gerados no DOC recebem uma estampa municipal de tempo contendo uma chave criptográfica pública SHA-256 no rodapé. Você pode digitar a chave ou o número de protocolo abaixo para certificar sua validade.
            </p>
          </div>

          <form onSubmit={handleVerifySignatureHash} className="flex flex-col sm:flex-row gap-3 max-w-xl">
            <input
              type="text"
              required
              placeholder="Digite o Protocolo ou o código HASH ICP-Brasil..."
              value={verifyHashInput}
              onChange={(e) => setVerifyHashInput(e.target.value)}
              className="flex-1 bg-slate-50 border border-slate-300 rounded text-xs p-2 focus:outline-none focus:border-emerald-600 text-slate-850 font-mono font-bold"
            />
            <button
              type="submit"
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs px-4 py-2 rounded shrink-0 transition-colors uppercase cursor-pointer"
            >
              Consultar Chave
            </button>
          </form>

          {/* Verification output area */}
          {verificationResult && (
            <div className="border border-slate-200 rounded p-4 max-w-xl bg-slate-50/50 animate-in fade-in-40 duration-150">
              {verificationResult.found && verificationResult.doc && verificationResult.sig ? (
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-emerald-800 font-extrabold text-xs uppercase">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                    <span>CERTIFICAÇÃO VÁLIDA - DOCUMENTO AUTÊNTICO</span>
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-xs border-y border-slate-200 py-3">
                    <div>
                      <span className="text-[9px] font-bold text-slate-400 block uppercase">Documento Vinculado</span>
                      <p className="font-extrabold text-slate-800">{verificationResult.doc.title}</p>
                      <p className="text-[10px] font-mono text-emerald-800">{verificationResult.doc.protocol} ({verificationResult.doc.type})</p>
                    </div>
                    <div>
                      <span className="text-[9px] font-bold text-slate-400 block uppercase">Origem / Destino</span>
                      <p className="text-[10px] text-slate-650 uppercase font-mono mt-0.5 truncate">
                        {verificationResult.doc.origin.includes('(') ? verificationResult.doc.origin.split('(')[1]?.replace(')', '') : verificationResult.doc.origin} 
                        ➡️ 
                        {verificationResult.doc.destination.includes('(') ? verificationResult.doc.destination.split('(')[1]?.replace(')', '') : verificationResult.doc.destination}
                      </p>
                    </div>
                  </div>

                  <div className="space-y-1.5 p-3 bg-white border border-slate-200 rounded max-w-md">
                    <div className="flex items-center gap-1 text-[#003366] text-[10px] font-black uppercase tracking-wide">
                      <Fingerprint className="w-4 h-4 text-emerald-650" />
                      <span>Metadados da Assinatura Cryptográfica</span>
                    </div>
                    <div className="text-[11px] text-slate-700 space-y-1">
                      <div>
                        <strong>Assinante:</strong> {verificationResult.sig.userName}
                      </div>
                      <div>
                        <strong>Papel:</strong> {verificationResult.sig.userRole} • {verificationResult.sig.userDepartment}
                      </div>
                      <div>
                        <strong>IP do Registro:</strong> {verificationResult.ipAddress || verificationResult.sig.ipAddress}
                      </div>
                      <div>
                        <strong>Certificadora:</strong> {verificationResult.sig.certificateAuthority}
                      </div>
                      <div className="pt-1.5 font-mono text-[9px] text-[#003366] select-all bg-slate-50 p-1.5 rounded break-all border border-slate-100">
                        HASH: {verificationResult.sig.hash}
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2 text-red-750 font-bold text-xs uppercase">
                    <AlertCircle className="w-5 h-5 text-red-600 shrink-0" />
                    <span>CHAVE DE SEGURANÇA NÃO RECONHECIDA</span>
                  </div>
                  <p className="text-[11px] text-slate-500 max-w-md leading-relaxed">
                    Não foi possível certificar a chave do recibo "{verifyHashInput}". Verifique se o código possui digitação válida ou se é um rascunho de documento pendente que ainda não concluiu a assinatura municipal de Cutias.
                  </p>
                </div>
              )}
            </div>
          )}
        </div>
      )}

    </div>
  );
}
