/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Calendar, 
  Clock, 
  Download, 
  CheckCircle, 
  AlertTriangle, 
  Building, 
  History, 
  Reply, 
  Paperclip,
  CalendarDays,
  FileCheck2,
  Lock
} from 'lucide-react';
import { Document, DocumentStatus, PriorityType, AppUser } from '../types';
import { getRemainingDays, getLiveStatus, formatDate, downloadFile, TODAY_DATE } from '../utils';

interface DocumentDetailProps {
  document: Document;
  onBack: () => void;
  onUpdateDocument: (updated: Document) => void;
  currentUser: AppUser;
}

export default function DocumentDetail({
  document: doc,
  onBack,
  onUpdateDocument,
  currentUser
}: DocumentDetailProps) {
  // Response form states
  const [responseText, setResponseText] = useState('');
  const [isResponding, setIsResponding] = useState(false);

  // Extend deadline states
  const [isExtending, setIsExtending] = useState(false);
  const [extensionDays, setExtensionDays] = useState('5');
  const [extensionReason, setExtensionReason] = useState('');

  const liveStatus = getLiveStatus(doc);
  const daysLeft = getRemainingDays(doc.deadlineDate);

  // Download logic
  const handleDownloadAttachment = () => {
    if (doc.attachment) {
      downloadFile(doc.attachment.name, doc.attachment.data, doc.attachment.type);
    } else {
      // If there's no attachment, generate an official DOC PDF-styled TXT report of the document itself
      const fileContent = `
========================================================================
            PREFEITURA MUNICIPAL DE CUTIAS - ESTADO DO AMAPÁ
                    SISTEMA ELETRÔNICO DE TRÂMITE - DOC
========================================================================
PROTOCOLO:      ${doc.protocol}
TIPO:           ${doc.type}
DATA ENVIO:     ${formatDate(doc.createdAt, true)}
PRAZO LIMITE:   ${formatDate(doc.deadlineDate)}
PRESTADOR:      ${doc.origin}
DESTINATÁRIO:   ${doc.destination}
ESTADO ATUAL:   ${liveStatus}
------------------------------------------------------------------------
ASSUNTO:
${doc.title}

TEOR DO DOCUMENTO / JUSTIFICATIVA:
${doc.description}

========================================================================
                  AUDITORIA DE HISTÓRICO DE TRÂMITES
========================================================================
${doc.history.map((h, i) => `[${i + 1}] ${formatDate(h.date, true)} - ${h.user}\n    Ação: ${h.action}\n    Obs: ${h.notes || 'Nenhuma.'}`).join('\n\n')}

========================================================================
Documento autenticado eletronicamente. Gerado pelo portal DOC Cutias.
========================================================================`;
      
      downloadFile(`doc_protocolo_${doc.protocol}.txt`, fileContent);
    }
  };

  // Submit Answer (Marks Concluído)
  const handleSendResponse = (e: React.FormEvent) => {
    e.preventDefault();
    if (!responseText.trim()) return;

    const updatedDoc: Document = {
      ...doc,
      status: 'Concluído',
      response: {
        responder: `${currentUser.name} (${currentUser.role === 'gestor' ? 'Gestor' : 'Servidor'} - ${currentUser.department})`,
        text: responseText,
        createdAt: new Date().toISOString()
      },
      history: [
        ...doc.history,
        {
          id: `h-resp-${Date.now()}`,
          date: new Date().toISOString(),
          user: `${currentUser.name} (${currentUser.role === 'gestor' ? 'Gestor' : 'Servidor'} - ${currentUser.department})`,
          action: 'Documento RESPONDIDO',
          notes: `Resposta oficial registrada: "${responseText.substring(0, 50)}..."`
        }
      ]
    };

    onUpdateDocument(updatedDoc);
    setResponseText('');
    setIsResponding(false);
  };

  // Postpone deadline (Dilação de Prazo)
  const handleExtendDeadline = (e: React.FormEvent) => {
    e.preventDefault();
    if (!extensionReason.trim()) {
      alert('Favor preencher a justificativa técnica para prorrogação do prazo.');
      return;
    }

    const currentDeadline = new Date(doc.deadlineDate);
    const addedDays = parseInt(extensionDays) || 5;
    currentDeadline.setDate(currentDeadline.getDate() + addedDays);
    const newDeadlineStr = currentDeadline.toISOString().split('T')[0];

    const updatedDoc: Document = {
      ...doc,
      deadlineDate: newDeadlineStr,
      status: 'Em Análise', // reset status is back in analysis instead of Delay
      history: [
        ...doc.history,
        {
          id: `h-ext-${Date.now()}`,
          date: new Date().toISOString(),
          user: `${currentUser.name} (${currentUser.role === 'gestor' ? 'Gestor' : 'Servidor'} - ${currentUser.department})`,
          action: 'DILAÇÃO DE PRAZO',
          notes: `Prazo prorrogado em +${addedDays} dias (Nova data: ${formatDate(newDeadlineStr)}). Justificativa: ${extensionReason}`
        }
      ]
    };

    onUpdateDocument(updatedDoc);
    setExtensionReason('');
    setIsExtending(false);
  };

  // Priority layout styles
  const getPrioBadge = (prio: PriorityType) => {
    switch (prio) {
      case 'Baixa': return 'bg-slate-100 text-slate-700 border-slate-200';
      case 'Média': return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'Alta': return 'bg-orange-50 text-orange-700 border-orange-200';
      case 'Urgente': return 'bg-red-50 text-red-700 border-red-200 animate-pulse';
    }
  };

  // Status layout styles
  const getStatusBadge = (status: DocumentStatus) => {
    switch (status) {
      case 'Pendente': return 'bg-sky-100 text-sky-800 border-sky-200';
      case 'Em Análise': return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'Atrasado': return 'bg-red-100 text-red-800 border-red-300 font-bold';
      case 'Concluído': return 'bg-emerald-100 text-emerald-800 border-emerald-300';
    }
  };

  return (
    <div className="space-y-4 max-w-5xl mx-auto pb-8 font-sans">
      
      {/* Back button and simple actions */}
      <div className="flex items-center justify-between">
        <button
          id="detail-back-btn"
          onClick={onBack}
          className="flex items-center gap-1 text-[#003366] hover:text-blue-900 transition-colors cursor-pointer text-xs font-bold uppercase"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          Voltar para Listagem
        </button>

        <span className="text-[10px] text-slate-500 font-mono font-bold">CÓD REGISTRO: {doc.id}</span>
      </div>

      {/* Main Grid: Document Data vs Workspace Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        
        {/* Left Column: Official Document representation */}
        <div className="lg:col-span-2 space-y-4">
          
          {/* Main Card representation */}
          <div className="bg-white rounded border border-slate-300 shadow-xs p-5 relative overflow-hidden">
            
            {/* Visual Header Accent Badge */}
            <div className="h-1.5 bg-[#003366] absolute top-0 left-0 right-0"></div>

            {/* Document stats ribbon */}
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-300 pb-3 mt-1">
              <div className="space-y-0.5">
                <span className="text-[9px] text-slate-400 block font-bold tracking-wider uppercase">PROTOCOLO OFICIAL</span>
                <span id="detail-protocol" className="text-xs font-mono font-extrabold text-slate-900 bg-slate-100 border border-slate-300 px-2 py-0.5 rounded">
                  {doc.protocol}
                </span>
              </div>

              <div className="flex gap-1.5">
                <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded border uppercase ${getStatusBadge(liveStatus)}`}>
                  {liveStatus === 'Atrasado' ? '⚠️ ATRASADO' : liveStatus}
                </span>
                <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded border uppercase ${getPrioBadge(doc.priority)}`}>
                  Prioridade {doc.priority}
                </span>
              </div>
            </div>

            {/* Document Content */}
            <div className="my-4 space-y-3.5">
              <div>
                <span className="text-[9px] text-slate-400 block font-bold uppercase tracking-wider">Assunto do Expediente</span>
                <h1 id="detail-title" className="text-base font-bold font-sans text-slate-900 leading-snug">
                  {doc.title}
                </h1>
              </div>

              {/* Trâmite info banner */}
              <div className="grid grid-cols-2 gap-3 p-2.5 bg-slate-50 border border-slate-300 rounded text-xs font-medium">
                <div>
                  <span className="text-[9px] text-slate-400 block uppercase font-bold">Departamento de Origem</span>
                  <strong className="text-slate-800 font-bold">{doc.origin}</strong>
                </div>
                <div>
                  <span className="text-[9px] text-slate-400 block uppercase font-bold">Departamento Destino</span>
                  <strong className="text-slate-800 font-bold">{doc.destination}</strong>
                </div>
              </div>

              <div>
                <span className="text-[9px] text-slate-400 block font-bold uppercase tracking-wider mb-0.5">Teor da Correspondência Oficial</span>
                <div className="text-xs text-slate-800 leading-relaxed bg-white border border-slate-200 p-3 rounded whitespace-pre-wrap font-sans">
                  {doc.description}
                </div>
              </div>

              {/* Deadline & creation visual panel */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                
                <div className="flex items-center gap-2 border border-slate-200 rounded p-2.5 bg-slate-50/50">
                  <Calendar className="w-4 h-4 text-slate-450 shrink-0" />
                  <div>
                    <span className="text-[9px] text-slate-405 block uppercase font-bold tracking-wider">Protocolado em</span>
                    <span className="text-xs text-slate-800 font-bold font-mono">{formatDate(doc.createdAt, true)}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2 border border-slate-200 rounded p-2.5 bg-slate-50/50">
                  <Clock className="w-4 h-4 text-amber-650 shrink-0" />
                  <div>
                    <span className="text-[9px] text-slate-405 block uppercase font-bold tracking-wider">Atendimento Limite</span>
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs text-slate-850 font-extrabold font-mono">{formatDate(doc.deadlineDate)}</span>
                      <span className={`text-[9px] font-extrabold px-1 py-0.2 rounded uppercase ${daysLeft.badgeColor}`}>
                        {daysLeft.label}
                      </span>
                    </div>
                  </div>
                </div>

              </div>

            </div>

            {/* Attachment block */}
            <div className="border-t border-slate-300 pt-3.5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2 min-w-0">
                <Paperclip className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <div className="min-w-0">
                  <p className="text-xs font-bold text-slate-850 truncate">
                    {doc.attachment ? doc.attachment.name : 'Voucher Oficial do Servidor (Certidão DOC)'}
                  </p>
                  <p className="text-[9px] text-slate-500 truncate">
                    {doc.attachment 
                      ? `${(doc.attachment.size / 1024).toFixed(1)} KB • Arquivo Digitalizado` 
                      : 'Assinado e validado através do protocolo municipal de Cutias-AP'}
                  </p>
                </div>
              </div>

              <button
                id="download-doc-btn"
                type="button"
                onClick={handleDownloadAttachment}
                className="w-full sm:w-auto bg-[#003366] hover:bg-blue-900 active:bg-blue-950 text-white font-bold py-1.5 px-3.5 rounded text-xs flex items-center justify-center gap-1.5 cursor-pointer transition-colors shrink-0 uppercase tracking-tight"
              >
                <Download className="w-3.5 h-3.5" />
                <span>{doc.attachment ? 'Baixar Anexo' : 'Baixar Certidão'}</span>
              </button>
            </div>

          </div>

          {/* Certificates block */}
          {doc.signatures && doc.signatures.length > 0 && (
            <div className="bg-emerald-50/20 border-2 border-dashed border-emerald-500 rounded p-5 space-y-3 relative overflow-hidden">
              <div className="flex items-center justify-between">
                <h3 className="font-sans font-black text-emerald-950 flex items-center gap-1.5 text-xs sm:text-sm uppercase tracking-wide">
                  <FileCheck2 className="w-5 h-5 text-emerald-700 shrink-0" />
                  <span>Assinaturas Digitais Coletadas ({doc.signatures.length})</span>
                </h3>
                <span className="text-[10px] font-extrabold uppercase bg-emerald-100 text-emerald-800 border border-emerald-300 rounded px-2 py-0.5">
                  ICP-Brasil Válido
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {doc.signatures.map((sig) => (
                  <div key={sig.id} className="bg-white border border-emerald-200 rounded p-3.5 space-y-2 shadow-xs">
                    <div className="flex items-center justify-between border-b border-slate-100 pb-1.5">
                      <span className="text-xs font-bold text-slate-800 uppercase">{sig.userName}</span>
                      <span className="text-[8.5px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded uppercase border border-emerald-150">
                        {sig.userRole}
                      </span>
                    </div>

                    <div className="text-[11px] text-[#003366] space-y-1">
                      <p>🏦 <strong>Departamento:</strong> <span className="text-slate-700">{sig.userDepartment}</span></p>
                      <p>💻 <strong>Autorizador:</strong> <span className="text-slate-700">{sig.certificateAuthority}</span></p>
                      <p>📡 <strong>Endereço IP:</strong> <span className="text-slate-700">{sig.ipAddress}</span></p>
                      <p className="text-[9.5px] text-[#003366] font-mono break-all bg-slate-50 p-1.5 rounded border border-slate-100 mt-1 select-all">
                        <strong>HASH:</strong> {sig.hash}
                      </p>
                    </div>

                    <div className="text-right">
                      <span className="text-[8.5px] font-bold text-slate-400 font-mono uppercase">
                        CARIMBO DE TEMPO: {formatDate(sig.signedAt, true)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Official reply from management if concluded */}
          {doc.response && (
            <div id="completed-response-block" className="bg-emerald-50/70 border border-emerald-300 rounded p-5 relative overflow-hidden">
              <div className="h-1 bg-emerald-600 absolute top-0 left-0 right-0"></div>
              
              <div className="flex items-center justify-between mb-2.5">
                <h3 className="font-sans font-bold text-emerald-950 flex items-center gap-1.5 text-xs sm:text-sm uppercase">
                  <CheckCircle className="w-4 h-4 text-emerald-700" />
                  Despacho de Resolução Administrativa
                </h3>
                <span className="text-[9px] font-mono text-emerald-700 bg-emerald-100 border border-emerald-300 rounded px-1.5 py-0.5 font-bold uppercase">
                  CONCLUÍDO
                </span>
              </div>

              <div className="bg-white border border-emerald-250 p-3 rounded space-y-2 shadow-xs">
                <div className="text-[10px] text-slate-500 flex justify-between">
                  <span>Autor: <strong className="font-bold text-slate-700">{doc.response.responder}</strong></span>
                  <span>Respondido em: <strong className="font-bold font-mono text-slate-700">{formatDate(doc.response.createdAt, true)}</strong></span>
                </div>
                <p className="text-xs text-slate-800 font-sans leading-relaxed whitespace-pre-wrap">
                  {doc.response.text}
                </p>
              </div>
            </div>
          )}

        </div>

        {/* Right Column: Dynamic Action Workflow Panel & Auditable Timeline */}
        <div className="space-y-4">
          
          {/* Action Box: Resp/Prorogation */}
          {liveStatus !== 'Concluído' ? (
            currentUser.role !== 'master' && !(doc.destination.toLowerCase().includes(currentUser.department.toLowerCase()) || 
              currentUser.department.toLowerCase().includes(doc.destination.toLowerCase()) ||
              currentUser.department.includes('GAB')) ? (
              <div className="bg-slate-50 border border-slate-200 rounded p-4 text-center space-y-2">
                <Lock className="w-5 h-5 text-slate-400 mx-auto" />
                <p className="text-xs font-extrabold text-slate-800 uppercase tracking-tight">Trâmite Restrito</p>
                <p className="text-[10px] text-slate-500 leading-normal font-sans">
                  Lotação do agente: <strong>{currentUser.department}</strong>.<br />
                  Apenas usuários de <strong>{doc.destination}</strong> estão autorizados a anexar despachos oficiais ou manifestações regimentais sobre esta demanda.
                </p>
              </div>
            ) : (
              <div className="bg-white rounded border border-slate-300 p-4 space-y-3">
                
                <div className="border-b border-slate-300 pb-2">
                  <h3 className="font-sans font-bold text-slate-900 text-xs sm:text-sm uppercase tracking-wide">Despachar Atendimento</h3>
                  <p className="text-[9px] text-slate-500 mt-0.5">Escolha o trâmite regimental</p>
                </div>

                {/* Responder button */}
                {!isResponding && !isExtending && (
                  <div className="space-y-1.5">
                    <button
                      id="despacho-responder-btn"
                      onClick={() => setIsResponding(true)}
                      className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-1.5 px-3 rounded text-xs flex items-center justify-center gap-1.5 cursor-pointer transition-all uppercase"
                    >
                      <Reply className="w-3.5 h-3.5" />
                      <span>Despachar Resposta</span>
                    </button>

                    <button
                      id="despacho-prorrogar-btn"
                      onClick={() => setIsExtending(true)}
                      className="w-full border border-slate-300 hover:bg-slate-50 text-slate-705 font-bold py-1.5 px-3 rounded text-xs flex items-center justify-center gap-1.5 cursor-pointer transition-all uppercase"
                    >
                      <CalendarDays className="w-3.5 h-3.5 text-slate-400" />
                      <span>Prorrogar Prazo</span>
                    </button>
                  </div>
                )}

                {/* Respond form fields */}
                {isResponding && (
                  <form onSubmit={handleSendResponse} className="space-y-2.5 animate-in fade-in-50 duration-200">
                    <div className="flex items-center justify-between text-[10px] font-bold text-slate-700 uppercase">
                      <span>Instruções da Devolução</span>
                      <button 
                        type="button" 
                        onClick={() => setIsResponding(false)}
                        className="text-red-750 hover:underline font-normal cursor-pointer"
                      >
                        Cancelar
                      </button>
                    </div>

                    <textarea
                      id="despacho-response-content"
                      required
                      rows={4}
                      placeholder="Redija os termos da sua manifestação oficial..."
                      value={responseText}
                      onChange={(e) => setResponseText(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded p-2 text-xs focus:outline-none focus:border-[#003366] font-sans"
                    ></textarea>

                    <button
                      id="submit-despacho-btn"
                      type="submit"
                      className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-1.5 px-2 rounded text-xs flex items-center justify-center gap-1 transition-colors cursor-pointer uppercase"
                    >
                      <FileCheck2 className="w-3.5 h-3.5" />
                      <span>Concluir e Devolver</span>
                    </button>
                  </form>
                )}

                {/* Prorrogate Form fields */}
                {isExtending && (
                  <form onSubmit={handleExtendDeadline} className="space-y-2.5 animate-in fade-in-50 duration-200">
                    <div className="flex items-center justify-between text-[10px] font-bold text-slate-700 uppercase">
                      <span>Estender Prazo de Atendimento</span>
                      <button 
                        type="button" 
                        onClick={() => setIsExtending(false)}
                        className="text-red-750 hover:underline font-normal cursor-pointer"
                      >
                        Cancelar
                      </button>
                    </div>

                    <div>
                      <label className="text-[9px] text-slate-450 block mb-0.5 font-bold uppercase tracking-wider">Acréscimo Solicitado</label>
                      <select
                        id="despacho-days-select"
                        value={extensionDays}
                        onChange={(e) => setExtensionDays(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 text-xs focus:outline-none font-bold"
                      >
                        <option value="3">+3 Dias Úteis</option>
                        <option value="5">+5 Dias Úteis</option>
                        <option value="10">+10 Dias Úteis</option>
                        <option value="15">+15 Dias Úteis</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[9px] text-slate-450 block mb-0.5 font-bold uppercase tracking-wider">Justificativa Técnica *</label>
                      <textarea
                        id="despacho-reason-input"
                        required
                        rows={3}
                        placeholder="Motivo de força maior, indisponibilidade ou exame de parecer jurífico..."
                        value={extensionReason}
                        onChange={(e) => setExtensionReason(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-300 rounded p-2 text-xs focus:outline-none"
                      ></textarea>
                    </div>

                    <button
                      id="submit-extension-btn"
                      type="submit"
                      className="w-full bg-orange-600 hover:bg-orange-700 text-white font-bold py-1.5 px-2 rounded text-xs flex items-center justify-center gap-1 transition-colors cursor-pointer uppercase"
                    >
                      <span>Salvar Prorrogação</span>
                    </button>
                  </form>
                )}

              </div>
            )
          ) : (
            <div className="bg-slate-50 border border-slate-300 rounded p-4 text-center space-y-1.5">
              <Lock className="w-6 h-6 text-[#003366] mx-auto" />
              <p className="text-xs font-bold text-slate-800 uppercase tracking-tight">Trâmite Finalizado</p>
              <p className="text-[10px] text-slate-500 leading-normal">
                Este expediente já recebeu parecer final de conclusão e está arquivado. Modificações bloqueadas de acordo com as diretrizes do portal DOC Cutias-AP.
              </p>
            </div>
          )}

          {/* Audit Trail: Timeline events (Histórico do Documento) */}
          <div className="bg-white rounded border border-slate-300 p-4 space-y-3">
            
            <div className="flex items-center gap-1.5 border-b border-slate-300 pb-2">
              <History className="w-3.5 h-3.5 text-slate-500" />
              <h3 className="font-sans font-bold text-slate-905 text-xs uppercase tracking-wide">Histórico de Movimentações</h3>
            </div>

            <div className="space-y-3 relative before:absolute before:bottom-1 before:top-1 before:left-2 before:w-0.5 before:bg-slate-200">
              {doc.history.map((hist) => (
                <div key={hist.id} className="flex gap-2 relative text-xs items-start pl-1">
                  
                  {/* Timeline bullet representer */}
                  <div className="w-4 h-4 bg-white rounded-full border border-slate-400 flex items-center justify-center shrink-0 z-10 mt-0.5">
                    <div className="w-1.5 h-1.5 rounded-full bg-[#003366]"></div>
                  </div>

                  <div className="space-y-0.5 min-w-0 flex-1">
                    <p className="font-bold text-slate-800 text-[11px] leading-tight uppercase tracking-tight">{hist.action}</p>
                    <p className="text-[9px] text-slate-405 font-mono font-bold leading-none">{formatDate(hist.date, true)}</p>
                    <p className="text-[10px] text-slate-600 italic">
                      Por: <span className="font-semibold text-slate-800">{hist.user}</span>
                    </p>
                    {hist.notes && (
                      <p className="text-[10px] text-slate-655 bg-slate-50 p-1.5 border border-slate-200 rounded leading-relaxed mt-1 whitespace-pre-wrap font-sans">
                        {hist.notes}
                      </p>
                    )}
                  </div>

                </div>
              ))}
            </div>

          </div>

        </div>

      </div>

    </div>
  );
}
