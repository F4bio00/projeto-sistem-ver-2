/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { 
  Send, 
  Paperclip, 
  Trash2, 
  CalendarDays, 
  AlertCircle, 
  FileCheck, 
  Printer, 
  Download,
  CheckCircle2,
  FileText
} from 'lucide-react';
import { DEPARTMENTS, Document, DocumentType, PriorityType, Attachment, AppUser } from '../types';
import { generateProtocol, TODAY_DATE, formatDate, downloadFile } from '../utils';

interface DocumentFormProps {
  onAddDocument: (doc: Document) => void;
  currentUser: AppUser;
}

export default function DocumentForm({ onAddDocument, currentUser }: DocumentFormProps) {
  // Form fields state
  const [title, setTitle] = useState('');
  const [type, setType] = useState<DocumentType>('Memorando');
  const [origin, setOrigin] = useState(currentUser.department);
  
  // Keep origin in sync with logged-in user mutations
  React.useEffect(() => {
    setOrigin(currentUser.department);
  }, [currentUser]);
  const [destination, setDestination] = useState(DEPARTMENTS[2].name); // SEMOF default
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState<PriorityType>('Média');
  const [deadlineDays, setDeadlineDays] = useState('7'); // preset days
  const [customDeadline, setCustomDeadline] = useState('');
  const [attachment, setAttachment] = useState<Attachment | null>(null);
  
  // Drag and drop states
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Success Protocol Modal State
  const [createdDoc, setCreatedDoc] = useState<Document | null>(null);
  const [showProtocolModal, setShowProtocolModal] = useState(false);

  // States for sub-tab and standard template model settings
  const [activeSubTab, setActiveSubTab] = useState<'create' | 'template'>('create');
  
  const [templateTitle, setTemplateTitle] = useState(() => {
    return localStorage.getItem('doc_template_title') || 'Requisição de Manutenção Predial Extrema - Prédio Administrativo';
  });
  const [templateDescription, setTemplateDescription] = useState(() => {
    return localStorage.getItem('doc_template_description') || 'Cumprimentando-o cordialmente, sirvo-me do presente para solicitar a reforma e pintura interna das salas anexas de protocolo, visando oferecer condições condignas de trabalho aos servidores municipais e melhor acolhimento aos munícipes de Cutias que nos visitam diariamente. Alertamos que há focos de fissura que necessitam engenharia de reparos urgente.';
  });
  const [templatePriority, setTemplatePriority] = useState<PriorityType>(() => {
    return (localStorage.getItem('doc_template_priority') as PriorityType) || 'Alta';
  });
  const [templateDeadlineDays, setTemplateDeadlineDays] = useState(() => {
    return localStorage.getItem('doc_template_deadline_days') || '5';
  });
  const [templateAttachmentName, setTemplateAttachmentName] = useState(() => {
    return localStorage.getItem('doc_template_attachment_name') || 'memorando_modelo_reforma_predial.pdf';
  });
  const [templateSuccessMsg, setTemplateSuccessMsg] = useState(false);

  const handleSaveTemplate = (e: React.FormEvent) => {
    e.preventDefault();
    localStorage.setItem('doc_template_title', templateTitle);
    localStorage.setItem('doc_template_description', templateDescription);
    localStorage.setItem('doc_template_priority', templatePriority);
    localStorage.setItem('doc_template_deadline_days', templateDeadlineDays);
    localStorage.setItem('doc_template_attachment_name', templateAttachmentName);
    
    setTemplateSuccessMsg(true);
    setTimeout(() => {
      setTemplateSuccessMsg(false);
    }, 4000);
  };

  // Calculate actual expiration date in real time
  const getExpirationDate = (): string => {
    if (customDeadline) return customDeadline;
    const days = parseInt(deadlineDays) || 7;
    const date = new Date(TODAY_DATE);
    date.setDate(date.getDate() + days);
    return date.toISOString().split('T')[0];
  };

  // Process selected files
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const processFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target && event.target.result) {
        setAttachment({
          name: file.name,
          type: file.type,
          size: file.size,
          data: event.target.result as string
        });
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const removeAttachment = () => {
    setAttachment(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Populate sample official document template
  const applyTemplate = () => {
    setTitle(templateTitle);
    setDescription(templateDescription);
    setPriority(templatePriority);
    setDeadlineDays(templateDeadlineDays);
    
    // Set a simulated template file
    setAttachment({
      name: templateAttachmentName,
      type: 'application/pdf',
      size: 48500,
      data: 'JVBERi0xLjQKJ...[CONTEÚDO SIMULADO EM BASE64 DE DOCUMENTO MODELO]'
    });
  };

  // Form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim()) {
      alert('Por favor, preencha todos os campos obrigatórios.');
      return;
    }

    const protocol = generateProtocol();
    const expDate = getExpirationDate();

    const newDoc: Document = {
      id: `doc-${Date.now()}`,
      protocol,
      title,
      type,
      origin,
      destination,
      description,
      createdAt: new Date().toISOString(),
      deadlineDate: expDate,
      priority,
      status: 'Pendente',
      attachment: attachment || undefined,
      history: [
        {
          id: `h-init-${Date.now()}`,
          date: new Date().toISOString(),
          user: `${currentUser.name} (${currentUser.role === 'gestor' ? 'Gestor' : 'Servidor'} - ${currentUser.department})`,
          action: 'Documento PROTOCOLADO',
          notes: `Envio efetuado via Portal de Documentação por lotação remetente da prefeitura.`
        }
      ]
    };

    onAddDocument(newDoc);
    setCreatedDoc(newDoc);
    setShowProtocolModal(true);

    // Reset Form
    setTitle('');
    setDescription('');
    setAttachment(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Triggers downloading the receipt as a formatted TXT card
  const handleDownloadReceipt = () => {
    if (!createdDoc) return;
    const receiptText = `
=============================================
         MUNICÍPIO DE CUTIAS - AMAPÁ
   DOC - COMPROVANTE DE PROTOCOLO DIGITAL
=============================================
Protocolo N°:   ${createdDoc.protocol}
Data do Envio:  ${formatDate(createdDoc.createdAt, true)}
Tipo/Assunto:   ${createdDoc.type} - ${createdDoc.title}
Origem:         ${createdDoc.origin}
Destino:        ${createdDoc.destination}
Prazo Limite:   ${formatDate(createdDoc.deadlineDate)}
Prioridade:     ${createdDoc.priority}

Descrição:      ${createdDoc.description}
Anexado:        ${createdDoc.attachment ? createdDoc.attachment.name : 'Nenhum'}

Validação Eletrônica efetuada pelo DOC Cutias.
Acesse o portal para acompanhar o andamento.
=============================================`;
    
    downloadFile(`comprovante_${createdDoc.protocol}.txt`, receiptText);
  };

  return (
    <div className="bg-white rounded border border-slate-300 p-5 max-w-4xl mx-auto space-y-4">
      
      {/* Form Header */}
      <div className="flex justify-between items-start gap-3 pb-2 border-b border-slate-200">
        <div>
          <h2 id="form-title" className="font-sans font-bold text-slate-900 text-sm tracking-tight flex items-center gap-1.5 uppercase">
            <FileText className="w-4 h-4 text-[#003366]" />
            Tramitação e Gestão de Modelos
          </h2>
          <p className="text-[10px] text-slate-500 mt-0.5">
            Instaure novos protocolos oficiais ou gerencie os metadados do modelo de ofício padrão adotado pela prefeitura.
          </p>
        </div>
      </div>

      {/* Sub-tabs Navigation */}
      <div className="flex border-b border-slate-200 gap-1 select-none">
        <button
          type="button"
          onClick={() => setActiveSubTab('create')}
          className={`px-4 py-2 text-xs font-bold uppercase tracking-wider border-b-2 transition-all cursor-pointer ${
            activeSubTab === 'create'
              ? 'border-[#003366] text-[#003366] bg-slate-50/50'
              : 'border-transparent text-slate-500 hover:text-slate-800 hover:bg-slate-50/20'
          }`}
        >
          📝 Instaurar Trâmite
        </button>
        <button
          type="button"
          onClick={() => setActiveSubTab('template')}
          className={`px-4 py-2 text-xs font-bold uppercase tracking-wider border-b-2 transition-all cursor-pointer ${
            activeSubTab === 'template'
              ? 'border-amber-600 text-amber-700 bg-amber-50/20'
              : 'border-transparent text-slate-500 hover:text-slate-800 hover:bg-slate-50/20'
          }`}
        >
          ⚙️ Editar Modelo Ofício Padrão
        </button>
      </div>

      {activeSubTab === 'create' && (
        <form onSubmit={handleSubmit} className="space-y-4 animate-fade-in">
          
          {/* Apply Template Banner */}
          <div className="bg-blue-50/55 border border-blue-200 rounded p-3 flex justify-between items-center gap-3">
            <div className="space-y-0.5">
              <span className="text-[10px] uppercase font-extrabold text-[#003366] block">Aceleração de Preenchimento</span>
              <p className="text-[10px] text-slate-600 leading-normal">Carregue o cabeçalho e descrição do Ofício Padrão oficial homologado pela secretaria.</p>
            </div>
            <button
              type="button"
              onClick={applyTemplate}
              className="text-[10px] border border-blue-400/50 text-[#003366] bg-white hover:bg-blue-100 font-extrabold px-3 py-1.5 rounded shadow-2xs transition-all cursor-pointer flex items-center gap-1 shrink-0"
              title="Aplica instantaneamente as configurações de modelo de ofício vigentes."
            >
              <span>📄 Aplicar Modelo Ofício Padrão</span>
            </button>
          </div>

          {/* Core Dropdowns: Type, Origin, Destination */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            
            <div>
              <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wide mb-1">Gênero do Documento *</label>
              <select
                id="form-type-select"
                value={type}
                onChange={(e) => setType(e.target.value as DocumentType)}
                className="w-full bg-slate-50 border border-slate-300 text-slate-800 text-xs rounded p-2 focus:outline-none focus:border-[#003366] focus:bg-white transition-all font-medium"
              >
                <option value="Memorando">📝 Memorando Interno</option>
                <option value="Ofício">✉️ Ofício de Expediente</option>
                <option value="Requerimento">⚖️ Requerimento</option>
                <option value="Portaria">📜 Portaria Oficial</option>
                <option value="Circular">🎯 Circular Normativo</option>
                <option value="Comunicação Interna">📢 Comunicação Interna</option>
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wide mb-1">Setor Remetente (Vinculado ao Login)</label>
              <input
                id="form-origin-select"
                type="text"
                value={origin}
                disabled
                className="w-full bg-slate-100 border border-slate-300 text-slate-500 text-xs rounded p-2 cursor-not-allowed font-bold font-sans"
              />
            </div>

            <div>
              <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wide mb-1">Setor Destinatário *</label>
              <select
                id="form-dest-select"
                value={destination}
                onChange={(e) => setDestination(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 text-slate-800 text-xs rounded p-2 focus:outline-none focus:border-[#003366] focus:bg-white transition-all font-medium"
              >
                {DEPARTMENTS.map((dept) => (
                  <option key={`dest-${dept.id}`} value={`${dept.name} (${dept.acronym})`}>
                    🏢 {dept.acronym} - {dept.name}
                  </option>
                ))}
              </select>
            </div>

          </div>

          {/* Title */}
          <div>
            <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wide mb-1">Assunto Geral do Envio *</label>
            <input
              id="form-title-input"
              type="text"
              required
              placeholder="Ex: Encaminhamento de laudo de fiscalização sanitária"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 text-slate-800 text-xs rounded p-2 focus:outline-none focus:border-[#003366] focus:bg-white transition-all font-semibold"
            />
          </div>

          {/* Big content editor */}
          <div>
            <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wide mb-1">Teor da Comunicação / Despacho e Justificativas *</label>
            <textarea
              id="form-description-input"
              required
              rows={4}
              placeholder="Redija aqui os termos regimentais oficiais de solicitação de providências..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 text-slate-850 text-xs rounded p-2 focus:outline-none focus:border-[#003366] focus:bg-white transition-all font-sans leading-relaxed"
            ></textarea>
          </div>

          {/* Priority & Deadline controls */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-3 bg-slate-50 rounded border border-slate-300">
            
            <div>
              <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wide mb-1.5">Grau de Prioridade Regimental</label>
              <div className="grid grid-cols-4 gap-1.5">
                {(['Baixa', 'Média', 'Alta', 'Urgente'] as PriorityType[]).map((prio) => {
                  let activeClass = '';
                  if (priority === prio) {
                    if (prio === 'Baixa') activeClass = 'bg-slate-700 text-white border-slate-800';
                    if (prio === 'Média') activeClass = 'bg-[#003366] text-white border-[#002244] font-bold shadow-xs';
                    if (prio === 'Alta') activeClass = 'bg-orange-600 text-white border-orange-750 font-bold shadow-xs';
                    if (prio === 'Urgente') activeClass = 'bg-red-600 text-white border-red-750 font-bold animate-pulse';
                  } else {
                    activeClass = 'bg-white hover:bg-slate-100 text-slate-650 border-slate-300';
                  }

                  return (
                    <button
                      key={prio}
                      type="button"
                      onClick={() => setPriority(prio)}
                      className={`text-[11px] font-bold py-1.5 border rounded transition-all cursor-pointer ${activeClass}`}
                    >
                      {prio}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Deadline control (Prazo) */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-[10px] font-bold text-slate-700 uppercase tracking-wide">Prazo Resolução DOC</label>
                <span className="text-[9px] text-[#003366] font-extrabold flex items-center gap-0.5 uppercase bg-blue-50 px-1 border border-blue-200 rounded">
                  <CalendarDays className="w-3 h-3 text-blue-650" />
                  Limite: {formatDate(getExpirationDate())}
                </span>
              </div>

              <div className="grid grid-cols-5 gap-1">
                {[
                  { label: '3 dias', val: '3' },
                  { label: '5 dias', val: '5' },
                  { label: '7 dias', val: '7' },
                  { label: '15 dias', val: '15' },
                  { label: 'Data Fixa', val: 'custom' }
                ].map((timeOpt) => {
                  const isSelected = timeOpt.val === 'custom' ? customDeadline !== '' : deadlineDays === timeOpt.val && !customDeadline;
                  
                  return (
                    <button
                      key={timeOpt.val}
                      type="button"
                      onClick={() => {
                        if (timeOpt.val === 'custom') {
                          setCustomDeadline(new Date(TODAY_DATE).toISOString().split('T')[0]);
                        } else {
                          setDeadlineDays(timeOpt.val);
                          setCustomDeadline('');
                        }
                      }}
                      className={`text-[10px] font-bold py-1.5 border rounded transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-[#003366] text-white border-[#002244]'
                          : 'bg-white hover:bg-slate-150 text-slate-650 border-slate-300'
                      }`}
                    >
                      {timeOpt.label}
                    </button>
                  );
                })}
              </div>

              {customDeadline !== '' && (
                <input
                  id="form-deadline-custom"
                  type="date"
                  required
                  min={TODAY_DATE}
                  value={customDeadline}
                  onChange={(e) => setCustomDeadline(e.target.value)}
                  className="mt-2 w-full bg-white border border-slate-300 text-slate-800 text-xs rounded p-1.5 focus:outline-none focus:border-[#003366] text-center font-mono font-bold"
                />
              )}
            </div>

          </div>

          {/* Real File Attachment Area */}
          <div>
            <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wide mb-1">Anexar Documento Escaneado (Peça de Instrução)</label>
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={`border-2 border-dashed rounded p-4 text-center transition-all ${
                isDragging 
                  ? 'border-[#003366] bg-blue-50/20' 
                  : attachment 
                    ? 'border-blue-400 bg-blue-50/10' 
                    : 'border-slate-300 hover:border-slate-400 bg-slate-50/30'
              }`}
            >
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                className="hidden"
                accept=".pdf,.doc,.docx,.jpg,.png,.txt,.xlsx"
              />

              {attachment ? (
                <div className="flex items-center justify-between bg-white border border-slate-300 p-2 rounded shadow-xs max-w-lg mx-auto">
                  <div className="flex items-center gap-2.5 text-left min-w-0">
                    <div className="p-2 bg-blue-50 text-[#003366] rounded border border-blue-200">
                      <Paperclip className="w-3.5 h-3.5" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-slate-800 truncate">{attachment.name}</p>
                      <p className="text-[9px] text-slate-405">{(attachment.size / 1024).toFixed(1)} KB • Arquivado Base64</p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={removeAttachment}
                    className="p-1 text-slate-405 hover:text-red-750 hover:bg-red-50 rounded transition-colors cursor-pointer"
                    title="Excluir anexo"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : (
                <div className="space-y-1 cursor-pointer" onClick={() => fileInputRef.current?.click()}>
                  <Paperclip className="w-6 h-6 text-slate-450 mx-auto" />
                  <p className="text-xs font-bold text-slate-700">
                    Arraste arquivos ou <span className="text-[#003366] underline hover:text-blue-800">clique aqui para anexar</span>
                  </p>
                  <p className="text-[9px] text-slate-450">Suporta PDF, DOCX, Imagens e planilhas até 5MB</p>
                </div>
              )}
            </div>
          </div>

          {/* Disclaimer of digital validity */}
          <div className="flex items-start gap-2.5 bg-amber-50 border border-amber-250 p-2.5 rounded">
            <AlertCircle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
            <p className="text-[10px] text-amber-900 leading-normal">
              <strong>DECLARAÇÃO DE VALIDADE:</strong> Em conformidade com o regimento interno de Cutias-AP, o envio por este portal confere fé pública e certificação de autoria ao servidor logado, dispensando autenticação de cartório físico.
            </p>
          </div>

          {/* Submit */}
          <div className="flex justify-end pt-1">
            <button
               id="form-submit-btn"
               type="submit"
               className="bg-[#003366] hover:bg-blue-900 active:bg-blue-950 text-white font-bold py-2 px-5 rounded flex items-center justify-center gap-1.5 shadow-sm cursor-pointer transition-colors w-full sm:w-auto text-xs uppercase"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Gerar Protocolo Eletrônico</span>
            </button>
          </div>

        </form>
      )}

      {activeSubTab === 'template' && (
        <form onSubmit={handleSaveTemplate} className="space-y-4 pt-1 animate-fade-in text-xs">
          
          <div className="bg-amber-50 border border-amber-200 rounded p-3 text-amber-910 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div className="space-y-0.5">
              <span className="font-extrabold uppercase text-[10px]">Editor de Ofício Modelo Extensível</span>
              <p className="text-[10px] leading-relaxed text-slate-600">
                Personalize os valores do template geral da comarca. Os dados salvos aqui serão aplicados de forma pré-definida no formulário de envio assim que qualquer servidor acionar o botão <strong>"Aplicar Modelo Ofício Padrão"</strong>.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Input fields */}
            <div className="space-y-3">
              <div>
                <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wide mb-1">Título Padrão do Ofício *</label>
                <input
                  type="text"
                  required
                  placeholder="Defina o título padrão do modelo"
                  value={templateTitle}
                  onChange={(e) => setTemplateTitle(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 text-slate-800 text-xs rounded p-2 focus:outline-none focus:border-amber-600 focus:bg-white transition-all font-semibold"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wide mb-1">Nome de Anexo Físico Simulado (PDF)</label>
                <input
                  type="text"
                  required
                  placeholder="Ex: modelo_oficial_memorando.pdf"
                  value={templateAttachmentName}
                  onChange={(e) => setTemplateAttachmentName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 text-slate-800 text-xs rounded p-2 focus:outline-none focus:border-amber-600 focus:bg-white transition-all font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wide mb-1">Prioridade Sugerida</label>
                  <select
                    value={templatePriority}
                    onChange={(e) => setTemplatePriority(e.target.value as PriorityType)}
                    className="w-full bg-slate-50 border border-slate-300 text-slate-800 text-xs rounded p-2 focus:outline-none focus:border-amber-605 focus:bg-white font-semibold"
                  >
                    <option value="Baixa">🟢 Baixa</option>
                    <option value="Média">🔵 Média</option>
                    <option value="Alta">🟠 Alta</option>
                    <option value="Urgente">🔴 Urgente</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wide mb-1">Tempo Limite Padrão</label>
                  <select
                    value={templateDeadlineDays}
                    onChange={(e) => setTemplateDeadlineDays(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 text-slate-800 text-xs rounded p-2 focus:outline-none focus:border-amber-605 focus:bg-white font-semibold"
                  >
                    <option value="3">3 dias úteis</option>
                    <option value="5">5 dias úteis</option>
                    <option value="7">7 dias úteis</option>
                    <option value="15">15 dias úteis</option>
                  </select>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-3 flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    if (confirm("Deseja restaurar o modelo oficial de fábrica (Reforma e Manutenção Predial)?")) {
                      setTemplateTitle('Requisição de Manutenção Predial Extrema - Prédio Administrativo');
                      setTemplateDescription('Cumprimentando-o cordialmente, sirvo-me do presente para solicitar a reforma e pintura interna das salas anexas de protocolo, visando oferecer condições condignas de trabalho aos servidores municipais e melhor acolhimento aos munícipes de Cutias que nos visitam diariamente. Alertamos que há focos de fissura que necessitam engenharia de reparos urgente.');
                      setTemplatePriority('Alta');
                      setTemplateDeadlineDays('5');
                      setTemplateAttachmentName('memorando_modelo_reforma_predial.pdf');
                    }
                  }}
                  className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-[10px] font-bold uppercase rounded cursor-pointer transition-colors border border-slate-300 flex-1 text-center"
                >
                  Restaurar Original
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white text-[10px] font-extrabold uppercase rounded shadow-2xs cursor-pointer transition-colors flex-1 text-center"
                >
                  Confirmar Alterações
                </button>
              </div>

              {templateSuccessMsg && (
                <div className="bg-emerald-50 border border-emerald-300 text-emerald-800 p-2.5 rounded text-[10px] font-bold animate-pulse text-center">
                  ✔️ Alterações memorizadas com sucesso! Pronto para tramitação.
                </div>
              )}
            </div>

            {/* Description editing and live mockups preview */}
            <div className="space-y-3">
              <div>
                <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wide mb-1">Teor / Conteúdo Oficial do Modelo *</label>
                <textarea
                  required
                  rows={4}
                  placeholder="Escreva os termos regimentais preenchidos por padrão"
                  value={templateDescription}
                  onChange={(e) => setTemplateDescription(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 text-slate-800 text-xs rounded p-2 focus:outline-none focus:border-amber-600 focus:bg-white transition-all font-sans leading-relaxed resize-none h-[116px]"
                />
              </div>

              {/* Dynamic visualization */}
              <div className="bg-slate-900 text-slate-100 rounded border border-slate-800 p-3 space-y-1.5 font-mono text-[9px] leading-relaxed shadow-inner">
                <span className="text-[8px] font-bold bg-amber-600/20 text-amber-400 px-1.5 py-0.5 rounded border border-amber-500/20 uppercase tracking-wider block w-fit">PRÉ-VISUALIZAÇÃO EM TEMPO REAL</span>
                <p className="truncate text-slate-400"><span className="font-bold text-slate-350">ASSUNTO:</span> {templateTitle || 'Sem assunto'}</p>
                <p className="line-clamp-2 text-slate-300"><span className="font-bold text-slate-350">DESCRIÇÃO:</span> {templateDescription || 'Sem conteúdo'}</p>
                <div className="grid grid-cols-2 gap-1 text-[8px] font-mono border-t border-slate-820 pt-1 text-slate-400">
                  <span>EXPIRAÇÃO: {templateDeadlineDays} dias</span>
                  <span>PRIORIDADE: {templatePriority.toUpperCase()}</span>
                  <span className="col-span-2 truncate">ARQUIVO: {templateAttachmentName}</span>
                </div>
              </div>
            </div>

          </div>

        </form>
      )}

      {/* Protocol Modal Success */}
      {showProtocolModal && createdDoc && (
        <div id="protocol-modal" className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded max-w-md w-full p-5 shadow-xl border border-slate-300 animate-in fade-in zoom-in-95 duration-200">
            
            <div className="text-center space-y-1.5">
              <div className="w-10 h-10 bg-emerald-50 text-emerald-700 rounded-full flex items-center justify-center mx-auto border border-emerald-350">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-slate-900 uppercase">PROTOCOLO GERADO COM SUCESSO!</h3>
              <p className="text-[11px] text-slate-500 max-w-sm mx-auto">
                O documento foi catalogado na base geral da Prefeitura de Cutias (AP).
              </p>
            </div>

            {/* Protocol Voucher Details Block */}
            <div className="my-4 p-3 bg-slate-50 rounded border border-slate-350 space-y-2.5 font-mono text-[11px]">
              
              <div className="flex justify-between items-center pb-1.5 border-b border-dashed border-slate-300">
                <span className="text-slate-450 font-sans font-bold text-[9px]">CÓDIGO PROTOCOLO:</span>
                <strong className="text-slate-900 text-xs font-bold tracking-wider bg-slate-200/80 px-1.5 py-0.5 border border-slate-300 rounded">{createdDoc.protocol}</strong>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[10px]">
                <div>
                  <span className="text-slate-450 font-sans font-bold text-[9px] block">DATA PROTOCOLAGEM:</span>
                  <span className="text-slate-800 font-bold">{formatDate(createdDoc.createdAt, true)}</span>
                </div>
                <div>
                  <span className="text-slate-450 font-sans font-bold text-[9px] block">DOCUMENTO DE CLASSE:</span>
                  <span className="text-slate-800 font-bold uppercase">{createdDoc.type}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[10px] pt-1">
                <div>
                  <span className="text-slate-450 font-sans font-bold text-[9px] block">REP. ORIGEM:</span>
                  <span className="text-slate-800 font-bold truncate block">{createdDoc.origin}</span>
                </div>
                <div>
                  <span className="text-slate-450 font-sans font-bold text-[9px] block">REP. DESTINO:</span>
                  <span className="text-slate-800 font-bold truncate block">{createdDoc.destination}</span>
                </div>
              </div>

              <div className="pt-2 border-t border-dashed border-slate-300 text-[10px] flex justify-between font-bold">
                <span className="text-slate-455 font-sans font-bold text-[9px]">EXPIRAÇÃO IMPOSIÇÃO DE PRAZO:</span>
                <span className="text-red-750">{formatDate(createdDoc.deadlineDate)}</span>
              </div>

            </div>

            {/* Actions for output printed */}
            <div className="grid grid-cols-2 gap-2">
              <button
                id="modal-download-receipt"
                type="button"
                onClick={handleDownloadReceipt}
                className="flex items-center justify-center gap-1.5 border border-slate-300 hover:bg-slate-50 text-slate-700 font-bold py-2 rounded text-xs cursor-pointer transition-all"
              >
                <Download className="w-3.5 h-3.5 text-[#003366]" />
                <span>Download Recibo</span>
              </button>
              <button
                id="modal-print-btn"
                type="button"
                onClick={() => window.print()}
                className="flex items-center justify-center gap-1.5 border border-slate-300 hover:bg-slate-50 text-slate-700 font-bold py-2 rounded text-xs cursor-pointer transition-all"
              >
                <Printer className="w-3.5 h-3.5 text-slate-500" />
                <span>Imprimir Via</span>
              </button>
            </div>

            <button
              id="modal-close-btn"
              type="button"
              onClick={() => {
                setShowProtocolModal(false);
                setCreatedDoc(null);
              }}
              className="mt-3.5 w-full bg-[#003366] hover:bg-blue-900 text-white font-bold py-2 rounded text-xs transition-colors cursor-pointer text-center uppercase"
            >
              Liberar Painel de Envio
            </button>

          </div>
        </div>
      )}

    </div>
  );
}
