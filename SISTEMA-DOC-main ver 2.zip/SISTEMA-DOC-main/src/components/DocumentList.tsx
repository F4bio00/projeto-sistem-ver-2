/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Search, 
  SlidersHorizontal, 
  Calendar, 
  FileText, 
  AlertTriangle, 
  CheckCircle, 
  Clock, 
  Paperclip,
  TrendingUp,
  ArrowUpDown,
  PenTool
} from 'lucide-react';
import { Document, DocumentStatus, DocumentType, PriorityType } from '../types';
import { getRemainingDays, getLiveStatus, formatDate } from '../utils';

interface DocumentListProps {
  documents: Document[];
  selectedDept: string;
  onViewDoc: (id: string) => void;
  initialFilterStatus: DocumentStatus | 'All';
}

export default function DocumentList({
  documents,
  selectedDept,
  onViewDoc,
  initialFilterStatus
}: DocumentListProps) {
  // Search and filter options
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<DocumentStatus | 'All'>(initialFilterStatus);
  const [typeFilter, setTypeFilter] = useState<DocumentType | 'All'>('All');
  const [priorityFilter, setPriorityFilter] = useState<PriorityType | 'All'>('All');
  const [sortBy, setSortBy] = useState<'createdAt' | 'deadlineDate'>('createdAt');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [showFilters, setShowFilters] = useState(false);

  // Sync initial status filter if it changes from father (clicking the dash card stats)
  React.useEffect(() => {
    setStatusFilter(initialFilterStatus);
  }, [initialFilterStatus]);

  // Apply Department and interactive Filters
  const processedDocs = documents
    .filter((doc) => {
      // Setor filter
      if (selectedDept !== 'all') {
        const checkOrigin = doc.origin.toLowerCase().includes(selectedDept.toLowerCase());
        const checkDest = doc.destination.toLowerCase().includes(selectedDept.toLowerCase());
        if (!checkOrigin && !checkDest) return false;
      }

      // Search filters
      const searchLower = searchTerm.toLowerCase();
      const matchesSearch = 
        doc.protocol.toLowerCase().includes(searchLower) ||
        doc.title.toLowerCase().includes(searchLower) ||
        doc.description.toLowerCase().includes(searchLower) ||
        doc.origin.toLowerCase().includes(searchLower) ||
        doc.destination.toLowerCase().includes(searchLower);

      if (!matchesSearch) return false;

      // Status filters
      const liveStatus = getLiveStatus(doc);
      if (statusFilter !== 'All' && liveStatus !== statusFilter) return false;

      // Type filter
      if (typeFilter !== 'All' && doc.type !== typeFilter) return false;

      // Priority filter
      if (priorityFilter !== 'All' && doc.priority !== priorityFilter) return false;

      return true;
    })
    .sort((a, b) => {
      let comparison = 0;
      if (sortBy === 'createdAt') {
        comparison = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      } else {
        comparison = new Date(a.deadlineDate).getTime() - new Date(b.deadlineDate).getTime();
      }
      return sortOrder === 'desc' ? -comparison : comparison;
    });

  const toggleSortOrder = () => {
    setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
  };

  // Helper styles for Priorities
  const getPriorityStyle = (prio: PriorityType) => {
    switch (prio) {
      case 'Baixa': return 'bg-slate-100 text-slate-700 border-slate-200';
      case 'Média': return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'Alta': return 'bg-orange-50 text-orange-700 border-orange-200';
      case 'Urgente': return 'bg-red-50 text-red-700 border-red-250 font-bold';
    }
  };

  // Helper styles for Statuses
  const getStatusStyle = (status: DocumentStatus) => {
    switch (status) {
      case 'Pendente': return 'bg-sky-100 text-sky-800 border-sky-250';
      case 'Em Análise': return 'bg-amber-100 text-amber-850 border-amber-250';
      case 'Atrasado': return 'bg-rose-105 text-rose-800 border-rose-300';
      case 'Concluído': return 'bg-emerald-100 text-emerald-800 border-emerald-300';
    }
  };

  return (
    <div className="space-y-3">
      
      {/* Search Header and quick filters */}
      <div className="bg-white p-3.5 rounded border border-slate-300 space-y-2.5">
        
        <div className="flex flex-col sm:flex-row gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-slate-450" />
            <input
              id="list-search-input"
              type="text"
              placeholder="Filtro rápido por Protocolo, Setor, Assunto ou teor informativo..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded pl-8 pr-3 py-1.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-[#003366] focus:bg-white transition-all font-medium"
            />
          </div>

          <div className="flex gap-2">
            <button
              id="list-filter-toggle"
              type="button"
              onClick={() => setShowFilters(!showFilters)}
              className={`flex items-center gap-1 px-2.5 py-1.5 border rounded text-xs font-bold cursor-pointer transition-colors ${
                showFilters || statusFilter !== 'All' || typeFilter !== 'All' || priorityFilter !== 'All'
                  ? 'bg-blue-50 text-[#003366] border-blue-400'
                  : 'bg-white text-slate-700 hover:bg-slate-50 border-slate-300'
              }`}
            >
              <SlidersHorizontal className="w-3 h-3 text-slate-500" />
              <span>Parametrizar {showFilters ? 'Ativo' : 'Busca'}</span>
            </button>

            <button
              id="list-sort-btn"
              type="button"
              onClick={toggleSortOrder}
              className="flex items-center gap-1 px-2.5 py-1.5 border border-slate-300 hover:bg-slate-50 rounded text-xs text-slate-705 cursor-pointer font-bold transition-all"
              title="Inverter Ordem"
            >
              <ArrowUpDown className="w-3 h-3 text-slate-500" />
              <span>{sortOrder === 'asc' ? 'A-Z' : 'Z-A'}</span>
            </button>
          </div>
        </div>

        {/* Advanced Filters dropdown panel */}
        {(showFilters || statusFilter !== 'All' || typeFilter !== 'All' || priorityFilter !== 'All') && (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2.5 border-t border-slate-200">
            
            <div>
              <label className="block text-[9 px] font-bold text-slate-500 uppercase tracking-wider mb-1">Status Interno</label>
              <select
                id="filter-status-select"
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as DocumentStatus | 'All')}
                className="w-full bg-slate-50 border border-slate-300 text-xs text-slate-700 rounded px-2 py-1 focus:outline-none focus:border-[#003366]"
              >
                <option value="All">🔍 Todos Status</option>
                <option value="Pendente">⌛ Pendente</option>
                <option value="Em Análise">⚙️ Em Análise</option>
                <option value="Atrasado">⚠️ Atrasado</option>
                <option value="Concluído">✅ Concluído</option>
              </select>
            </div>

            <div>
              <label className="block text-[9px] font-bold text-slate-500 uppercase tracking-wider mb-1">Tipo de Documento</label>
              <select
                id="filter-type-select"
                value={typeFilter}
                onChange={(e) => setTypeFilter(e.target.value as DocumentType | 'All')}
                className="w-full bg-slate-50 border border-slate-300 text-xs text-slate-700 rounded px-2 py-1 focus:outline-none focus:border-[#003366]"
              >
                <option value="All">📁 Todos os Tipos</option>
                <option value="Memorando">Memorando</option>
                <option value="Ofício">Ofício</option>
                <option value="Requerimento">Requerimento</option>
                <option value="Portaria">Portaria</option>
                <option value="Circular">Circular</option>
                <option value="Comunicação Interna">Comunicação Interna</option>
              </select>
            </div>

            <div>
              <label className="block text-[9px] font-bold text-slate-500 uppercase tracking-wider mb-1">Prioridade</label>
              <select
                id="filter-priority-select"
                value={priorityFilter}
                onChange={(e) => setPriorityFilter(e.target.value as PriorityType | 'All')}
                className="w-full bg-slate-50 border border-slate-300 text-xs text-slate-700 rounded px-2 py-1 focus:outline-none focus:border-[#003366]"
              >
                <option value="All">🚦 Todas Prioridades</option>
                <option value="Baixa">Baixa</option>
                <option value="Média">Média</option>
                <option value="Alta">Alta</option>
                <option value="Urgente">Urgente</option>
              </select>
            </div>

            <div>
              <label className="block text-[9px] font-bold text-slate-500 uppercase tracking-wider mb-1">Critério de Ordenação</label>
              <select
                id="filter-sort-select"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as 'createdAt' | 'deadlineDate')}
                className="w-full bg-slate-50 border border-slate-300 text-xs text-slate-700 rounded px-2 py-1 focus:outline-none focus:border-[#003366]"
              >
                <option value="createdAt">📅 Data Protocolo</option>
                <option value="deadlineDate">⏳ Prazo Limite</option>
              </select>
            </div>

          </div>
        )}

      </div>

      {/* Counter Summary */}
      <div className="flex justify-between items-center px-1">
        <p className="text-[11px] text-slate-500">
          Pesquisa retornou <strong className="font-bold text-slate-800">{processedDocs.length}</strong> registro(s) no total.
        </p>
      </div>

      {/* Main List */}
      {processedDocs.length === 0 ? (
        <div id="list-empty-state" className="flex flex-col items-center justify-center p-8 bg-white rounded border border-dashed border-slate-300 text-center">
          <FileText className="w-8 h-8 text-slate-400 mb-1" />
          <p className="text-xs font-bold text-slate-800">DOCUMENTO NÃO LOCALIZADO</p>
          <p className="text-[11px] text-slate-500 max-w-sm mt-0.5">Nenhum protocolo corresponde às restrições de filtragem ou termos de busca atuados.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-2">
          {processedDocs.map((doc) => {
            const liveStatus = getLiveStatus(doc);
            const daysLeft = getRemainingDays(doc.deadlineDate);

            return (
              <div 
                key={doc.id}
                onClick={() => onViewDoc(doc.id)}
                className="bg-white hover:bg-slate-50 border border-slate-300 p-3 rounded transition-all cursor-pointer group flex flex-col md:flex-row md:items-center justify-between gap-3 border-l-4 border-l-[#003366]"
              >
                {/* Main Identity & Org Context */}
                <div className="min-w-0 flex-1 space-y-1.5">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-[10px] bg-slate-100 font-mono font-bold text-[#003366] px-1.5 py-0.2 border border-slate-300 rounded">
                      {doc.protocol}
                    </span>
                    <span className="text-[10px] bg-slate-800 text-white font-bold tracking-wider px-1.5 py-0.2 rounded">
                      {doc.type}
                    </span>
                    <span className={`text-[9px] uppercase font-bold tracking-wider px-1.5 py-0.2 rounded border ${getPriorityStyle(doc.priority)}`}>
                      Prio: {doc.priority}
                    </span>
                    <span className={`text-[9px] uppercase font-bold tracking-wider px-1.5 py-0.2 rounded border ${getStatusStyle(liveStatus)}`}>
                      {liveStatus === 'Atrasado' ? '⚠️ ATRASADO' : liveStatus}
                    </span>
                    {doc.attachment && (
                      <span className="text-[9px] bg-blue-50 text-blue-800 border border-blue-200 font-bold px-1.5 py-0.2 rounded flex items-center gap-0.5">
                        <Paperclip className="w-2.5 h-2.5" />
                        Anexo
                      </span>
                    )}
                    {doc.signatures && doc.signatures.length > 0 && (
                      <span className="text-[9px] bg-emerald-50 text-emerald-800 border border-emerald-200 font-bold px-1.5 py-0.2 rounded flex items-center gap-0.5">
                        <PenTool className="w-2.5 h-2.5 text-emerald-600" />
                        Assinado ({doc.signatures.length})
                      </span>
                    )}
                  </div>

                  <div>
                    <h3 className="font-sans font-bold text-slate-900 group-hover:text-[#003366] transition-colors text-xs sm:text-sm leading-snug">
                      {doc.title}
                    </h3>
                    <p className="text-[10px] text-slate-500 mt-0.5 flex flex-wrap items-center gap-1.5 leading-normal">
                      <span>Remetente:</span>
                      <strong className="text-slate-800 font-bold bg-slate-100 px-1 rounded">{doc.origin}</strong>
                      <span className="text-slate-400">➔</span>
                      <span>Destino:</span>
                      <strong className="text-slate-800 font-bold bg-slate-100 px-1 rounded">{doc.destination}</strong>
                    </p>
                  </div>
                </div>

                {/* Deadlines Timer Area (Controle de Prazos) */}
                <div className="flex flex-row md:flex-col md:items-end md:justify-center justify-between items-center gap-1 pt-2 md:pt-0 border-t border-slate-100 md:border-0 shrink-0 md:pl-3">
                  <div className="text-left md:text-right">
                    <span className="text-[9px] text-slate-400 block uppercase font-bold tracking-wider">Prazo Geral</span>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded border inline-block mt-0.5 font-bold ${daysLeft.badgeColor}`}>
                      {daysLeft.label}
                    </span>
                  </div>
                  
                  <div className="text-right hidden sm:block">
                    <span className="text-[9px] text-slate-400 block uppercase font-medium">Data Envio</span>
                    <span className="text-[10px] text-slate-600 font-mono font-bold">{formatDate(doc.createdAt)}</span>
                  </div>
                </div>

              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
