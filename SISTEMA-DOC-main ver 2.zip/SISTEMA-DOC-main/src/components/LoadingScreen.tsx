import React, { useState, useEffect } from 'react';
import { ShieldCheck, Loader2 } from 'lucide-react';

interface LoadingScreenProps {
  message?: string;
  onFinished?: () => void;
}

const MESSAGES = [
  'Verificando chaves criptográficas do barramento...',
  'Autenticando assinaturas digitais ICP-Brasil de servidores...',
  'Consultando repositório de documentos de Cutias-AP...',
  'Carregando metadados de trâmites e despachos remetidos...',
  'Estabelecendo canal seguro com a Controladoria Geral...',
  'Sincronizando banco de dados com os municípios do Amapá...',
  'Consolidando pareceres de chefias e secretarias convocadas...'
];

export default function LoadingScreen({ message, onFinished }: LoadingScreenProps) {
  const [progress, setProgress] = useState(0);
  const [currentMessage, setCurrentMessage] = useState(message || MESSAGES[0]);

  // Handle progress animation simulation
  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          if (onFinished) {
            onFinished();
          }
          return 100;
        }
        // Increment by safe random jumps
        const jump = Math.floor(Math.random() * 20) + 10;
        return Math.min(prev + jump, 100);
      });
    }, 120);

    return () => clearInterval(timer);
  }, [onFinished]);

  // Cycle through messages if there is no explicit message provided
  useEffect(() => {
    if (message) return;
    const msgTimer = setInterval(() => {
      const unusedMsg = MESSAGES[Math.floor(Math.random() * MESSAGES.length)];
      setCurrentMessage(unusedMsg);
    }, 450);

    return () => clearInterval(msgTimer);
  }, [message]);

  return (
    <div className="fixed inset-0 bg-[#001f3f]/90 backdrop-blur-md z-[9999] flex flex-col justify-center items-center p-6 text-center select-none font-sans">
      <div className="max-w-md w-full bg-slate-900 border border-blue-800 rounded-lg p-8 shadow-2xl flex flex-col items-center space-y-6 animate-zoom-in relative overflow-hidden">
        
        {/* Subtle background glow effect */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-48 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Outer Circular spinning seal */}
        <div className="relative flex items-center justify-center">
          <div className="w-20 h-20 rounded-full border-4 border-slate-800 border-t-[#00ff88] animate-spin ease-out duration-1000" />
          <div className="absolute inset-0 flex items-center justify-center">
            <ShieldCheck className="w-10 h-10 text-emerald-400 animate-pulse" />
          </div>
        </div>

        {/* Branding & Subtitle */}
        <div className="space-y-1">
          <span className="text-[10px] text-emerald-400 font-extrabold uppercase tracking-widest block font-mono">
            SISTEMA ELETRÔNICO DOC
          </span>
          <h2 className="text-white font-sans font-black text-sm uppercase tracking-wide">
            Processando Trâmite Digital
          </h2>
          <p className="text-[10px] text-blue-300 font-medium">
            Prefeitura Municipal de Cutias • Amapá
          </p>
        </div>

        {/* Customized Progress Bar */}
        <div className="w-full space-y-2">
          <div className="w-full bg-slate-800 h-2 rounded overflow-hidden p-0.5 border border-slate-705">
            <div 
              className="bg-gradient-to-r from-emerald-500 to-[#00ff88] h-1 rounded-full transition-all duration-150 ease-out shadow-[0_0_10px_#00ff88]" 
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="flex justify-between items-center text-[10px] font-mono text-slate-400 font-bold">
            <span className="uppercase tracking-tight text-slate-500">Aguarde...</span>
            <span>{progress}%</span>
          </div>
        </div>

        {/* Dynamic status line helper */}
        <div className="min-h-[2.5rem] flex items-center justify-center px-4 bg-slate-950/40 rounded border border-slate-800 w-full">
          <p className="text-[11px] font-mono font-medium text-blue-150 leading-relaxed text-center animate-pulse">
            {currentMessage}
          </p>
        </div>

        {/* Tiny encrypted footer */}
        <div className="text-[8px] font-mono text-slate-600 uppercase tracking-widest pt-2 border-t border-slate-850 w-full flex items-center justify-center gap-1.5 ">
          <Loader2 className="w-2.5 h-2.5 animate-spin text-slate-500" />
          <span>AES-256 CONEXÃO DE GOVERNO CRIPTOGRAFADA</span>
        </div>

      </div>
    </div>
  );
}
