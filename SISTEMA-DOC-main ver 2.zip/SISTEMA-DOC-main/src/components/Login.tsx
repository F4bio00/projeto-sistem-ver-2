/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Building, 
  Lock, 
  User, 
  UserCheck, 
  PlusCircle, 
  ArrowRight, 
  ShieldCheck, 
  Briefcase,
  Layers,
  Sparkles,
  HelpCircle
} from 'lucide-react';
import { AppUser, DEPARTMENTS } from '../types';

interface LoginProps {
  onLoginSuccess: (user: AppUser) => void;
  registeredUsers: AppUser[];
  onRegisterUser: (newUser: AppUser) => void;
  municipalities?: string[];
  suspendedMunicipalities?: string[];
}

export const DEFAULT_USERS: AppUser[] = [
  {
    id: 'u-adm',
    name: 'Administrador Master',
    username: 'ADM',
    role: 'master',
    department: 'Controladoria Geral (CGM) - TI Administrador',
    password: 'ADM',
    municipality: 'Cutias'
  },
  {
    id: 'u-serv1',
    name: 'Servidor Municipal Macapá',
    username: 'SERV1',
    role: 'servidor',
    department: 'Secretaria Municipal de Administração e Planejamento (SEMAP)',
    password: 'SERV1',
    municipality: 'Macapá'
  },
  {
    id: 'u-master',
    name: 'Dr. Valter Amapá',
    username: 'master',
    role: 'master',
    department: 'Controladoria Geral (CGM) - TI Administrador',
    password: 'master',
    municipality: 'Cutias'
  },
  {
    id: 'u-1',
    name: 'Ana Cristina Souza',
    username: 'ana.semusa',
    role: 'gestor',
    department: 'Secretaria Municipal de Saúde (SEMUSA)',
    password: '123',
    municipality: 'Cutias'
  },
  {
    id: 'u-2',
    name: 'Paulo Roberto Dias',
    username: 'paulo.semof',
    role: 'servidor',
    department: 'Secretaria Municipal de Finanças (SEMOF)',
    password: '123',
    municipality: 'Cutias'
  },
  {
    id: 'u-3',
    name: 'Carlos Magno',
    username: 'carlos.semed',
    role: 'gestor',
    department: 'Secretaria Municipal de Educação (SEMED)',
    password: '123',
    municipality: 'Cutias'
  },
  {
    id: 'u-4',
    name: 'Juliana Barbosa',
    username: 'juliana.semap',
    role: 'servidor',
    department: 'Secretaria Municipal de Administração e Planejamento (SEMAP)',
    password: '123',
    municipality: 'Cutias'
  },
  {
    id: 'u-5',
    name: 'Dr. Fernando Mello',
    username: 'fernando.pgm',
    role: 'gestor',
    department: 'Procuradoria Geral do Município (PGM)',
    password: '123',
    municipality: 'Cutias'
  },
  {
    id: 'u-6',
    name: 'Luciana Mendes',
    username: 'luciana.semgov',
    role: 'gestor',
    department: 'Secretaria Municipal de Governo (SEMGOV)',
    password: '123',
    municipality: 'Cutias'
  }
];

export default function Login({
  onLoginSuccess,
  registeredUsers,
  onRegisterUser,
  municipalities = ['Cutias', 'Macapá', 'Santana', 'Itaubal'],
  suspendedMunicipalities = []
}: LoginProps) {
  const [isRegistering, setIsRegistering] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // Register state
  const [regName, setRegName] = useState('');
  const [regUsername, setRegUsername] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regRole, setRegRole] = useState<'gestor' | 'servidor'>('servidor');
  const [regDept, setRegDept] = useState(DEPARTMENTS[4].name + ` (${DEPARTMENTS[4].acronym})`); // Default to SEMUSA
  const [regMunicipality, setRegMunicipality] = useState(municipalities[0] || 'Cutias');

  const allUsers = [...DEFAULT_USERS, ...registeredUsers];

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!username || !password) {
      setErrorMsg('Por favor, informe suas credenciais de acesso.');
      return;
    }

    const matched = allUsers.find(
      (u) => u.username.toLowerCase() === username.trim().toLowerCase() && u.password === password
    );

    if (matched) {
      const userMunicipality = matched.municipality || 'Cutias';
      if (matched.role !== 'master' && suspendedMunicipalities.includes(userMunicipality)) {
        setErrorMsg(`Acesso suspenso. O município de ${userMunicipality} está temporariamente desativado pelo Administrador Federal.`);
        return;
      }
      onLoginSuccess(matched);
    } else {
      setErrorMsg('Acesso negado. Credenciais ou usuário inválidos para os servidores municipais.');
    }
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!regName || !regUsername || !regPassword) {
      setErrorMsg('Todos os campos obrigatórios precisam estar preenchidos.');
      return;
    }

    if (regRole !== 'master' && suspendedMunicipalities.includes(regMunicipality)) {
      setErrorMsg(`Não é possível registrar usuários para um município suspenso (${regMunicipality}).`);
      return;
    }

    // Check if username already exists
    const exists = allUsers.some((u) => u.username.toLowerCase() === regUsername.trim().toLowerCase());
    if (exists) {
      setErrorMsg('Este nome de usuário já está cadastrado.');
      return;
    }

    const newUser: AppUser = {
      id: `u-custom-${Date.now()}`,
      name: regName.trim(),
      username: regUsername.trim().toLowerCase(),
      role: regRole,
      department: regDept,
      password: regPassword,
      municipality: regMunicipality
    };

    onRegisterUser(newUser);
    setIsRegistering(false);
    
    // Auto fill login fields for experience flow
    setUsername(newUser.username);
    setPassword(newUser.password || '');
    setErrorMsg('');
  };

  // Quick sandbox login handler
  const handleQuickLogin = (user: AppUser) => {
    setUsername(user.username);
    setPassword(user.password || '123');
    setErrorMsg('');
    // Instantly log in for maximum ease of testing
    onLoginSuccess(user);
  };

  return (
    <div className="min-h-screen bg-slate-100 flex items-center justify-center p-4 sm:p-6 md:p-12 font-sans overflow-y-auto">
      <div className="max-w-4xl w-full bg-white rounded-lg border border-slate-300 shadow-md overflow-hidden grid grid-cols-1 md:grid-cols-5 min-h-[540px]">
        
        {/* Left Info Column (Branded) */}
        <div className="col-span-2 bg-[#003366] text-white p-6 md:p-8 flex flex-col justify-between relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-full blur-2xl"></div>
          
          <div className="space-y-4 relative z-10">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-white text-[#003366] rounded flex items-center justify-center font-bold p-1">
                <Building className="w-5 h-5" />
              </div>
              <span className="font-sans font-extrabold text-sm tracking-widest uppercase text-blue-100">DOC Cutias-AP</span>
            </div>

            <div className="pt-4 space-y-2">
              <h2 className="text-xl font-extrabold tracking-tight font-sans text-white uppercase leading-tight">
                Portal de Trâmites Administrativos
              </h2>
              <p className="text-xs text-blue-200 leading-relaxed font-medium">
                Sistemas eletrônicos de desburocratização regulamentar para ofícios, portarias e memorandos internos da Prefeitura de Cutias (AP).
              </p>
            </div>
          </div>

          <div className="space-y-4 pt-6 relative z-10">
            <div className="space-y-2.5 text-xs text-blue-150">
              <div className="flex items-start gap-2">
                <ShieldCheck className="w-4 h-4 text-blue-300 shrink-0 mt-0.5" />
                <span><strong>Não-Interferência:</strong> Servidores trabalham nas filas próprias do seu setor, sem acesso indevido às pastas alheias.</span>
              </div>
              <div className="flex items-start gap-2">
                <Sparkles className="w-4 h-4 text-theme-alert text-blue-300 shrink-0 mt-0.5" />
                <span><strong>Comunicação Transparente:</strong> Ofícios remetidos chegam instantaneamente às secretarias destino para gerar despachos.</span>
              </div>
              <div className="flex items-start gap-2">
                <Layers className="w-4 h-4 text-blue-300 shrink-0 mt-0.5" />
                <span><strong>Auditabilidade Plena:</strong> Histórico imutável de recebimentos, dilação de prazos e respostas regimentais.</span>
              </div>
            </div>

            <div className="border-t border-blue-800 pt-4 text-[10px] text-blue-300 font-semibold uppercase tracking-wider text-center">
              Amapá • Amazônia • Brasil
            </div>
          </div>
        </div>

        {/* Right Input Column */}
        <div className="col-span-3 p-6 md:p-8 flex flex-col justify-center">
          
          <div>
            {/* Simple Header */}
            <div className="border-b border-slate-300 pb-3 mb-6">
              <h3 className="font-sans font-extrabold text-[#003366] text-sm uppercase tracking-wide">
                Identificação de Servidor
              </h3>
              <p className="text-[10px] text-slate-500 mt-0.5">
                Utilize as credenciais <strong className="text-amber-700">ADM / ADM</strong> (para acesso Master) ou <strong className="text-[#003366]">SERV1 / SERV1</strong> (para simular acesso de servidor municipal).
              </p>
            </div>

            {errorMsg && (
              <div className="p-2.5 mb-4 bg-red-50 border border-red-300 text-red-700 text-xs rounded font-medium flex items-center gap-1.5 animate-pulse">
                <span>⚠️ {errorMsg}</span>
              </div>
            )}

            {/* LOGIN FORM */}
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Nome de Usuário (Login)
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-2.5 flex items-center text-slate-400">
                    <User className="w-4 h-4" />
                  </span>
                  <input
                    id="login-username"
                    type="text"
                    required
                    placeholder="Ex: ana.semusa"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-300 text-slate-850 text-xs rounded focus:outline-none focus:border-[#003366] focus:bg-white font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Senha Provisória
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-2.5 flex items-center text-slate-400">
                    <Lock className="w-4 h-4" />
                  </span>
                  <input
                    id="login-password"
                    type="password"
                    required
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-300 text-slate-850 text-xs rounded focus:outline-none focus:border-[#003366] focus:bg-white font-mono"
                  />
                </div>
              </div>

              <button
                id="btn-confirm-login"
                type="submit"
                className="w-full bg-[#003366] hover:bg-blue-900 active:bg-blue-950 text-white font-bold py-2 rounded text-xs transition-colors flex items-center justify-center gap-1.5 uppercase tracking-wide shadow-xs cursor-pointer animate-none"
              >
                <span>Acessar Painel DOC</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </form>

          </div>

        </div>

      </div>
    </div>
  );
}
