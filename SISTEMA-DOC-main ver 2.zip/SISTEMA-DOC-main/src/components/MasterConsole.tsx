import React, { useState, useEffect } from 'react';
import {
  Database,
  Shield,
  Trash2,
  Edit3,
  RefreshCw,
  AlertTriangle,
  ShieldCheck,
  CheckCircle2,
  Activity,
  Server,
  FileText,
  AlertCircle,
  Clock,
  Wrench,
  Search,
  Check,
  X,
  Building,
  User,
  Plus,
  Code,
  Terminal,
  Lock,
  Unlock,
  Play,
  Cpu,
  Layers,
  Settings
} from 'lucide-react';
import { Document, DocumentType, PriorityType, DocumentStatus, AppUser, DEPARTMENTS } from '../types';
import { formatDate } from '../utils';
import { DEFAULT_USERS } from './Login';

interface MasterConsoleProps {
  documents: Document[];
  onUpdateDocument: (updated: Document) => void;
  onDeleteDocument: (id: string) => void;
  onResetDatabase: () => void;
  currentUser: AppUser;
  municipalities?: string[];
  currentMunicipality?: string;
  onAddMunicipality?: (name: string) => void;
  onSelectMunicipality?: (name: string) => void;
  suspendedMunicipalities?: string[];
  onSuspendMunicipality?: (name: string) => void;
  onReactivateMunicipality?: (name: string) => void;
  registeredUsers?: AppUser[];
  onAddStaffMember?: (newUser: AppUser) => void;
  onDeleteStaffMember?: (id: string) => void;
  onBulkUpdateDocuments?: (allDocs: Document[]) => void;
  onBulkUpdateUsers?: (allUsers: AppUser[]) => void;
}

interface SimulatedError {
  id: string;
  code: string;
  severity: 'Crítico' | 'Aviso' | 'Otimização';
  title: string;
  description: string;
  targetDocumentId?: string;
  recommendation: string;
  type: 'overdue' | 'self_sent' | 'empty_history' | 'heavy_attachment' | 'no_priority';
}

export default function MasterConsole({
  documents,
  onUpdateDocument,
  onDeleteDocument,
  onResetDatabase,
  currentUser,
  municipalities = ['Cutias'],
  currentMunicipality = 'Cutias',
  onAddMunicipality,
  onSelectMunicipality,
  suspendedMunicipalities = [],
  onSuspendMunicipality,
  onReactivateMunicipality,
  registeredUsers = [],
  onAddStaffMember,
  onDeleteStaffMember,
  onBulkUpdateDocuments,
  onBulkUpdateUsers
}: MasterConsoleProps) {
  const [activeSubTab, setActiveSubTab] = useState<'errors' | 'editing' | 'system' | 'municipalities' | 'advanced_db'>('errors');
  const [selectedMunForStaff, setSelectedMunForStaff] = useState<string>(currentMunicipality);

  const [staffName, setStaffName] = useState('');
  const [staffUser, setStaffUser] = useState('');
  const [staffPass, setStaffPass] = useState('');
  const [staffRole, setStaffRole] = useState<'servidor' | 'gestor'>('servidor');
  const [staffDept, setStaffDept] = useState(DEPARTMENTS[4].name + ` (${DEPARTMENTS[4].acronym})`); // Default to SEMUSA
  const [staffSearchQuery, setStaffSearchQuery] = useState('');
  const [staffError, setStaffError] = useState('');

  const [searchQuery, setSearchQuery] = useState('');
  const [newMunicName, setNewMunicName] = useState('');
  const [municError, setMunicError] = useState('');
  
  // Editing state for corrections
  const [editingDocId, setEditingDocId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editType, setEditType] = useState<DocumentType>('Memorando');
  const [editOrigin, setEditOrigin] = useState('');
  const [editDestination, setEditDestination] = useState('');
  const [editDeadline, setEditDeadline] = useState('');
  const [editPriority, setEditPriority] = useState<PriorityType>('Média');
  const [editStatus, setEditStatus] = useState<DocumentStatus>('Pendente');
  const [editDescription, setEditDescription] = useState('');
  const [editResponseText, setEditResponseText] = useState('');

  // States for Advanced Database tab
  const [selectedDocIdForRawExplorer, setSelectedDocIdForRawExplorer] = useState<string>('');
  const [rawJsonText, setRawJsonText] = useState<string>('');
  const [jsonError, setJsonError] = useState<string>('');
  const [terminalInput, setTerminalInput] = useState<string>('');
  const [terminalLines, setTerminalLines] = useState<string[]>([
    'CONTROLE DO BANCO DE DADOS CORE • TERMINAL DE MACRO-COMANDOS v1.0',
    'Conexão segura estabelecida com o barramento central.',
    'Dispositivo habilitado no nível total de Master Auditor.',
    'Digite "help" ou selecione uma predefinição acima.'
  ]);
  const [selectedMunForDbCreation, setSelectedMunForDbCreation] = useState<string>(currentMunicipality);
  const [createdDbPresetType, setCreatedDbPresetType] = useState<'urbanismo' | 'educacao' | 'saude' | 'completo'>('completo');
  
  // User permissions states
  const [advUserFilter, setAdvUserFilter] = useState<string>('');
  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [editUserRole, setEditUserRole] = useState<'servidor' | 'gestor' | 'master'>('servidor');
  const [editUserDept, setEditUserDept] = useState<string>('');
  const [editUserMun, setEditUserMun] = useState<string>('');
  const [editUserPassword, setEditUserPassword] = useState<string>('');

  // Toast / Status banner info
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'info' } | null>(null);

  // Auto-calculated simulated error analysis
  const [systemErrors, setSystemErrors] = useState<SimulatedError[]>([]);

  // Trigger Toast helper
  const showToast = (text: string, type: 'success' | 'info' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 5000);
  };

  // Run dynamic error analyzer on database
  const runErrorAnalysis = () => {
    const list: SimulatedError[] = [];
    
    // Rule 1: Pendente/Em Análise com data ultrapassada (Overdue items without response)
    const today = new Date();
    documents.forEach(doc => {
      const deadline = new Date(doc.deadlineDate);
      if ((doc.status === 'Pendente' || doc.status === 'Em Análise') && deadline < today) {
        list.push({
          id: `err-overdue-${doc.id}`,
          code: 'ERR_TIMEOUT_01',
          severity: 'Crítico',
          title: 'Prazo Excedido de Trâmite',
          description: `O ${doc.type} (${doc.protocol}) está sob status "${doc.status}" mas extrapolou a data de vencimento (${formatDate(doc.deadlineDate)}).`,
          targetDocumentId: doc.id,
          recommendation: 'Atualizar prioridade para "Urgente" ou marcar como Concluído.',
          type: 'overdue'
        });
      }

      // Rule 2: Self Sent (Origin and destination are identical)
      if (doc.origin.toLowerCase() === doc.destination.toLowerCase() || 
          (doc.origin.includes('(') && doc.destination.includes('(') && 
           doc.origin.split('(')[1] === doc.destination.split('(')[1])) {
        list.push({
          id: `err-self-${doc.id}`,
          code: 'ERR_SEMANTICS_02',
          severity: 'Aviso',
          title: 'Loop de Destinatário Identificado',
          description: `O remetente é idêntico ao destinatário (${doc.origin}). Isso causa loop infinito de trâmite.`,
          targetDocumentId: doc.id,
          recommendation: 'Corrigir o setor destinatário no painel de alterações.',
          type: 'self_sent'
        });
      }

      // Rule 3: Empty history log or anomalous log count
      if (!doc.history || doc.history.length === 0) {
        list.push({
          id: `err-hist-${doc.id}`,
          code: 'ERR_INTEGRITY_03',
          severity: 'Crítico',
          title: 'Histórico de Auditoria Corrompido',
          description: `O documento ${doc.protocol} foi cadastrado, mas carece de histórico de trâmite eletrônico.`,
          targetDocumentId: doc.id,
          recommendation: 'Gerar histórico de inicialização automática.',
          type: 'empty_history'
        });
      }

      // Rule 4: Simulated "heavy attachment" warning
      if (doc.attachment && doc.attachment.size > 1024 * 1024 * 1.5) { // 1.5MB
        list.push({
          id: `err-size-${doc.id}`,
          code: 'WARN_MEMORY_04',
          severity: 'Otimização',
          title: 'Anexo com tamanho excessivo',
          description: `O arquivo "${doc.attachment.name}" possui ${ (doc.attachment.size / (1024*1024)).toFixed(2) } MB, excedendo a quota padrão de indexação rápida.`,
          targetDocumentId: doc.id,
          recommendation: 'Gargalo de cache detectado. Otimizar arquivo PDF/DOCX.',
          type: 'heavy_attachment'
        });
      }
    });

    setSystemErrors(list);
  };

  useEffect(() => {
    runErrorAnalysis();
  }, [documents]);

  const handleEditClick = (doc: Document) => {
    setEditingDocId(doc.id);
    setEditTitle(doc.title);
    setEditType(doc.type);
    setEditOrigin(doc.origin);
    setEditDestination(doc.destination);
    setEditDeadline(doc.deadlineDate);
    setEditPriority(doc.priority);
    setEditStatus(doc.status);
    setEditDescription(doc.description);
    setEditResponseText(doc.response?.text || '');
  };

  const handleCancelEdit = () => {
    setEditingDocId(null);
  };

  const handleSaveCorrection = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingDocId) return;

    const originalDoc = documents.find(d => d.id === editingDocId);
    if (!originalDoc) return;

    let updatedResponse = undefined;
    if (editResponseText) {
      updatedResponse = {
        responder: originalDoc.response?.responder || `Master Auditor (TI CGM)`,
        text: editResponseText,
        createdAt: originalDoc.response?.createdAt || new Date().toISOString()
      };
    }

    const updatedDoc: Document = {
      ...originalDoc,
      title: editTitle,
      type: editType,
      origin: editOrigin,
      destination: editDestination,
      deadlineDate: editDeadline,
      priority: editPriority,
      status: editStatus,
      description: editDescription,
      response: updatedResponse,
      history: [
        ...originalDoc.history,
        {
          id: `h-corr-${Date.now()}`,
          date: new Date().toISOString(),
          user: `Master (${currentUser.name})`,
          action: 'CORREÇÃO DE BANCO',
          notes: 'Metadados e integridade de arquivo corrigidos manualmente pelo Painel Master.'
        }
      ]
    };

    onUpdateDocument(updatedDoc);
    setEditingDocId(null);
    showToast(`O documento ${updatedDoc.protocol} foi corrigido com sucesso!`);
  };

  const handleAutoResolve = (err: SimulatedError) => {
    const doc = documents.find(d => d.id === err.targetDocumentId);
    if (!doc) return;

    let updated = { ...doc };

    if (err.type === 'overdue') {
      // Elevate priority to Urgente and add history warning
      updated.priority = 'Urgente';
      updated.history = [
        ...updated.history,
        {
          id: `h-err-${Date.now()}`,
          date: new Date().toISOString(),
          user: 'Sistema (Auto-Corrector)',
          action: 'ESCALONAMENTO DE PRAZO',
          notes: 'O prazo do documento expirou. Urgência do trâmite restabelecida para nível máximo por auditoria.'
        }
      ];
      onUpdateDocument(updated);
      showToast(`Resolvido: Prioridade do ${doc.protocol} atualizada para Urgente!`);
    } else if (err.type === 'self_sent') {
      // Redirect target to default central general sector GAB
      const originalAbbr = doc.origin.split('(')[1]?.replace(')', '') || '';
      // Find a destination that is not same as origin
      const defaultDest = DEPARTMENTS.find(d => d.acronym !== originalAbbr)?.name || DEPARTMENTS[1].name;
      updated.destination = defaultDest;
      updated.history = [
        ...updated.history,
        {
          id: `h-err-${Date.now()}`,
          date: new Date().toISOString(),
          user: 'Sistema (Auto-Corrector)',
          action: 'REDIRECIONAMENTO SEMÂNTICO',
          notes: `Loop de destino corrigido. Envio re-encaminhado para ${defaultDest}.`
        }
      ];
      onUpdateDocument(updated);
      showToast(`Resolvido: Destinatário do ${doc.protocol} reencaminhado para ${defaultDest.split(' ')[0]}`);
    } else if (err.type === 'empty_history') {
      // Regenerate simple standard log history entries
      updated.history = [
        {
          id: `h-init-${Date.now()}`,
          date: doc.createdAt,
          user: 'Agente Originário',
          action: 'DOCUMENTO PROTOCOLADO',
          notes: 'Log restaurado pelo corrector de redundância.'
        }
      ];
      onUpdateDocument(updated);
      showToast(`Resolvido: Histórico de auditoria do ${doc.protocol} reconstruído!`);
    } else if (err.type === 'heavy_attachment') {
      // Compress simulated attachment in memory
      if (updated.attachment) {
        updated.attachment = {
          ...updated.attachment,
          size: Math.round(updated.attachment.size * 0.35) // Simulated compression
        };
        updated.history = [
          ...updated.history,
          {
            id: `h-err-${Date.now()}`,
            date: new Date().toISOString(),
            user: 'Sistema (Auto-Corrector)',
            action: 'COMPRESSÃO DE ARQUIVO',
            notes: 'Arquivo indexador em cache reduzido para otimização de banda.'
          }
        ];
        onUpdateDocument(updated);
        showToast(`Resolvido: Anexo do ${doc.protocol} otimizado em 65%!`);
      }
    }
  };

  const handleDeleteClick = (id: string, protocol: string) => {
    if (confirm(`Tem certeza que deseja excluir permanentemente o documento ${protocol}? Essa ação registrará um log de purgação irreversível.`)) {
      onDeleteDocument(id);
      showToast(`Documento ${protocol} excluído com sucesso do barramento de dados.`, 'info');
    }
  };

  const handleFullReset = () => {
    if (confirm('ATENÇÃO: Deseja redefinir todo o banco de dados simulado do DOC para o estado padrão? Todos os ofícios extras criados serão descartados.')) {
      onResetDatabase();
      showToast('Banco de dados eletrônico redefinido com sucesso!', 'info');
    }
  };

  // Synchronize Raw JSON text block when item is selected in raw explorer
  useEffect(() => {
    if (selectedDocIdForRawExplorer) {
      const doc = documents.find(d => d.id === selectedDocIdForRawExplorer);
      if (doc) {
        setRawJsonText(JSON.stringify(doc, null, 2));
        setJsonError('');
      } else {
        setRawJsonText('');
      }
    } else {
      setRawJsonText('');
    }
  }, [selectedDocIdForRawExplorer, documents]);

  // Handle direct JSON compilation and update
  const handleSaveRawJson = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDocIdForRawExplorer) return;
    try {
      const parsed = JSON.parse(rawJsonText) as Document;
      if (!parsed.id || !parsed.protocol || !parsed.title) {
        setJsonError('Erro: O JSON precisa conter ao menos as chaves obrigatórias "id", "protocol" e "title".');
        return;
      }
      onUpdateDocument(parsed);
      setJsonError('');
      showToast(`Sucesso: Documento ${parsed.protocol} atualizado diretamente no banco de dados!`);
    } catch (err: any) {
      setJsonError(`Erro de Sintaxe JSON: ${err.message}`);
    }
  };

  // Function to build/seed a dedicated database for a specific prefeitura
  const handleCreateDatabaseForMunicipality = (municipalityName: string, preset: 'urbanismo' | 'educacao' | 'saude' | 'completo') => {
    if (!onBulkUpdateDocuments) {
      showToast('Erro: Callbacks de atualização de banco de dados indisponíveis.', 'info');
      return;
    }

    const todayStr = new Date().toISOString().split('T')[0];
    const createdDocs: Document[] = [];

    // Helper to generate a random PMC protocol
    const makeProtocol = (year: number, seq: number) => `PMC-${year}-${String(Math.floor(1000 + seq * 133 + Math.random() * 99)).padStart(4, '0')}`;

    if (preset === 'saude' || preset === 'completo') {
      createdDocs.push({
        id: `doc-seeded-${municipalityName}-saude-1`,
        protocol: makeProtocol(2026, 1),
        title: `Aquisição Emergencial de Vacinas Termolábeis — Unidade Integrada de Saúde de ${municipalityName}`,
        type: 'Ofício',
        origin: 'Secretaria Municipal de Saúde (SEMUSA)',
        destination: 'Secretaria Municipal de Finanças (SEMOF)',
        description: `Demanda vinculada ao repasse do teto de custeio SUS para conservação e logística fluvial de lotes de imunizantes na rede de postos de ${municipalityName}.`,
        createdAt: new Date(Date.now() - 3 * 24 * 3600 * 1000).toISOString(),
        deadlineDate: todayStr,
        priority: 'Urgente',
        status: 'Pendente',
        municipality: municipalityName,
        history: [
          {
            id: `h-seed-s1-${Date.now()}`,
            date: new Date(Date.now() - 3 * 24 * 3600 * 1000).toISOString(),
            user: 'Simulado (Gerador de Banco)',
            action: 'Instaurado pelo Portal DOC',
            notes: `Banco de dados inicializado para a prefeitura de ${municipalityName}.`
          }
        ]
      });

      createdDocs.push({
        id: `doc-seeded-${municipalityName}-saude-2`,
        protocol: makeProtocol(2026, 2),
        title: `Custeio de Combustível para Ambulâncias do SAMU em ${municipalityName}`,
        type: 'Memorando',
        origin: 'Secretaria Municipal de Saúde (SEMUSA)',
        destination: 'Secretaria Municipal de Administração e Planejamento (SEMAP)',
        description: `Solicitação emergencial para liberação de cotas adicionais de diesel marítimo e gasolina comum para cobrir os deslocamentos sanitários em ${municipalityName}.`,
        createdAt: new Date(Date.now() - 1 * 24 * 3600 * 1000).toISOString(),
        deadlineDate: new Date(Date.now() + 5 * 24 * 3600 * 1000).toISOString().split('T')[0],
        priority: 'Alta',
        status: 'Em Análise',
        municipality: municipalityName,
        history: [
          {
            id: `h-seed-s2-${Date.now()}`,
            date: new Date(Date.now() - 1 * 24 * 3600 * 1000).toISOString(),
            user: 'Secretário de Saúde Interino',
            action: 'Documento Protocolado',
            notes: 'Aguardando o deferimento orçamentário para o empenho da distribuidora.'
          }
        ]
      });
    }

    if (preset === 'educacao' || preset === 'completo') {
      createdDocs.push({
        id: `doc-seeded-${municipalityName}-edu-1`,
        protocol: makeProtocol(2026, 3),
        title: `Reforma Estrutural da Escola Municipal de Ensino Fundamental Clodoaldo Ramos - Polo Fluvial de ${municipalityName}`,
        type: 'Requerimento',
        origin: 'Secretaria Municipal de Educação (SEMED)',
        destination: 'Secretaria Municipal de Obras e Serviços Públicos (SEMOSP)',
        description: `Laudo técnico aponta necessidade inadiável de melhorias estruturais na cobertura, fiação elétrica e banheiros do educandário de ${municipalityName} antes do início do período letivo.`,
        createdAt: new Date(Date.now() - 15 * 24 * 3600 * 1000).toISOString(),
        deadlineDate: new Date(Date.now() - 2 * 24 * 3600 * 1000).toISOString().split('T')[0],
        priority: 'Alta',
        status: 'Atrasado',
        municipality: municipalityName,
        history: [
          {
            id: `h-seed-e1-1`,
            date: new Date(Date.now() - 15 * 24 * 3600 * 1000).toISOString(),
            user: 'Diretoria de Logística de Ensino',
            action: 'Instaurado',
            notes: 'Laudo de sinistralidade anexado via protocolo geral de controle da prefeitura.'
          }
        ]
      });

      createdDocs.push({
        id: `doc-seeded-${municipalityName}-edu-2`,
        protocol: makeProtocol(2026, 4),
        title: `Renovação de Contrato do Serviço de Nutrição Escolar (Merenda)`,
        type: 'Ofício',
        origin: 'Secretaria Municipal de Educação (SEMED)',
        destination: 'Secretaria Municipal de Finanças (SEMOF)',
        description: `Aditivo contratual para atendimento da pauta de gêneros alimentícios do Programa Nacional de Alimentação Escolar (PNAE) na comarca de ${municipalityName}.`,
        createdAt: new Date(Date.now() - 2 * 24 * 3600 * 1000).toISOString(),
        deadlineDate: new Date(Date.now() + 10 * 24 * 3600 * 1000).toISOString().split('T')[0],
        priority: 'Média',
        status: 'Em Análise',
        municipality: municipalityName,
        history: [
          {
            id: `h-seed-e2-1`,
            date: new Date(Date.now() - 2 * 24 * 3600 * 1000).toISOString(),
            user: 'Pregoeiro Geral do Município',
            action: 'Parecer Preliminar Emitido',
            notes: 'Preenchimento adequado de termo de conciliação fiscal efetuado.'
          }
        ]
      });
    }

    if (preset === 'urbanismo' || preset === 'completo') {
      createdDocs.push({
        id: `doc-seeded-${municipalityName}-urb-1`,
        protocol: makeProtocol(2026, 5),
        title: `Manutenção de Iluminação Pública no Bairro Central e Orla de ${municipalityName}`,
        type: 'Comunicação Interna',
        origin: 'Secretaria Municipal de Obras e Serviços Públicos (SEMOSP)',
        destination: 'Gabinete do Prefeito',
        description: `Troca de projetores danificados por luminárias de LED econômicas de alta performance para segurança dos munícipes no calçadão das praças de ${municipalityName}.`,
        createdAt: new Date().toISOString(),
        deadlineDate: new Date(Date.now() + 15 * 24 * 3600 * 1000).toISOString().split('T')[0],
        priority: 'Baixa',
        status: 'Pendente',
        municipality: municipalityName,
        history: [
          {
            id: `h-seed-u1-1`,
            date: new Date().toISOString(),
            user: 'Gabinete SEMOSP',
            action: 'Protocolado no DOC',
            notes: 'Planejamento das equipes de campo agendado para o fim de semana.'
          }
        ]
      });

      createdDocs.push({
        id: `doc-seeded-${municipalityName}-urb-2`,
        protocol: makeProtocol(2026, 6),
        title: `Licenciamento Ambiental para Coleta de Resíduos Sólidos e Saneamento de ${municipalityName}`,
        type: 'Ofício',
        origin: 'Secretaria Municipal de Obras e Serviços Públicos (SEMOSP)',
        destination: 'Secretaria Municipal de Administração e Planejamento (SEMAP)',
        description: `Plano de contingência preventiva ambiental e requisição do alvará de conformidade sanitária para a destinação sustentável de dejetos coletados.`,
        createdAt: new Date(Date.now() - 6 * 24 * 3600 * 1000).toISOString(),
        deadlineDate: new Date(Date.now() + 2 * 24 * 3600 * 1000).toISOString().split('T')[0],
        priority: 'Média',
        status: 'Concluído',
        municipality: municipalityName,
        history: [
          {
            id: `h-seed-u2-1`,
            date: new Date(Date.now() - 6 * 24 * 3600 * 1000).toISOString(),
            user: 'Auditor do Comitê de Saneamento',
            action: 'Abertura de Inquérito Técnico',
            notes: 'Aprovado sem nenhuma ressalva pelo colegiado no portal DOC.'
          },
          {
            id: `h-seed-u2-2`,
            date: new Date(Date.now() - 1 * 24 * 3600 * 1000).toISOString(),
            user: 'Administração Geral',
            action: 'Despacho de Homologação Concluido',
            notes: 'Parecer emitido pela autarquia reguladora local. Processo encerrado.'
          }
        ],
        response: {
          text: 'Prezado Secretário, o alvará ambiental municipal para saneamento foi emitido com validade de 24 meses. Favor repassar cópia ao consórcio de coleta.',
          createdAt: new Date(Date.now() - 1 * 24 * 3600 * 1000).toISOString(),
          responder: 'Prefeito Municipal'
        }
      });
    }

    // Append to existing database (keep other municipalities, clean old of this municipality to override)
    const externalDocs = documents.filter(d => (d.municipality || 'Cutias').toLowerCase() !== municipalityName.toLowerCase());
    const finalDocsList = [...createdDocs, ...externalDocs];

    onBulkUpdateDocuments(finalDocsList);
    showToast(`Banco de dados para ${municipalityName} criado com ${createdDocs.length} novos documentos!`);
    
    // Add terminal log message
    setTerminalLines(prev => [
      ...prev,
      `[${new Date().toLocaleTimeString()}] >> BANCO CRIADO: Prefeitura de ${municipalityName} (${preset.toUpperCase()})`,
      `  - ${createdDocs.length} documentos oficiais semeados com sucesso.`,
      `  - ProtocolosPMC integrados em hashes de verificação pública.`
    ]);
  };

  // Safe macro interpreter & manual instruction center (commands creator)
  const handleExecuteTerminalCommand = (rawCmd: string) => {
    const exprText = rawCmd.trim();
    if (!exprText) return;

    const parts = exprText.split(' ');
    const command = parts[0].toLowerCase();
    const args = parts.slice(1);

    let outputLog = `[${new Date().toLocaleTimeString()}] $ ${exprText}\n`;
    let responseText = '';

    switch (command) {
      case 'help':
        responseText = 
          'Macros e Comandos disponiveis para a Auditoria:\n' +
          '  - clear                             Limpa a tela do terminal\n' +
          '  - db_status                         Status de integridade do barramento de dados\n' +
          '  - promote_all [município]           Torna TODOS os usuários do município em "Gestor"\n' +
          '  - fix_loops                         Exclui ou resolve auto-envio (remetente = destino)\n' +
          '  - overdue_grace [dias]              Adiciona prazo extra aos ofícios vencidos (padrão 15)\n' +
          '  - approve_all [município]           Força a conclusão de todos os processos pendentes\n' +
          '  - show_users                        Gera o dump dos servidores cadastrados no terminal\n' +
          '  - sql_sim [seletor_status]          Imita busca SQL ("select from docs where status=...")\n' +
          '  - help                              Exibe essa listagem de comandos';
        break;

      case 'clear':
        setTerminalLines([]);
        setTerminalInput('');
        return;

      case 'db_status':
        responseText = 
          `--- INTEGRIDADE DO BARRAMENTO CENTRAL DE DADOS ---\n` +
          `  - Total de Ofícios/Processos: ${documents.length} registros ativos.\n` +
          `  - Municípios Registrados: [${municipalities.join(', ')}]\n` +
          `  - Clientes Conectados na Sessão DOC: ${[...DEFAULT_USERS, ...(registeredUsers || [])].length} servidores.\n` +
          `  - Situação de Armazenamento cache: ${(JSON.stringify(documents).length / 1024).toFixed(2)} KB em uso.`;
        break;

      case 'promote_all': {
        const targetMun = args[0] ? args[0].toLowerCase() : currentMunicipality.toLowerCase();
        if (!onBulkUpdateUsers) {
          responseText = 'Erro: Callback de atualização de usuários indisponível.';
          break;
        }
        const updated = (registeredUsers || []).map(u => {
          const userMun = u.municipality || 'Cutias';
          if (userMun.toLowerCase() === targetMun) {
            return { ...u, role: 'gestor' as const };
          }
          return u;
        });
        onBulkUpdateUsers(updated);
        responseText = `SUCESSO: Todos os servidores customizados de "${targetMun.toUpperCase()}" foram promovidos a GESTORES municipais.`;
        showToast('Atualização de privilégios efetuada em lote!');
        break;
      }

      case 'fix_loops': {
        if (!onBulkUpdateDocuments) {
          responseText = 'Erro: Callback de atualização de documentos indisponível.';
          break;
        }
        let fixCount = 0;
        const updatedDocs = documents.map(doc => {
          if (doc.origin.toLowerCase() === doc.destination.toLowerCase() || 
             (doc.origin.includes('(') && doc.destination.includes('(') && 
              doc.origin.split('(')[1] === doc.destination.split('(')[1])) {
            fixCount++;
            const originalAbbr = doc.origin.split('(')[1]?.replace(')', '') || '';
            const defaultDest = DEPARTMENTS.find(d => d.acronym !== originalAbbr)?.name || DEPARTMENTS[1].name;
            return {
              ...doc,
              destination: defaultDest,
              history: [
                ...doc.history,
                {
                  id: `h-macro-fix-${Date.now()}`,
                  date: new Date().toISOString(),
                  user: 'Terminal (Script Exec)',
                  action: 'CORREÇÃO DE AUTO-LOOPING',
                  notes: `Redirecionamento técnico via terminal de comandos. Destinatário alterado para ${defaultDest}.`
                }
              ]
            };
          }
          return doc;
        });

        onBulkUpdateDocuments(updatedDocs);
        responseText = `SUCESSO: Laço infinito localizado em ${fixCount} documento(s) com endereçamento circular. Destinatário re-roteado.`;
        showToast(`Corrigido auto-looping em de ${fixCount} documento(s)!`);
        break;
      }

      case 'overdue_grace': {
        if (!onBulkUpdateDocuments) {
          responseText = 'Erro: Callback de atualização do banco de dados indisponível.';
          break;
        }
        const graceDays = args[0] ? parseInt(args[0], 10) : 15;
        if (isNaN(graceDays)) {
          responseText = 'Erro: Informe um número de dias válido. Ex: overdue_grace 15';
          break;
        }
        let modCount = 0;
        const updatedDocs = documents.map(doc => {
          const deadline = new Date(doc.deadlineDate);
          const today = new Date();
          if ((doc.status === 'Pendente' || doc.status === 'Em Análise' || doc.status === 'Atrasado') && deadline < today) {
            modCount++;
            const newDeadlineDate = new Date(today.getTime() + graceDays * 24 * 3600 * 1000).toISOString().split('T')[0];
            return {
              ...doc,
              deadlineDate: newDeadlineDate,
              status: 'Pendente' as const, // Clear layout block
              history: [
                ...doc.history,
                {
                  id: `h-macro-grace-${Date.now()}`,
                  date: new Date().toISOString(),
                  user: 'Terminal (Script Exec)',
                  action: 'OUTORGA DE PRAZO REGIMENTAL',
                  notes: `Celeridade de andamento pelo Master Auditor. Prazo estendido por +${graceDays} dias decorrentes de gargalos.`
                }
              ]
            };
          }
          return doc;
        });

        onBulkUpdateDocuments(updatedDocs);
        responseText = `SUCESSO: ${modCount} documento(s) com data vencida prorrogados por mais ${graceDays} dias em caráter excepcional.`;
        showToast(`Prazo estendido em ${modCount} documentos de forma bem-sucedida!`);
        break;
      }

      case 'approve_all': {
        const targetMun = args[0] ? args[0].toLowerCase() : currentMunicipality.toLowerCase();
        if (!onBulkUpdateDocuments) {
          responseText = 'Erro: Callback de atualização de documentos indisponível.';
          break;
        }
        let alteredCount = 0;
        const updatedDocs = documents.map(doc => {
          const docMun = doc.municipality || 'Cutias';
          if (docMun.toLowerCase() === targetMun && doc.status !== 'Concluído') {
            alteredCount++;
            return {
              ...doc,
              status: 'Concluído' as const,
              response: {
                text: 'PROCESSO DESPACHADO E HOMOLOGADO VIA DECRETO EXTRAORDINÁRIO PELO MASTER AUDITOR.',
                createdAt: new Date().toISOString(),
                responder: 'Master Auditor do Sistema Central'
              },
              history: [
                ...doc.history,
                {
                  id: `h-macro-appr-${Date.now()}`,
                  date: new Date().toISOString(),
                  user: 'Master Auditor',
                  action: 'HOMOLOGAÇÃO EM LOTE',
                  notes: 'Sancionado e arquivado via console terminal master de auditoria regulamentar.'
                }
              ]
            };
          }
          return doc;
        });

        onBulkUpdateDocuments(updatedDocs);
        responseText = `SUCESSO: Forçados como concluídos e deferidos ${alteredCount} processo(s) da prefeitura de ${targetMun.toUpperCase()}.`;
        showToast(`Aprovados em lote ${alteredCount} documentos!`);
        break;
      }

      case 'show_users': {
        const list = [...DEFAULT_USERS, ...(registeredUsers || [])];
        responseText = 'USUÁRIOS DE SISTEMA CADASTRADOS (DUMP REGULAMENTAR):\n';
        list.forEach((u, i) => {
          const mun = u.municipality || 'Cutias';
          responseText += `  [${i + 1}] @${u.username.padEnd(16, ' ')} | Nome: ${u.name.padEnd(22, ' ')} | Role: ${u.role.toUpperCase().padEnd(8, ' ')} | Mun: ${mun.toUpperCase() || 'CUTIAS'}\n`;
        });
        break;
      }

      case 'sql_sim': {
        const statusReq = args[0] ? args[0].toLowerCase() : 'atrasado';
        const rawResults = documents.filter(d => d.status.toLowerCase() === statusReq);
        responseText = `SQL SIMULADOR: SELECT * FROM documents WHERE status = '${statusReq.toUpperCase()}'\n`;
        responseText += `Resultados encontrados: ${rawResults.length} registros.\n`;
        rawResults.forEach((r, i) => {
          responseText += `  - [${i+1}] Protocolo: ${r.protocol} | Assunto: ${r.title.substring(0, 42)}... | Mun: ${r.municipality || 'Cutias'}\n`;
        });
        break;
      }

      default:
        responseText = `Comando desconhecido "${command}". Digite "help" para ver as opções válidas.`;
    }

    setTerminalLines(prev => [...prev, outputLog, ...responseText.split('\n')]);
    setTerminalInput('');
  };

  // Direct access permissions modifier for staff
  const handleModifyUserRights = (userId: string) => {
    if (!onBulkUpdateUsers) {
      showToast('Erro: Callback de atualização de usuários não configurado.', 'info');
      return;
    }
    
    // Check if it is a default user
    const isPrimary = DEFAULT_USERS.some(u => u.id === userId);
    if (isPrimary) {
      alert('Aviso de Segurança: Não é recomendável modificar privilégios dos usuários embutidos padrão para fins de integridade do app.');
    }

    const list = [...DEFAULT_USERS, ...(registeredUsers || [])];
    const userToEdit = list.find(u => u.id === userId);
    if (!userToEdit) {
      showToast('Erro: Usuário não localizado.', 'info');
      return;
    }

    const updated = (registeredUsers || []).map(u => {
      if (u.id === userId) {
        return {
          ...u,
          role: editUserRole as 'servidor' | 'gestor',
          department: editUserDept,
          municipality: editUserMun,
          password: editUserPassword || u.password
        };
      }
      return u;
    });

    onBulkUpdateUsers(updated);
    setEditingUserId(null);
    showToast(`Direitos de @${userToEdit.username} atualizados com sucesso!`);
    
    setTerminalLines(prev => [
      ...prev,
      `[${new Date().toLocaleTimeString()}] >> PRIVILÉGIOS DISTRIBUÍDOS: @${userToEdit.username}`,
      `  - Cargo atualizado para: ${editUserRole.toUpperCase()}`,
      `  - Novo departamento: ${editUserDept}`,
      `  - Comarca: ${editUserMun.toUpperCase()}`
    ]);
  };

  // Filter documents by user's search query inside Corrections tab
  const filteredDocs = documents.filter(doc => 
    doc.protocol.toLowerCase().includes(searchQuery.toLowerCase()) ||
    doc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    doc.origin.toLowerCase().includes(searchQuery.toLowerCase()) ||
    doc.destination.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      
      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className={`fixed bottom-4 right-4 z-50 p-3 rounded shadow-lg border flex items-center gap-2.5 max-w-sm animate-bounce ${
          toastMessage.type === 'success' 
            ? 'bg-emerald-50 border-emerald-300 text-emerald-800' 
            : 'bg-blue-50 border-blue-300 text-blue-800'
        }`}>
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span className="text-xs font-bold">{toastMessage.text}</span>
        </div>
      )}

      {/* Header Info */}
      <div className="bg-gradient-to-r from-amber-600 via-amber-700 to-slate-900 text-white rounded p-6 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 bg-white/10 backdrop-blur-md rounded flex items-center justify-center p-2 text-amber-300 shrink-0">
              <Shield className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h2 className="font-sans font-extrabold text-lg sm:text-xl uppercase tracking-wide">Acesso Master & Auditoria de Trâmite</h2>
              <p className="text-xs text-amber-100">Controles de infraestrutura, diagnósticos de redundância e correções eletrônicas em lote.</p>
            </div>
          </div>
          <div>
            <button
              id="master-btn-db-reset"
              onClick={handleFullReset}
              className="bg-red-700 hover:bg-red-800 text-white border border-red-500 font-extrabold text-xs px-3.5 py-2 rounded shadow-xs uppercase flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Resetar Banco Geral</span>
            </button>
          </div>
        </div>
      </div>

      {/* Internal Navigation Sub-Tabs */}
      <div className="flex border-b border-slate-300">
        <button
          onClick={() => { setActiveSubTab('errors'); setEditingDocId(null); }}
          className={`px-4 py-2 text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-2 border-b-2 ${
            activeSubTab === 'errors'
              ? 'border-amber-500 text-amber-700 bg-amber-50/40 font-black'
              : 'border-transparent text-slate-500 hover:text-slate-900 bg-transparent'
          }`}
        >
          <AlertCircle className={`w-3.5 h-3.5 ${systemErrors.length > 0 ? 'text-amber-600' : 'text-slate-405'}`} />
          <span>Análise de Erros ({systemErrors.length})</span>
        </button>
        <button
          onClick={() => setActiveSubTab('editing')}
          className={`px-4 py-2 text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-2 border-b-2 ${
            activeSubTab === 'editing'
              ? 'border-amber-500 text-amber-700 bg-amber-50/40 font-black'
              : 'border-transparent text-slate-500 hover:text-slate-900 bg-transparent'
          }`}
        >
          <Database className="w-3.5 h-3.5" />
          <span>Central de Correções (CRUD)</span>
        </button>
        <button
          onClick={() => { setActiveSubTab('system'); setEditingDocId(null); }}
          className={`px-4 py-2 text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-2 border-b-2 ${
            activeSubTab === 'system'
              ? 'border-amber-500 text-amber-700 bg-amber-50/40 font-black'
              : 'border-transparent text-slate-500 hover:text-slate-900 bg-transparent'
          }`}
        >
          <Server className="w-3.5 h-3.5" />
          <span>Integridade do Barramento</span>
        </button>
        <button
          onClick={() => { setActiveSubTab('municipalities'); setEditingDocId(null); }}
          className={`px-4 py-2 text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-2 border-b-2 ${
            activeSubTab === 'municipalities'
              ? 'border-amber-500 text-amber-700 bg-amber-50/40 font-black'
              : 'border-transparent text-slate-500 hover:text-slate-900 bg-transparent'
          }`}
        >
          <Building className="w-3.5 h-3.5" />
          <span>Gestão de Municípios</span>
        </button>
        <button
          onClick={() => { setActiveSubTab('advanced_db'); setEditingDocId(null); setSelectedDocIdForRawExplorer(documents[0]?.id || ''); }}
          className={`px-4 py-2 text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-2 border-b-2 ${
            activeSubTab === 'advanced_db'
              ? 'border-amber-500 text-amber-700 bg-amber-50/40 font-black'
              : 'border-transparent text-slate-500 hover:text-slate-900 bg-transparent'
          }`}
        >
          <Settings className="w-3.5 h-3.5 text-amber-700" />
          <span>Controles de Banco & Comandos</span>
        </button>
      </div>

      {/* Main master screens */}
      {activeSubTab === 'errors' && (
        <div className="space-y-4">
          <div className="bg-white border border-slate-300 rounded p-4">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wide mb-1 flex items-center gap-2">
              <Activity className="w-4 h-4 text-amber-500" />
              <span>Verificação Sintática e Validador de Negócios</span>
            </h3>
            <p className="text-[11px] text-slate-500">O robô de auditoria analisa o banco carregado na sessão e aponta gargalos regulamentares ou operacionais de Cutias-AP.</p>
          </div>

          {systemErrors.length === 0 ? (
            <div className="bg-emerald-50 border border-emerald-200 rounded p-6 text-center space-y-2">
              <ShieldCheck className="w-10 h-10 text-emerald-600 mx-auto" />
              <p className="text-sm font-bold text-slate-900 uppercase">Integridade Perfeita Detectada</p>
              <p className="text-xs text-slate-650 leading-relaxed max-w-md mx-auto">Nenhum erro de loop de redirecionamento, atraso crítico inativo ou anexo corrompido foi identificado no repositório de documentos atual.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {systemErrors.map((err) => (
                <div key={err.id} className="bg-white border border-slate-300 rounded p-4 flex flex-col justify-between hover:shadow-xs transition-shadow">
                  <div>
                    <div className="flex items-center justify-between gap-2 border-b border-slate-100 pb-2 mb-2">
                      <span className="text-[9px] font-mono font-bold bg-slate-100 border border-slate-200 px-1.5 py-0.5 rounded text-slate-700">
                        {err.code}
                      </span>
                      <span className={`text-[8px] font-bold uppercase px-1.5 py-0.5 rounded border ${
                        err.severity === 'Crítico' 
                          ? 'bg-red-50 text-red-700 border-red-200' 
                          : err.severity === 'Aviso'
                            ? 'bg-amber-50 text-amber-800 border-amber-200'
                            : 'bg-blue-50 text-blue-800 border-blue-200'
                      }`}>
                        {err.severity}
                      </span>
                    </div>

                    <h4 className="text-xs font-extrabold text-[#003366] uppercase mb-1 flex items-center gap-1.5">
                      <AlertTriangle className="w-3.5 h-3.5 shrink-0 text-amber-500" />
                      <span>{err.title}</span>
                    </h4>
                    <p className="text-[11px] text-slate-600 leading-normal mb-3 font-sans">
                      {err.description}
                    </p>
                    <div className="bg-amber-50/50 p-2 border border-amber-100 rounded text-[10px] text-amber-900 leading-relaxed">
                      <strong>Recomendação TI:</strong> {err.recommendation}
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                    <span className="text-[9px] text-slate-400 font-bold uppercase tracking-wider">Mapeado no Front</span>
                    <button
                      onClick={() => handleAutoResolve(err)}
                      className="bg-amber-600 hover:bg-amber-700 text-white font-extrabold text-[10px] uppercase tracking-wide px-3 py-1 rounded shadow-2xs flex items-center gap-1 cursor-pointer transition-colors"
                    >
                      <Wrench className="w-3 h-3" />
                      <span>Auto-Corrigir</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {activeSubTab === 'editing' && (
        <div className="space-y-4">
          
          {editingDocId ? (
            /* Editing interface form for chosen process */
            <form onSubmit={handleSaveCorrection} className="bg-white border border-slate-300 p-5 rounded space-y-4 animate-in fade-in-50 duration-200">
              <div className="border-b border-slate-200 pb-3 flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-black text-[#003366] uppercase">Corretor de Documento Unificado</h3>
                  <p className="text-[10px] text-slate-500">Modificação direta contornando restrições de departamento ou bloqueios de trâmite.</p>
                </div>
                <button
                  type="button"
                  onClick={handleCancelEdit}
                  className="text-slate-400 hover:text-slate-800 p-1 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-slate-700 uppercase mb-1">Assunto do Documento (Título) *</label>
                  <input
                    type="text"
                    required
                    value={editTitle}
                    onChange={(e) => setEditTitle(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded p-2 text-xs text-slate-800 text-slate-850 font-bold focus:bg-white focus:outline-none focus:border-amber-600"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-700 uppercase mb-1">Tipo de Matéria Legislativa/Interna</label>
                  <select
                    value={editType}
                    onChange={(e) => setEditType(e.target.value as DocumentType)}
                    className="w-full bg-slate-50 border border-slate-300 rounded p-2 text-xs font-bold focus:bg-white focus:outline-none"
                  >
                    <option value="Memorando">Memorando</option>
                    <option value="Ofício">Ofício</option>
                    <option value="Requerimento">Requerimento</option>
                    <option value="Portaria">Portaria</option>
                    <option value="Circular">Circular</option>
                    <option value="Comunicação Interna">Comunicação Interna</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-700 uppercase mb-1">Setor Remetente (Origem)</label>
                  <input
                    type="text"
                    required
                    value={editOrigin}
                    onChange={(e) => setEditOrigin(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded p-2 text-xs focus:bg-white focus:outline-none"
                    placeholder="Ex: Gabinete do Prefeito"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-700 uppercase mb-1">Setor Destinatário</label>
                  <input
                    type="text"
                    required
                    value={editDestination}
                    onChange={(e) => setEditDestination(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded p-2 text-xs focus:bg-white focus:outline-none"
                    placeholder="Ex: Gabinete do Prefeito"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-700 uppercase mb-1">Data Limite de Prorrogação (Deadline)</label>
                  <input
                    type="date"
                    required
                    value={editDeadline}
                    onChange={(e) => setEditDeadline(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded p-2 text-xs font-mono"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-700 uppercase mb-1">Prioridade</label>
                    <select
                      value={editPriority}
                      onChange={(e) => setEditPriority(e.target.value as PriorityType)}
                      className="w-full bg-slate-50 border border-slate-300 rounded p-2 text-xs font-bold focus:bg-white focus:outline-none"
                    >
                      <option value="Baixa">Baixa</option>
                      <option value="Média">Média</option>
                      <option value="Alta">Alta</option>
                      <option value="Urgente">Urgente</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-700 uppercase mb-1">Status Interno</label>
                    <select
                      value={editStatus}
                      onChange={(e) => setEditStatus(e.target.value as DocumentStatus)}
                      className="w-full bg-slate-50 border border-slate-300 rounded p-2 text-xs font-bold focus:bg-white focus:outline-none"
                    >
                      <option value="Pendente">Pendente</option>
                      <option value="Em Análise">Em Análise</option>
                      <option value="Atrasado">Atrasado</option>
                      <option value="Concluído">Concluído</option>
                    </select>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-700 uppercase mb-1">Descrição Textual ou Ementa Básica</label>
                <textarea
                  required
                  rows={3}
                  value={editDescription}
                  onChange={(e) => setEditDescription(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded p-2 text-xs focus:bg-white focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-amber-700 uppercase mb-1">Despacho Oficial / Resposta Vinculada (Conteúdo)</label>
                <textarea
                  rows={3}
                  placeholder="Deixe em branco para remover ou apagar a resposta atual do documento"
                  value={editResponseText}
                  onChange={(e) => setEditResponseText(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded p-2 text-xs focus:bg-white focus:outline-none border-amber-300 focus:border-amber-600 scrollbar-thin"
                />
              </div>

              <div className="pt-3 border-t border-slate-250 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={handleCancelEdit}
                  className="border border-slate-300 hover:bg-slate-100 text-slate-700 font-bold py-1.5 px-3.5 rounded text-xs uppercase cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="bg-amber-600 hover:bg-amber-700 text-white font-black py-1.5 px-4 rounded text-xs uppercase flex items-center gap-1 cursor-pointer transition-colors shadow-2xs"
                >
                  <Check className="w-4 h-4" />
                  <span>Salvar Alterações</span>
                </button>
              </div>
            </form>
          ) : (
            /* Document Table for adjustments and deletions */
            <div className="space-y-3">
              <div className="flex bg-white rounded border border-slate-300 p-2 items-center gap-2">
                <Search className="w-4 h-4 text-slate-400 shrink-0 ml-1.5" />
                <input
                  type="text"
                  placeholder="Pesquisar por assunto, número de protocolo, destino ou origem..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-transparent text-xs border-none outline-none text-slate-800 placeholder-slate-400"
                />
              </div>

              <div className="bg-white border border-slate-300 rounded overflow-hidden">
                <div className="p-3 bg-slate-50 border-b border-secondary border-slate-205 flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase text-slate-500 tracking-wider">Mesa de Operações de Ajuste</span>
                  <span className="text-[9px] font-mono text-slate-405 font-bold">Total Encontrado: {filteredDocs.length}</span>
                </div>

                {filteredDocs.length === 0 ? (
                  <div className="p-8 text-center text-slate-400 text-xs">Nenhum documento encontrado para correção com o termo pesquisado.</div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr className="bg-slate-100/50 text-[10px] text-slate-405 font-bold uppercase border-b border-slate-200">
                          <th className="p-3">Protocolo</th>
                          <th className="p-3">Assunto / Tipo</th>
                          <th className="p-3">Remetente/Destino</th>
                          <th className="p-3">Vencimento</th>
                          <th className="p-3">Estado</th>
                          <th className="p-3 text-right">Ações Master</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        {filteredDocs.map((doc) => (
                          <tr key={doc.id} className="hover:bg-slate-50 transition-colors">
                            <td className="p-3 text-emerald-800 font-extrabold font-mono">{doc.protocol}</td>
                            <td className="p-3 min-w-[200px]">
                              <p className="font-bold text-slate-800 truncate max-w-[260px]">{doc.title}</p>
                              <span className="text-[9px] bg-blue-50 text-[#003366] px-1 rounded font-bold uppercase">{doc.type}</span>
                            </td>
                            <td className="p-3">
                              <p className="text-[10px] text-slate-500 flex items-center gap-1 font-mono uppercase">
                                <span className="bg-emerald-50 text-emerald-700 font-bold px-0.5 rounded">O</span> 
                                {doc.origin.includes('(') ? doc.origin.split('(')[1]?.replace(')', '') : doc.origin.substring(0, 15)}
                              </p>
                              <p className="text-[10px] text-slate-500 flex items-center gap-1 font-mono mt-0.5 uppercase">
                                <span className="bg-amber-50 text-amber-700 font-bold px-0.5 rounded">D</span> 
                                {doc.destination.includes('(') ? doc.destination.split('(')[1]?.replace(')', '') : doc.destination.substring(0, 15)}
                              </p>
                            </td>
                            <td className="p-3 font-mono text-slate-600">{formatDate(doc.deadlineDate)}</td>
                            <td className="p-3">
                              <span className={`px-1.5 py-0.5 rounded-[3px] text-[9px] font-extrabold uppercase ${
                                doc.status === 'Concluído' 
                                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-250' 
                                  : doc.status === 'Atrasado'
                                    ? 'bg-red-100 text-red-800 border border-red-200'
                                    : 'bg-amber-100 text-amber-800 border border-amber-250'
                              }`}>
                                {doc.status}
                              </span>
                            </td>
                            <td className="p-3 text-right">
                              <div className="flex items-center justify-end gap-1.5">
                                <button
                                  onClick={() => handleEditClick(doc)}
                                  className="p-1 border border-slate-300 hover:border-amber-600 text-slate-605 bg-white hover:bg-amber-50 rounded cursor-pointer transition-colors"
                                  title="Editar Metadados Completo (Correção)"
                                >
                                  <Edit3 className="w-3.5 h-3.5 text-amber-700" />
                                </button>
                                <button
                                  onClick={() => handleDeleteClick(doc.id, doc.protocol)}
                                  className="p-1 border border-slate-300 hover:border-red-650 text-slate-605 bg-white hover:bg-red-50 rounded cursor-pointer transition-colors"
                                  title="Excluir Permanentemente (Expurgar)"
                                >
                                  <Trash2 className="w-3.5 h-3.5 text-red-700" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          )}

        </div>
      )}

      {activeSubTab === 'system' && (
        <div className="bg-white border border-slate-300 rounded p-5 space-y-5">
          <h3 className="text-xs font-extrabold uppercase text-[#003366] tracking-wide border-b border-slate-205 pb-3">Status de Integridade do Barramento Eletrônico</h3>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            <div className="p-3 bg-slate-50 border border-slate-250 rounded">
              <span className="text-[9px] font-bold text-slate-400 block uppercase tracking-wider">Storage Consolidado</span>
              <p className="text-sm font-extrabold text-[#003366] mt-0.5 font-mono">1.24 MB / 15.00 MB</p>
              <div className="w-full bg-slate-200 h-1.5 rounded-full mt-2.5 overflow-hidden">
                <div className="bg-emerald-500 h-1.5" style={{ width: '8.2%' }}></div>
              </div>
            </div>

            <div className="p-3 bg-slate-50 border border-slate-250 rounded">
              <span className="text-[9px] font-bold text-slate-400 block uppercase tracking-wider">Latência do Enlace Municipal</span>
              <p className="text-sm font-extrabold text-[#003366] mt-0.5 font-mono">14 ms (Status: Excelente)</p>
              <span className="text-[9px] text-emerald-600 font-bold block mt-2">● Conexão Segura Ativa (SSL)</span>
            </div>

            <div className="p-3 bg-slate-50 border border-slate-250 rounded">
              <span className="text-[9px] font-bold text-slate-400 block uppercase tracking-wider">Verificador de Assinaturas ICP-Brasil</span>
              <p className="text-sm font-extrabold text-[#003366] mt-0.5 font-mono">OK (100% Criptografado)</p>
              <span className="text-[9px] text-slate-500 mt-2 block font-sans">Carimbos de tempo e logs de auditoria não editáveis.</span>
            </div>
          </div>

          {/* Municipality Register & Switch Engine inside Master Console */}
          <div className="border border-slate-300 rounded p-4 bg-slate-50/50 space-y-4 animate-fade-in">
            <h4 className="text-xs font-extrabold uppercase text-[#003366] tracking-wide border-b border-slate-200 pb-2">
              Gerência e Seleção de Municípios Cadastrados ({municipalities.length})
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              
              {/* List and Switch */}
              <div className="space-y-2">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Municípios Disponíveis (Clique para Alternar Ativo)</span>
                <div className="bg-white border border-slate-200 rounded divide-y divide-slate-100 max-h-[160px] overflow-y-auto">
                  {municipalities.map(mun => (
                    <div key={mun} className="p-2.5 flex items-center justify-between text-xs font-semibold">
                      <span className="uppercase text-slate-700">{mun}</span>
                      {currentMunicipality.toLowerCase() === mun.toLowerCase() ? (
                        <span className="text-[9px] font-extrabold uppercase bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded border border-emerald-300">Ativo</span>
                      ) : (
                        <button
                          type="button"
                          onClick={() => {
                            if (onSelectMunicipality) {
                              onSelectMunicipality(mun);
                              showToast(`Município alternado para ${mun}!`);
                            }
                          }}
                          className="text-[9px] font-bold text-blue-800 hover:underline uppercase bg-blue-50 hover:bg-blue-100 px-2 py-0.5 rounded border border-blue-200 cursor-pointer"
                        >
                          Alternar
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Inline Form to Register */}
              <div className="space-y-2">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Cadastrar Novo Município</span>
                <div className="p-3 bg-white border border-slate-200 rounded space-y-3">
                  <div>
                    <label className="block text-[9px] font-bold text-slate-650 uppercase mb-1">Nome Oficial do Município</label>
                    <input
                      type="text"
                      placeholder="Ex: Mazagão"
                      value={newMunicName}
                      onChange={(e) => { setNewMunicName(e.target.value); setMunicError(''); }}
                      className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 text-xs text-slate-850 font-bold focus:bg-white focus:outline-none focus:border-amber-600 uppercase"
                    />
                  </div>
                  {municError && (
                    <p className="text-[10px] text-red-650 font-bold">⚠️ {municError}</p>
                  )}
                  <button
                    type="button"
                    onClick={() => {
                      const nameTrim = newMunicName.trim();
                      if (!nameTrim) return;
                      if (municipalities.some(m => m.toLowerCase() === nameTrim.toLowerCase())) {
                        setMunicError('Município já cadastrado.');
                        return;
                      }
                      if (onAddMunicipality) {
                        onAddMunicipality(nameTrim);
                        setNewMunicName('');
                        showToast(`Município ${nameTrim} cadastrado com sucesso!`);
                      }
                    }}
                    className="w-full bg-amber-600 hover:bg-amber-700 text-white font-extrabold text-[10px] uppercase tracking-wide py-1.5 px-3 rounded shadow-2xs flex items-center justify-center gap-1 cursor-pointer transition-colors"
                  >
                    <span>Cadastrar Município</span>
                  </button>
                </div>
              </div>

            </div>
          </div>

          <div className="p-3.5 bg-amber-50 border border-amber-200 rounded text-xs text-amber-900 leading-normal flex gap-2">
            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <p>
              <strong>Por que existem as auditorias?</strong> Para garantir que nenhuma lotação da prefeitura de {currentMunicipality} altere um documento sem a auditoria técnica da Controladoria Geral. Como Master Auditor, você tem a senha mestra para intervir em casos de urgência social ou erros formais de digitação.
            </p>
          </div>
        </div>
      )}

      {/* NEW Municipalities & Staff management sub-tab */}
      {activeSubTab === 'municipalities' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-start font-sans animate-fade-in pb-8">
          
          {/* Card left column (1/3 of space) for Municipality list & addition */}
          <div className="md:col-span-1 space-y-4">
            
            {/* List block */}
            <div className="bg-white border border-slate-300 rounded p-4 space-y-3 shadow-xs">
              <h3 className="text-xs font-extrabold uppercase text-[#003366] tracking-wide border-b border-slate-100 pb-2 flex items-center gap-1">
                <Building className="w-3.5 h-3.5 text-[#003366]" />
                <span>Municípios Disponíveis ({municipalities.length})</span>
              </h3>

              <div className="space-y-2 max-h-[380px] overflow-y-auto pr-1 scrollbar-thin">
                {municipalities.map((mun) => {
                  const isSuspended = suspendedMunicipalities.includes(mun);
                  const isCurrent = currentMunicipality.toLowerCase() === mun.toLowerCase();
                  const isViewingStaff = selectedMunForStaff.toLowerCase() === mun.toLowerCase();
                  
                  return (
                    <div 
                      key={mun} 
                      className={`p-3 rounded border transition-all space-y-2.5 ${
                        isViewingStaff 
                          ? 'border-amber-600 bg-amber-50/20 ring-1 ring-amber-500' 
                          : 'border-slate-200 hover:border-slate-300 bg-white'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-1.5 min-w-0">
                        <span className={`text-xs font-extrabold uppercase truncate ${
                          isSuspended ? 'text-slate-400 line-through' : 'text-slate-800 font-sans'
                        }`}>{mun}</span>
                        
                        <div className="flex items-center gap-1 shrink-0">
                          {isCurrent && (
                            <span className="text-[8px] font-extrabold bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded border border-emerald-300 uppercase">
                              Conectado
                            </span>
                          )}
                          {isSuspended ? (
                            <span className="text-[8px] font-black bg-red-100 text-red-850 px-1.5 py-0.5 rounded border border-red-300 uppercase">
                              Suspenso
                            </span>
                          ) : (
                            <span className="text-[8px] font-black bg-blue-100 text-[#003366] px-1.5 py-0.5 rounded border border-blue-200 uppercase">
                              Ativo
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="flex flex-wrap gap-1.5 pt-2 border-t border-slate-100 justify-between items-center bg-transparent">
                        <div className="flex gap-1 bg-transparent">
                          <button
                            type="button"
                            onClick={() => setSelectedMunForStaff(mun)}
                            className={`text-[9px] font-black uppercase px-2 py-1 rounded border transition-all cursor-pointer ${
                              isViewingStaff 
                                ? 'bg-amber-600 text-white border-amber-600 shadow-2xs'
                                : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                            }`}
                          >
                            👥 Pessoal Interno
                          </button>

                          {!isCurrent && !isSuspended && onSelectMunicipality && (
                            <button
                              type="button"
                              onClick={() => {
                                onSelectMunicipality(mun);
                                showToast(`Conectado ao município de ${mun}!`);
                              }}
                              className="text-[9px] font-black text-emerald-800 bg-emerald-50 hover:bg-emerald-100 px-2 py-1 rounded border border-emerald-250 uppercase transition-colors shrink-0 cursor-pointer"
                            >
                              📍 Conectar
                            </button>
                          )}
                        </div>

                        <div className="flex gap-1 bg-transparent">
                          {isSuspended ? (
                            <button
                              type="button"
                              onClick={() => {
                                if (onReactivateMunicipality) {
                                  onReactivateMunicipality(mun);
                                  showToast(`Município de ${mun} reativado com sucesso!`);
                                }
                              }}
                              className="text-[9px] font-black text-emerald-800 bg-emerald-50 hover:bg-emerald-100 px-2 py-1 rounded border border-emerald-250 uppercase transition-colors shrink-0 cursor-pointer"
                            >
                              Reativar
                            </button>
                          ) : (
                            <button
                              type="button"
                              onClick={() => {
                                if (isCurrent) {
                                  alert('Você está conectado neste município! Alterne para outro município ativo antes de suspendê-lo.');
                                  return;
                                }
                                if (confirm(`Tem certeza que deseja SUSPENDER o município de ${mun}? Isso desativará o login e bloqueará imediatamente todos os seus servidores.`)) {
                                  if (onSuspendMunicipality) {
                                    onSuspendMunicipality(mun);
                                    showToast(`Município de ${mun} suspenso com sucesso.`, 'info');
                                  }
                                }
                              }}
                              className="text-[9px] font-black text-red-800 bg-red-50 hover:bg-red-100 px-2 py-1 rounded border border-red-250 uppercase transition-colors shrink-0 cursor-pointer"
                            >
                              Suspender
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Inline creation of municipality */}
            <div className="bg-slate-50 border border-slate-300 rounded p-4 space-y-3 shadow-xs">
              <span className="text-[10px] font-bold text-slate-700 uppercase tracking-wider block">Cadastrar Novo Município</span>
              <div className="space-y-2">
                <div>
                  <label className="block text-[9px] font-bold text-slate-655 uppercase mb-1">Nome Oficial da Cidade</label>
                  <input
                    type="text"
                    placeholder="Ex: Mazagão"
                    value={newMunicName}
                    onChange={(e) => { setNewMunicName(e.target.value); setMunicError(''); }}
                    className="w-full bg-white border border-slate-330 rounded p-1.5 text-xs text-slate-850 font-bold focus:bg-white focus:outline-none focus:border-amber-605 uppercase"
                  />
                </div>
                {municError && (
                  <p className="text-[10px] text-red-650 font-bold">⚠️ {municError}</p>
                )}
                <button
                  type="button"
                  onClick={() => {
                    const nameTrim = newMunicName.trim();
                    if (!nameTrim) return;
                    if (municipalities.some(m => m.toLowerCase() === nameTrim.toLowerCase())) {
                      setMunicError('Este município já está cadastrado.');
                      return;
                    }
                    if (onAddMunicipality) {
                      onAddMunicipality(nameTrim);
                      setNewMunicName('');
                      showToast(`Município ${nameTrim} cadastrado com sucesso!`);
                      setSelectedMunForStaff(nameTrim);
                    }
                  }}
                  className="w-full bg-amber-600 hover:bg-amber-700 text-white font-extrabold text-[10px] uppercase tracking-wide py-2 px-3 rounded shadow-2xs flex items-center justify-center gap-1 cursor-pointer transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Cadastrar Município</span>
                </button>
              </div>
            </div>

          </div>

          {/* Right columns (2/3 of space) for staff management */}
          <div className="md:col-span-2 space-y-4">
            
            <div className="bg-white border border-slate-300 rounded p-5 space-y-5 shadow-xs">
              <div className="border-b border-slate-200 pb-3 flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                <div>
                  <h3 className="text-xs font-black uppercase text-[#003366] tracking-wide inline-flex items-center gap-1.5">
                    <User className="w-4 h-4 text-amber-650" />
                    <span>Lotação de Pessoal: {selectedMunForStaff.toUpperCase()}</span>
                  </h3>
                  <p className="text-[10px] text-slate-500">Adicione ou remova pessoal interno (Servidores e Gestores) da prefeitura de {selectedMunForStaff}.</p>
                </div>
                <div>
                  <span className="text-[9px] font-black uppercase tracking-wider bg-amber-50 text-amber-805 px-2 py-1 rounded border border-amber-200">
                    Sub-Aba de Pessoal Interno
                  </span>
                </div>
              </div>

              {/* Add staff form */}
              <div className="bg-slate-50 border border-slate-200 rounded p-4 space-y-3.5">
                <span className="text-[10px] font-bold text-slate-700 uppercase tracking-wider block">Inscrever Novo Membro em {selectedMunForStaff}</span>
                
                {staffError && (
                  <p className="p-2 bg-red-50 text-red-700 text-[10px] font-bold rounded">⚠️ {staffError}</p>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[9px] font-bold text-slate-600 uppercase mb-1">Nome Completo</label>
                    <input
                      type="text"
                      placeholder="Ex: Carlos Silva"
                      value={staffName}
                      onChange={(e) => { setStaffName(e.target.value); setStaffError(''); }}
                      className="w-full bg-white border border-slate-300 rounded p-1.5 text-xs font-bold text-slate-800 focus:outline-none focus:border-amber-600"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-[9px] font-bold text-slate-600 uppercase mb-1">Login (username)</label>
                    <input
                      type="text"
                      placeholder="Ex: carlos.silva"
                      value={staffUser}
                      onChange={(e) => { setStaffUser(e.target.value); setStaffError(''); }}
                      className="w-full bg-white border border-slate-300 rounded p-1.5 text-xs text-slate-800 font-mono focus:outline-none focus:border-amber-600"
                    />
                  </div>

                  <div>
                    <label className="block text-[9px] font-bold text-slate-600 uppercase mb-1">Senha</label>
                    <input
                      type="password"
                      placeholder="Senha provisória"
                      value={staffPass}
                      onChange={(e) => { setStaffPass(e.target.value); setStaffError(''); }}
                      className="w-full bg-white border border-slate-300 rounded p-1.5 text-xs font-mono focus:outline-none focus:border-amber-600"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pb-1">
                  <div>
                    <label className="block text-[9px] font-bold text-slate-600 uppercase mb-1">Cargo/Função Institucional</label>
                    <select
                      value={staffRole}
                      onChange={(e) => setStaffRole(e.target.value as 'servidor' | 'gestor')}
                      className="w-full bg-white border border-slate-300 rounded p-1.5 text-xs font-bold focus:outline-none focus:border-[#003366] text-slate-800"
                    >
                      <option value="servidor">✍️ Servidor (Operacional)</option>
                      <option value="gestor">🔑 Gestor (Autoridade)</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-[9px] font-bold text-slate-600 uppercase mb-1">Secretaria Escolhida</label>
                    <select
                      value={staffDept}
                      onChange={(e) => setStaffDept(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded p-1.5 text-xs font-bold focus:outline-none focus:border-[#003366] text-slate-800"
                    >
                      {DEPARTMENTS.map((dept) => (
                        <option key={`staff-dept-${dept.id}`} value={`${dept.name} (${dept.acronym})`}>
                          🏢 {dept.name} ({dept.acronym})
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    const nameTrim = staffName.trim();
                    const userTrim = staffUser.trim().toLowerCase();
                    const passTrim = staffPass.trim();

                    if (!nameTrim || !userTrim || !passTrim) {
                      setStaffError('Preencha nome completo, login e senha do servidor.');
                      return;
                    }

                    // Check duplicate usernames
                    const allUsers = [...DEFAULT_USERS, ...(registeredUsers || [])];
                    if (allUsers.some(u => u.username.toLowerCase() === userTrim.toLowerCase())) {
                      setStaffError('Este nome de login (username) já está sendo utilizado por outro servidor cadastrado.');
                      return;
                    }

                    const newStaff: AppUser = {
                      id: `u-custom-${Date.now()}`,
                      name: nameTrim,
                      username: userTrim,
                      password: passTrim,
                      role: staffRole,
                      department: staffDept,
                      municipality: selectedMunForStaff
                    };

                    if (onAddStaffMember) {
                      onAddStaffMember(newStaff);
                      setStaffName('');
                      setStaffUser('');
                      setStaffPass('');
                      showToast(`Novo servidor ${nameTrim} cadastrado com sucesso no quadro de ${selectedMunForStaff}!`);
                    }
                  }}
                  className="w-full bg-amber-600 hover:bg-amber-700 text-white font-extrabold text-[10px] uppercase tracking-wide py-2 px-3 rounded shadow-2xs flex items-center justify-center gap-1 cursor-pointer transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Cadastrar Servidor no Quadro</span>
                </button>
              </div>

              {/* Table list of staff */}
              <div className="space-y-3">
                <div className="flex bg-slate-50 border border-slate-200 rounded p-2 items-center gap-2 text-xs">
                  <Search className="w-4 h-4 text-slate-400 shrink-0 ml-1.5" />
                  <input
                    type="text"
                    placeholder="Filtrar servidores cadastrados por nome ou login..."
                    value={staffSearchQuery}
                    onChange={(e) => setStaffSearchQuery(e.target.value)}
                    className="w-full bg-transparent outline-none text-xs text-slate-800 placeholder-slate-400 font-semibold"
                  />
                </div>

                <div className="border border-slate-200 rounded divide-y divide-slate-150 overflow-hidden bg-white">
                  <div className="p-3 bg-slate-50 border-b border-slate-200 text-[10px] font-extrabold text-slate-500 uppercase tracking-widest flex items-center justify-between">
                    <span>Quadro Geral de Servidores em {selectedMunForStaff}</span>
                    <span className="font-mono text-[9px] text-[#003366] bg-blue-50 px-1.5 rounded font-bold">Total: {
                      [...DEFAULT_USERS, ...(registeredUsers || [])].filter(u => {
                        const userMun = u.municipality || 'Cutias';
                        return userMun.toLowerCase() === selectedMunForStaff.toLowerCase();
                      }).length
                    }</span>
                  </div>

                  <div className="max-h-[300px] overflow-y-auto divide-y divide-slate-100">
                    {(() => {
                      const list = [...DEFAULT_USERS, ...(registeredUsers || [])].filter(u => {
                        const userMun = u.municipality || 'Cutias';
                        if (userMun.toLowerCase() !== selectedMunForStaff.toLowerCase()) return false;
                        
                        // Search query match
                        const q = staffSearchQuery.toLowerCase();
                        return u.name.toLowerCase().includes(q) || u.username.toLowerCase().includes(q);
                      });

                      if (list.length === 0) {
                        return <div className="p-6 text-center text-xs text-slate-400">Nenhum servidor localizado neste município para o filtro atual.</div>;
                      }

                      return list.map((user) => {
                        const isPrimary = DEFAULT_USERS.some(u => u.id === user.id);
                        return (
                          <div key={user.id} className="p-3 flex items-center justify-between text-xs hover:bg-slate-50/50">
                            <div className="min-w-0 pr-2">
                              <p className="font-bold text-slate-800">{user.name}</p>
                              <p className="text-[10px] text-slate-500 font-medium flex flex-wrap items-center gap-1 mt-0.5">
                                <span className="font-mono font-bold bg-slate-100 px-1 rounded text-slate-600 font-bold">@{user.username}</span> 
                                <span className="text-slate-300">•</span> 
                                <span className="text-blue-800 font-bold uppercase">{user.role === 'gestor' ? 'Gestor' : user.role === 'master' ? 'Master' : 'Servidor'}</span>
                                <span className="text-slate-300">•</span>
                                <span className="truncate max-w-[200px]">{user.department}</span>
                              </p>
                            </div>

                            <div className="shrink-0 pl-2">
                              {isPrimary ? (
                                <span className="text-[9px] bg-slate-100 text-slate-400 px-1.5 py-0.5 rounded border border-slate-200 font-bold uppercase select-none" title="Servidores do sistema padrão não podem ser excluídos.">
                                  Default
                                </span>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => {
                                    if (confirm(`Excluir permanentemente o cadastro de @${user.username} (${user.name})?`)) {
                                      if (onDeleteStaffMember) {
                                        onDeleteStaffMember(user.id);
                                        showToast(`Cadastro de @${user.username} removido com sucesso de ${selectedMunForStaff}!`, 'info');
                                      }
                                    }
                                  }}
                                  className="text-[9px] font-black text-red-700 bg-red-50 hover:bg-red-100 px-2 py-1.5 rounded border border-red-200 uppercase transition-colors shrink-0 cursor-pointer"
                                >
                                  Excluir
                                </button>
                              )}
                            </div>
                          </div>
                        );
                      });
                    })()}
                  </div>
                </div>

              </div>
            </div>

          </div>

        </div>
      )}

      {activeSubTab === 'advanced_db' && (
        <div className="space-y-6 font-sans animate-fade-in pb-12">
          
          {/* Top warning/explanation card */}
          <div className="bg-slate-900 border border-slate-700 text-slate-100 rounded p-5 shadow-md flex items-start gap-4">
            <Cpu className="w-8 h-8 text-amber-500 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <h3 className="text-sm font-black uppercase tracking-wide text-amber-400">Ambiente Administrativo de Alto Privilégio (DBMS & Terminal)</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Esta área destina-se exclusivamente ao Auditor de TI Corporativo. Aqui você pode inicializar datasets dedicados das prefeituras, rodar rotinas automatizadas e macros corretivas via terminal de comandos, e alterar livremente chaves de acesso e distribuições de privilégios institucionais.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            
            {/* LEFT COLUMN: Datasets & Generator (Grid Span 5) */}
            <div className="lg:col-span-5 space-y-6">
              
              {/* Box 1: Criar Banco de Dados Dedicado */}
              <div className="bg-white border border-slate-300 rounded p-4 shadow-xs space-y-4">
                <h3 className="text-xs font-black text-slate-900 uppercase tracking-wider border-b border-slate-100 pb-2 flex items-center gap-2">
                  <Building className="w-4 h-4 text-amber-600" />
                  <span>Inicializar Banco Escopado por Prefeitura</span>
                </h3>
                <p className="text-[11px] text-slate-500 leading-normal">
                  Selecione uma comarca cadastrada e um perfil temático para injetar ou sobrescrever uma base de dados realista (ofícios, pendências e históricos) customizada.
                </p>

                <div className="space-y-3 bg-slate-50 p-3.5 border border-slate-200 rounded">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-700 uppercase mb-1">Prefeitura de Destino</label>
                    <select
                      value={selectedMunForDbCreation}
                      onChange={(e) => setSelectedMunForDbCreation(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded p-2 text-xs font-bold text-slate-800 focus:outline-none focus:border-amber-600"
                    >
                      {municipalities.map(m => (
                        <option key={`mun-db-opt-${m}`} value={m}>🏢 PREFEITURA DE {m.toUpperCase()}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-slate-700 uppercase mb-1">Tema / Preset de Documentos</label>
                    <div className="grid grid-cols-2 gap-2">
                      {[
                        { id: 'completo', title: '💼 Completo', desc: 'Todas as áreas' },
                        { id: 'saude', title: '🍏 Saúde Pública', desc: 'SEMUSA & vacinas' },
                        { id: 'educacao', title: '📚 Educacional', desc: 'SEMED & escolas' },
                        { id: 'urbanismo', title: '🚧 Obras & Vias', desc: 'SEMOSP infra' }
                      ].map((preset) => (
                        <button
                          key={preset.id}
                          type="button"
                          onClick={() => setCreatedDbPresetType(preset.id as any)}
                          className={`p-2 rounded border text-left flex flex-col transition-all cursor-pointer ${
                            createdDbPresetType === preset.id
                              ? 'border-amber-600 bg-amber-50/20 ring-1 ring-amber-500 font-sans'
                              : 'border-slate-200 bg-white hover:border-slate-300 font-sans'
                          }`}
                        >
                          <span className="text-[10px] font-bold text-slate-800">{preset.title}</span>
                          <span className="text-[8px] text-slate-500 font-medium">{preset.desc}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      if (confirm(`Atenção: Isso irá criar ou reformatar os registros de "${selectedMunForDbCreation.toUpperCase()}" com o preset "${createdDbPresetType.toUpperCase()}". Prosseguir?`)) {
                        handleCreateDatabaseForMunicipality(selectedMunForDbCreation, createdDbPresetType);
                      }
                    }}
                    className="w-full bg-amber-600 hover:bg-amber-700 text-white font-extrabold text-xs uppercase py-2 rounded shadow-2xs flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Gerar / Semeiar Banco de Dados</span>
                  </button>
                </div>
              </div>

              {/* Box 2: Console Terminal Interactive */}
              <div className="bg-slate-950 text-emerald-400 rounded p-4 shadow-lg border border-slate-800 flex flex-col space-y-3 font-mono text-[11px]">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2 text-[10px] text-slate-400 uppercase tracking-widest font-sans font-bold">
                  <span className="flex items-center gap-1.5 text-emerald-500 font-sans">
                    <Terminal className="w-4 h-4 text-emerald-500 shrink-0" />
                    CONSOLES DE SCRIPTING MASTER
                  </span>
                  <span className="bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded text-[8px] border border-slate-700 font-semibold font-sans">ONLINE</span>
                </div>

                <div className="bg-slate-900/40 p-3 border border-slate-900 rounded max-h-[220px] overflow-y-auto pr-1 space-y-1.5 scrollbar-thin">
                  {terminalLines.map((line, idx) => (
                    <div key={`term-line-${idx}`} className="whitespace-pre-wrap leading-relaxed select-text text-emerald-300">
                      {line}
                    </div>
                  ))}
                </div>

                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    handleExecuteTerminalCommand(terminalInput);
                  }}
                  className="flex items-center gap-2 border border-slate-800 bg-slate-900 rounded px-2.5 py-1"
                >
                  <span className="text-emerald-500 font-black shrink-0 font-mono select-none">$</span>
                  <input
                    type="text"
                    placeholder="Digite seu macro comando (ex: help, db_status)..."
                    value={terminalInput}
                    onChange={(e) => setTerminalInput(e.target.value)}
                    className="w-full bg-transparent border-none outline-none text-xs text-slate-100 font-mono"
                  />
                  <button
                    type="submit"
                    className="bg-emerald-800 hover:bg-emerald-700 text-white font-bold text-[9px] uppercase px-2 py-0.5 rounded cursor-pointer shrink-0 transition-colors font-sans"
                  >
                    Executar
                  </button>
                </form>

                <div className="grid grid-cols-2 gap-1.5 pt-1 text-[10px] text-slate-400">
                  <button
                    type="button"
                    onClick={() => handleExecuteTerminalCommand('db_status')}
                    className="p-1 px-2 border border-slate-800 rounded bg-slate-900/60 hover:bg-slate-900 hover:text-white transition-colors cursor-pointer text-left font-sans flex items-center justify-between"
                  >
                    <span>📊 Status Resumido</span>
                    <Play className="w-2.5 h-2.5 text-emerald-500" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleExecuteTerminalCommand('fix_loops')}
                    className="p-1 px-2 border border-slate-800 rounded bg-slate-900/60 hover:bg-slate-900 hover:text-white transition-colors cursor-pointer text-left font-sans flex items-center justify-between"
                  >
                    <span>🔄 Corrigir Loops</span>
                    <Play className="w-2.5 h-2.5 text-emerald-500" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleExecuteTerminalCommand('overdue_grace 15')}
                    className="p-1 px-2 border border-slate-800 rounded bg-slate-900/60 hover:bg-slate-900 hover:text-white transition-colors cursor-pointer text-left font-sans flex items-center justify-between"
                  >
                    <span>📅 Prorrogar +15 Dias</span>
                    <Play className="w-2.5 h-2.5 text-emerald-500" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleExecuteTerminalCommand('show_users')}
                    className="p-1 px-2 border border-slate-800 rounded bg-slate-900/60 hover:bg-slate-900 hover:text-white transition-colors cursor-pointer text-left font-sans flex items-center justify-between"
                  >
                    <span>👤 Listar Servidores</span>
                    <Play className="w-2.5 h-2.5 text-emerald-500" />
                  </button>
                </div>
              </div>

            </div>

            {/* RIGHT COLUMN: Database Explorer & User Rights Distribution (Grid Span 7) */}
            <div className="lg:col-span-7 space-y-6">
              
              {/* Card 1: Distribuição e Verificação de Acessos */}
              <div className="bg-white border border-slate-300 rounded p-4 shadow-xs space-y-4">
                <div className="border-b border-slate-100 pb-2">
                  <h3 className="text-xs font-black text-slate-900 uppercase tracking-wider flex items-center gap-1.5 font-sans">
                    <ShieldCheck className="w-4 h-4 text-indigo-700 font-sans animate-pulse" />
                    <span>Auditoria e Controle de Direitos de Acesso</span>
                  </h3>
                  <p className="text-[10px] text-slate-500">Verifique acessos cadastrados em todas as comarcas, promova a Gestor ou altere escopo departamental.</p>
                </div>

                {/* Sub-Interface for editing a user's rights */}
                {editingUserId ? (
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      handleModifyUserRights(editingUserId);
                    }}
                    className="bg-indigo-50/50 p-4 border border-indigo-200 rounded text-xs space-y-3 animate-fade-in"
                  >
                    <div className="flex items-center justify-between border-b border-indigo-150 pb-2">
                      <span className="font-extrabold uppercase text-indigo-900 text-[10px]">Alteração de Privilégios Extraordinários</span>
                      <button
                        type="button"
                        onClick={() => setEditingUserId(null)}
                        className="text-slate-400 hover:text-slate-700 p-0.5 cursor-pointer"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[9px] font-bold text-slate-700 uppercase mb-1">Nível Hierárquico</label>
                        <select
                          value={editUserRole}
                          onChange={(e) => setEditUserRole(e.target.value as any)}
                          className="w-full bg-white border border-slate-300 rounded p-1.5 text-xs text-slate-800 font-bold focus:outline-none focus:border-indigo-500"
                        >
                          <option value="servidor">✍️ Servidor (Operacional)</option>
                          <option value="gestor">🔑 Gestor (Autoridade Assinatura)</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-[9px] font-bold text-slate-700 uppercase mb-1">Redefinir Senha de Acesso</label>
                        <input
                          type="password"
                          placeholder="Manter senha atual"
                          value={editUserPassword}
                          onChange={(e) => setEditUserPassword(e.target.value)}
                          className="w-full bg-white border border-slate-300 rounded p-1.5 text-xs font-mono focus:outline-none focus:border-indigo-500"
                        />
                      </div>

                      <div>
                        <label className="block text-[9px] font-bold text-slate-700 uppercase mb-1">Secretaria / Setor Vinculado</label>
                        <select
                          value={editUserDept}
                          onChange={(e) => setEditUserDept(e.target.value)}
                          className="w-full bg-white border border-slate-300 rounded p-1.5 text-xs text-slate-800 font-semibold focus:outline-none focus:border-indigo-500"
                        >
                          {DEPARTMENTS.map(dept => (
                            <option key={`edit-user-dept-${dept.id}`} value={`${dept.name} (${dept.acronym})`}>🏢 {dept.name} ({dept.acronym})</option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-[9px] font-bold text-slate-700 uppercase mb-1">Jurisdição Municipal</label>
                        <select
                          value={editUserMun}
                          onChange={(e) => setEditUserMun(e.target.value)}
                          className="w-full bg-white border border-slate-300 rounded p-1.5 text-xs text-slate-800 font-semibold focus:outline-none focus:border-indigo-500"
                        >
                          {municipalities.map(mun => (
                            <option key={`edit-user-mun-opt-${mun}`} value={mun}>📍 {mun.toUpperCase()}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div className="flex items-center justify-end gap-2 pt-2 border-t border-indigo-150 bg-transparent">
                      <button
                        type="button"
                        onClick={() => setEditingUserId(null)}
                        className="bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 text-[10px] font-bold uppercase py-1 px-2.5 rounded cursor-pointer"
                      >
                        Cancelar
                      </button>
                      <button
                        type="submit"
                        className="bg-indigo-700 hover:bg-indigo-800 text-white text-[10px] font-bold uppercase py-1 px-3.5 rounded shadow-2xs cursor-pointer"
                      >
                        Aplicar Privilégios
                      </button>
                    </div>
                  </form>
                ) : null}

                {/* Users List with dynamic filters inside DB Tab */}
                <div className="space-y-3">
                  <div className="flex bg-slate-50 border border-slate-200 rounded px-2.5 py-1.5 items-center gap-1.5">
                    <Search className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <input
                      type="text"
                      placeholder="Pesquisar por nome de servidor, login ou repartição..."
                      value={advUserFilter}
                      onChange={(e) => setAdvUserFilter(e.target.value)}
                      className="w-full bg-transparent outline-none text-xs text-slate-800 placeholder-slate-400 font-semibold"
                    />
                  </div>

                  <div className="border border-slate-200 rounded overflow-hidden max-h-[220px] overflow-y-auto scrollbar-thin divide-y divide-slate-100 bg-white">
                    {(() => {
                      const allList = [...DEFAULT_USERS, ...(registeredUsers || [])];
                      const filteredList = allList.filter(u => {
                        const q = advUserFilter.toLowerCase();
                        return u.name.toLowerCase().includes(q) || u.username.toLowerCase().includes(q) || u.department.toLowerCase().includes(q);
                      });

                      if (filteredList.length === 0) {
                        return <div className="p-6 text-center text-xs text-slate-400">Nenhum servidor localizado com os filtros inseridos.</div>;
                      }

                      return filteredList.map(user => {
                        return (
                          <div key={`adv-user-row-${user.id}`} className="p-2.5 flex items-center justify-between text-xs hover:bg-slate-50">
                            <div className="min-w-0 pr-2">
                              <div className="flex items-center gap-2">
                                <span className="font-extrabold text-slate-800">{user.name}</span>
                                <span className="text-[9px] font-mono font-bold bg-indigo-50 text-indigo-700 px-1 py-0.5 rounded border border-indigo-200 uppercase">@{user.username}</span>
                              </div>
                              <p className="text-[10px] text-slate-500 font-medium flex items-center gap-1.5 mt-0.5">
                                <span className="font-bold text-slate-650 uppercase">{user.role === 'gestor' ? '👑 Gestor' : user.role === 'master' ? '🛡️ Master' : '✍️ Servidor'}</span>
                                <span>•</span>
                                <span className="truncate max-w-[200px]">{user.department}</span>
                                <span>•</span>
                                <span className="font-bold font-sans text-slate-700 bg-slate-100 hover:bg-slate-200 px-1 rounded transition-colors uppercase">{user.municipality || 'Cutias'}</span>
                              </p>
                            </div>

                            <div className="shrink-0 flex items-center gap-2">
                              {user.role === 'master' ? (
                                <span className="text-[9px] text-amber-700 font-extrabold bg-amber-50 px-2 py-1 rounded border border-amber-205">Full Root</span>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => {
                                    setEditingUserId(user.id);
                                    setEditUserRole(user.role as any);
                                    setEditUserDept(user.department);
                                    setEditUserMun(user.municipality || 'Cutias');
                                    setEditUserPassword('');
                                    showToast(`Configurando direitos corporativos de @${user.username}...`, 'info');
                                  }}
                                  className="text-[9px] text-[#003366] hover:bg-blue-50 font-black uppercase tracking-wide border border-blue-200 px-2.5 py-1 rounded cursor-pointer transition-colors"
                                >
                                  🔑 Modificar Acesso
                                </button>
                              )}
                            </div>
                          </div>
                        );
                      });
                    })()}
                  </div>
                </div>
              </div>

              {/* Card 2: Explorador de Registros Primitivos (DBMS JSON CRUD) */}
              <div className="bg-white border border-slate-300 rounded p-4 shadow-xs space-y-4">
                <div className="border-b border-slate-100 pb-2">
                  <h3 className="text-xs font-black text-slate-900 uppercase tracking-wider flex items-center gap-1.5 font-sans">
                    <Code className="w-4 h-4 text-emerald-700 font-sans" />
                    <span>Explorador de Registros Primitivos (Direct JSON DBMS)</span>
                  </h3>
                  <p className="text-[10px] text-slate-500">Inspecione ou modifique registros crus de documentos diretamente utilizando a notação primitiva JSON.</p>
                </div>

                <div className="space-y-3.5">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-700 uppercase mb-1 font-sans">Selecionar Ofício / Documento para Leitura Direta</label>
                    <select
                      value={selectedDocIdForRawExplorer}
                      onChange={(e) => setSelectedDocIdForRawExplorer(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded p-2 text-xs font-bold text-slate-805 focus:outline-none focus:bg-white"
                    >
                      <option value="">-- Selecione um registro no banco --</option>
                      {documents.map((d) => (
                        <option key={`raw-explorer-opt-${d.id}`} value={d.id}>
                          [{d.protocol}] {d.title.substring(0, 48)}... ({(d.municipality || 'Cutias').toUpperCase()})
                        </option>
                      ))}
                    </select>
                  </div>

                  {selectedDocIdForRawExplorer ? (
                    <form onSubmit={handleSaveRawJson} className="space-y-3 animate-fade-in">
                      <div className="relative">
                        <textarea
                          rows={7}
                          value={rawJsonText}
                          onChange={(e) => setRawJsonText(e.target.value)}
                          className="w-full p-2.5 bg-slate-900 border border-slate-800 text-emerald-400 font-mono text-[11px] leading-relaxed rounded focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-500"
                        />
                        <span className="absolute bottom-2.5 right-2 px-1 text-[8px] font-bold bg-slate-800 text-emerald-500 rounded border border-slate-750 uppercase tracking-widest font-mono select-none">DBMS JSON EDITOR</span>
                      </div>

                      {jsonError && (
                        <p className="text-[10px] text-red-650 font-bold bg-red-50 p-2 border border-red-200 rounded">⚠️ {jsonError}</p>
                      )}

                      <div className="flex items-center justify-between">
                        <span className="text-[9px] text-slate-400 font-semibold uppercase tracking-wider font-sans">Cuidado ao salvar campos obrigatórios!</span>
                        <div className="flex gap-2">
                          <button
                            type="button"
                            onClick={() => {
                              setSelectedDocIdForRawExplorer('');
                              setRawJsonText('');
                            }}
                            className="text-[10px] font-bold uppercase text-slate-550 bg-slate-100 hover:bg-slate-200 py-1 px-3 rounded cursor-pointer transition-colors font-sans"
                          >
                            Limpar
                          </button>
                          <button
                            type="submit"
                            className="bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-black uppercase tracking-wider py-1 px-4 rounded shadow-2xs cursor-pointer flex items-center gap-1 transition-colors font-sans"
                          >
                            <Check className="w-3.5 h-3.5 font-bold" />
                            <span>Gravar JSON alterado</span>
                          </button>
                        </div>
                      </div>
                    </form>
                  ) : (
                    <div className="p-6 text-center border border-dashed border-slate-250 text-slate-400 text-xs rounded">
                      Selecione um documento acima para decodificar e ler seu payload.
                    </div>
                  )}

                </div>
              </div>

            </div>

          </div>

        </div>
      )}

    </div>
  );
}
