/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  LayoutDashboard, 
  PlusCircle, 
  FileText, 
  Building, 
  UserCheck, 
  Calendar, 
  ShieldAlert,
  MapPin,
  Clock,
  PenTool
} from 'lucide-react';
import { TODAY_DATE, formatDate } from '../utils';
import { AppUser } from '../types';

interface SidebarProps {
  currentTab: 'dashboard' | 'enviar' | 'documentos' | 'master' | 'assinatura';
  setCurrentTab: (tab: 'dashboard' | 'enviar' | 'documentos' | 'master' | 'assinatura') => void;
  currentUser: AppUser;
  onlyMyDepartment: boolean;
  setOnlyMyDepartment: (val: boolean) => void;
  onLogout: () => void;
  selectedDept: string;
  setSelectedDept: (dept: string) => void;
  allDepts: { acronym: string; name: string }[];
  currentMunicipality?: string;
}

export default function Sidebar({
  currentTab,
  setCurrentTab,
  currentUser,
  onlyMyDepartment,
  setOnlyMyDepartment,
  onLogout,
  selectedDept,
  setSelectedDept,
  allDepts,
  currentMunicipality = 'Cutias'
}: SidebarProps) {
  return (
    <aside className="w-72 bg-white text-slate-800 flex flex-col justify-between border-r border-slate-300 h-screen sticky top-0 hidden md:flex shrink-0 font-sans">
      {/* Branding & Entity Header */}
      <div>
        <div className="p-5 border-b border-slate-200 bg-[#003366] text-white">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-white rounded flex items-center justify-center p-1 text-[#003366] shrink-0 shadow-xs">
              <Building className="w-5 h-5" />
            </div>
            <div>
              <h1 className="font-sans font-extrabold text-base leading-tight">DOC {currentMunicipality}</h1>
              <p className="text-[10px] uppercase font-bold tracking-wider text-blue-200">Prefeitura de {currentMunicipality}</p>
            </div>
          </div>
          
          {/* Location Badge */}
          <div className="mt-4 pt-3 border-t border-blue-800/60 space-y-1">
            <div className="flex items-center gap-1.5 text-blue-100 text-[11px]">
              <MapPin className="w-3.5 h-3.5 text-blue-300" />
              <span>Sede • {currentMunicipality}</span>
            </div>
            <div className="flex items-center gap-1.5 text-blue-100 text-[11px]">
              <Clock className="w-3.5 h-3.5 text-blue-300" />
              <span>Data Base: {formatDate(TODAY_DATE)}</span>
            </div>
          </div>
        </div>

        {/* Navigation Categories */}
        <nav className="p-3 space-y-1">
          <p className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-widest text-slate-400">Principal</p>
          
          <button
            id="nav-dashboard-btn"
            onClick={() => setCurrentTab('dashboard')}
            className={`w-full flex items-center gap-2.5 px-3 py-2 rounded text-xs font-semibold transition-all ${
              currentTab === 'dashboard'
                ? 'bg-blue-50 text-[#003366] border-r-4 border-[#003366]'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <LayoutDashboard className="w-4 h-4 shrink-0 text-slate-500" />
            <span>Dashboard Geral</span>
          </button>

          <button
            id="nav-documentos-btn"
            onClick={() => setCurrentTab('documentos')}
            className={`w-full flex items-center gap-2.5 px-3 py-2 rounded text-xs font-semibold transition-all ${
              currentTab === 'documentos'
                ? 'bg-blue-50 text-[#003366] border-r-4 border-[#003366]'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <FileText className="w-4 h-4 shrink-0 text-slate-500" />
            <span>Documentos Enviados</span>
          </button>

          <p className="px-3 pt-3 py-1.5 text-[10px] font-bold uppercase tracking-widest text-slate-400">Trâmite Interno</p>

          <button
            id="nav-enviar-btn"
            onClick={() => setCurrentTab('enviar')}
            className={`w-full flex items-center gap-2.5 px-3 py-2 rounded text-xs font-semibold transition-all ${
              currentTab === 'enviar'
                ? 'bg-blue-50 text-[#003366] border-r-4 border-[#003366]'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <PlusCircle className="w-4 h-4 shrink-0 text-slate-500" />
            <span>Novo Envio</span>
          </button>

          <button
            id="nav-assinatura-btn"
            onClick={() => setCurrentTab('assinatura')}
            className={`w-full flex items-center gap-2.5 px-3 py-2 rounded text-xs font-semibold transition-all ${
              currentTab === 'assinatura'
                ? 'bg-blue-50 text-[#003366] border-r-4 border-[#003366]'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <PenTool className="w-4 h-4 shrink-0 text-slate-500 text-emerald-650" />
            <span>Assinar Documentos</span>
          </button>

          {currentUser.role === 'master' && (
            <>
              <p className="px-3 pt-3 py-1.5 text-[10px] font-bold uppercase tracking-widest text-amber-600 flex items-center gap-1">
                <ShieldAlert className="w-3.5 h-3.5" />
                <span>Auditoria & TI</span>
              </p>
              <button
                id="nav-master-btn"
                onClick={() => setCurrentTab('master')}
                className={`w-full flex items-center gap-2.5 px-3 py-2 rounded text-xs font-semibold transition-all ${
                  currentTab === 'master'
                    ? 'bg-amber-50 text-amber-800 border-r-4 border-amber-600'
                    : 'text-slate-650 hover:bg-amber-50/40 hover:text-amber-900'
                }`}
              >
                <ShieldAlert className="w-4 h-4 shrink-0 text-amber-600" />
                <span>Console Master</span>
              </button>
            </>
          )}
        </nav>
      </div>

      {/* Logged User & Security Context */}
      <div className="p-3.5 border-t border-slate-200 bg-slate-50 space-y-3">
        
        {/* Active Profile Info */}
        <div className="p-2.5 bg-white border border-slate-200 rounded shadow-xs">
          <span className="text-[9px] font-extrabold uppercase text-slate-400 block tracking-widest mb-1.5">Agente Logado</span>
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded bg-blue-100 text-[#003366] font-extrabold text-[10px] flex items-center justify-center shrink-0">
              {currentUser.role === 'gestor' ? 'G' : 'S'}
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-xs font-bold text-slate-900 truncate">{currentUser.name}</p>
              <p className="text-[9px] text-[#003366] font-bold truncate">
                {currentUser.role === 'gestor' ? 'Gestor' : 'Servidor'} • {currentUser.department.split('(')[1]?.replace(')', '') || currentUser.department}
              </p>
            </div>
          </div>
        </div>

        {/* Non-Interference Multi-User Filter */}
        <div className="space-y-1">
          <label className="block text-[9px] font-extrabold uppercase tracking-wider text-slate-500">
            Ficha de Segurança (Sigilo)
          </label>
          <div className="grid grid-cols-2 p-1 bg-white rounded border border-slate-200">
            <button
              id="filter-only-mine-btn"
              onClick={() => {
                setOnlyMyDepartment(true);
                setSelectedDept('all');
              }}
              className={`py-1 text-[9px] font-bold rounded transition-all leading-tight ${
                onlyMyDepartment
                  ? 'bg-[#003366] text-white shadow-xs'
                  : 'text-slate-500 hover:text-slate-850'
              }`}
              title="Exibe apenas processos que envolvem o seu setor de atuação (Sem interferência externa)"
            >
              🔒 Meu Setor
            </button>
            <button
              id="filter-all-dept-btn"
              onClick={() => {
                setOnlyMyDepartment(false);
              }}
              className={`py-1 text-[9px] font-bold rounded transition-all leading-tight ${
                !onlyMyDepartment
                  ? 'bg-blue-100 text-[#003366] border border-blue-200 shadow-xs'
                  : 'text-slate-500 hover:text-slate-850'
              }`}
              title={`Visualiza o repositório geral público das secretarias de ${currentMunicipality}-AP`}
            >
              🌐 Ver Todos
            </button>
          </div>
        </div>

        {/* Administrative Department filter for broader view */}
        {!onlyMyDepartment && (
          <div className="p-2 bg-blue-50/50 rounded border border-blue-105">
            <p className="text-[9px] font-bold text-blue-800 uppercase tracking-widest">Painel Administrativo</p>
            <p className="text-[10px] text-slate-500 mt-0.5">Filtrar por Departamento:</p>
            <select
              id="dept-select"
              value={selectedDept}
              onChange={(e) => setSelectedDept(e.target.value)}
              className="mt-1 w-full bg-white border border-slate-300 text-slate-700 text-[11px] rounded px-1.5 py-0.5 focus:outline-none"
            >
              <option value="all">🏢 Todos os Setores</option>
              {allDepts.map((d) => (
                <option key={d.acronym} value={d.name}>
                  🏢 {d.acronym}
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Global Exit button */}
        <button
          id="btn-sidebar-logout"
          onClick={onLogout}
          className="w-full bg-slate-200 hover:bg-red-50 hover:text-red-700 border border-slate-300 text-slate-600 font-bold py-1 px-2 rounded text-[10px] uppercase transition-all shrink-0 cursor-pointer flex items-center justify-center gap-1"
        >
          🔐 Sair da Sessão
        </button>
        
        {/* Footnotes */}
        <div className="bg-slate-100 p-2.5 rounded text-[10px] text-slate-500 text-center space-y-0.5">
          <p className="font-semibold">Sistema v3.2.0-stable</p>
          <p>Servidor Oficial: AP-CUT-01</p>
        </div>
      </div>
    </aside>
  );
}
