/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Document } from './types';

export const INITIAL_DOCUMENTS: Document[] = [
  {
    id: 'doc-1',
    protocol: 'PMC-2026-0412',
    title: 'Solicitação de Remanejamento Orçamentário para Medicamentos',
    type: 'Ofício',
    origin: 'Secretaria Municipal de Saúde (SEMUSA)',
    destination: 'Secretaria Municipal de Finanças (SEMOF)',
    description: 'Solicito em caráter de urgência a verificação da disponibilidade orçamentária e financeira para o remanejamento no valor de R$ 45.000,00 destinados à compra emergencial de insumos farmacêuticos e vacinas para a Unidade de Saúde de Cutias.',
    createdAt: '2026-05-10T09:30:00Z',
    deadlineDate: '2026-05-20',
    priority: 'Urgente',
    status: 'Atrasado',
    attachment: {
      name: 'oficio_45_2026_remanejamento_medicamentos.pdf',
      type: 'application/pdf',
      size: 154200,
      data: 'JVBERi0xLjQKJ...[CONTEÚDO SIMULADO EM BASE64 - SOLICITAÇÃO DE MEDICAMENTOS SEMUSA]'
    },
    history: [
      {
        id: 'h-1-1',
        date: '2026-05-10T09:30:00Z',
        user: 'Ana Cristina Souza (Secretária SEMUSA)',
        action: 'Documento Criado e Enviado',
        notes: 'Protocolado pelo portal interno de envio DOC.'
      },
      {
        id: 'h-1-2',
        date: '2026-05-11T14:15:00Z',
        user: 'Paulo Roberto Dias (Triagem SEMOF)',
        action: 'Documento Recebido',
        notes: 'Encaminhado para o setor de análise de orçamentos fiscais.'
      }
    ]
  },
  {
    id: 'doc-2',
    protocol: 'PMC-2026-0418',
    title: 'Contratação Temporária de Professores Substitutos - Edital 02/2026',
    type: 'Comunicação Interna',
    origin: 'Secretaria Municipal de Educação (SEMED)',
    destination: 'Secretaria Municipal de Administração e Planejamento (SEMAP)',
    description: 'Encaminho a requisição formal para abertura de contratação de 5 (cinco) profissionais de docência (ensino fundamental I) para atuar nas escolas polos rurais do município de Cutias de forma temporária, visando atender à demanda decorrente de licenças médicas regulamentares.',
    createdAt: '2026-05-24T11:45:00Z',
    deadlineDate: '2026-05-29',
    priority: 'Alta',
    status: 'Em Análise',
    attachment: {
      name: 'solicitacao_semed_professores_substitutos.docx',
      type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      size: 92450,
      data: 'UEsDBBQABgAIA...[CONTEÚDO SIMULADO EM BASE64 - MEMORANDO DE EDUCAÇÃO SEMED]'
    },
    history: [
      {
        id: 'h-2-1',
        date: '2026-05-24T11:45:00Z',
        user: 'Profr. Carlos Magno (Secretário SEMED)',
        action: 'Documento Criado e Enviado',
        notes: 'Encaminhado com caráter prioritário devido ao início do bimestre escolar.'
      },
      {
        id: 'h-2-2',
        date: '2026-05-25T10:00:00Z',
        user: 'Juliana Barbosa (Diretora de RH - SEMAP)',
        action: 'Início da Análise',
        notes: 'Documento alocado em fila de verificação de vagas preestabelecidas.'
      }
    ]
  },
  {
    id: 'doc-3',
    protocol: 'PMC-2026-0395',
    title: 'Portaria de Nomeação dos Membros do Conselho de Alimentação Escolar',
    type: 'Portaria',
    origin: 'Gabinete do Prefeito (GAB)',
    destination: 'Secretaria Municipal de Educação (SEMED)',
    description: 'Dispõe sobre a nomeação dos conselheiros titulares e suplentes para o biênio 2026-2028 no Conselho Municipal de Alimentação Escolar (CAE) de Cutias - AP, na forma regulamentar da Lei Federal nº 11.947.',
    createdAt: '2026-05-15T08:00:00Z',
    deadlineDate: '2026-05-25',
    priority: 'Média',
    status: 'Concluído',
    attachment: {
      name: 'portaria_102_2026_conselho_cae.pdf',
      type: 'application/pdf',
      size: 198000,
      data: 'JVBERi0xLjQKJ...[CONTEÚDO SIMULADO EM BASE64 - PORTARIA DE NOMEAÇÃO PREFEITO]'
    },
    history: [
      {
        id: 'h-3-1',
        date: '2026-05-15T08:00:00Z',
        user: 'Prefeito Municipal (GAB)',
        action: 'Documento Publicado e Enviado',
        notes: 'Enviado para cumprimento e guarda na SEMED.'
      },
      {
        id: 'h-3-2',
        date: '2026-05-22T16:40:00Z',
        user: 'Marta Helena Santos (Apoio Pedagógico SEMED)',
        action: 'Documento Respondido',
        notes: 'Membros homologados e portaria registrada no livro de atas municipal.'
      }
    ],
    response: {
      responder: 'Marta Helena Santos (Apoio Pedagógico SEMED)',
      text: 'Informamos que procedemos ao arquivamento, publicação institucional e devida convocação dos novos conselheiros para a sessão solene de posse marcada no dia 02 de Junho de 2026. Agradecemos a agilidade legislativa.',
      createdAt: '2026-05-22T16:40:00Z'
    }
  },
  {
    id: 'doc-4',
    protocol: 'PMC-2026-0422',
    title: 'Parecer Jurídico sobre a Reforma da Orla do Rio Cutias',
    type: 'Requerimento',
    origin: 'Procuradoria Geral do Município (PGM)',
    destination: 'Secretaria Municipal de Obras e Serviços Públicos (SEMOSP)',
    description: 'Apresentação de parecer circunstanciado referindo-se aos aspectos da licitação nº 004/2026 para início da reforma e requalificação paisagística da orla municipal. Autorização legal atestada com base na lei de licitações.',
    createdAt: '2026-05-25T14:20:00Z',
    deadlineDate: '2026-06-08',
    priority: 'Média',
    status: 'Pendente',
    attachment: {
      name: 'parecer_juridico_04_licitacao_orla.pdf',
      type: 'application/pdf',
      size: 320100,
      data: 'JVBERi0xLjQKJ...[CONTEÚDO SIMULADO EM BASE64 - PARECER LICITATÓRIO LAUDO PGM]'
    },
    history: [
      {
        id: 'h-4-1',
        date: '2026-05-25T14:20:00Z',
        user: 'Dr. Fernando Mello (Procurador Geral)',
        action: 'Parecer Emitido e Enviado',
        notes: 'Documentação remetida para a comissão licitatória da SEMOSP.'
      }
    ]
  }
];
