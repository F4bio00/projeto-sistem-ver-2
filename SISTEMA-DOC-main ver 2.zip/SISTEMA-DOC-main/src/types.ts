/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type DocumentType = 'Memorando' | 'Ofício' | 'Requerimento' | 'Portaria' | 'Circular' | 'Comunicação Interna';

export type PriorityType = 'Baixa' | 'Média' | 'Alta' | 'Urgente';

export type DocumentStatus = 'Pendente' | 'Em Análise' | 'Atrasado' | 'Concluído';

export interface HistoryItem {
  id: string;
  date: string;
  user: string;
  action: string;
  notes?: string;
}

export interface DocumentResponse {
  responder: string;
  text: string;
  createdAt: string;
  attachmentName?: string;
  attachmentData?: string;
}

export interface Attachment {
  name: string;
  type: string;
  size: number;
  data: string; // Base64 content of the file
}

export interface DigitalSignature {
  id: string;
  userName: string;
  userRole: string;
  userDepartment: string;
  signedAt: string;
  ipAddress?: string;
  certificateAuthority?: string;
  hash: string;
}

export interface Document {
  id: string;
  protocol: string;
  title: string;
  type: DocumentType;
  origin: string;
  destination: string;
  description: string;
  createdAt: string;
  deadlineDate: string;
  priority: PriorityType;
  status: DocumentStatus;
  attachment?: Attachment;
  history: HistoryItem[];
  response?: DocumentResponse;
  signatures?: DigitalSignature[];
  municipality?: string;
}

export interface Department {
  id: string;
  name: string;
  acronym: string;
  color: string;
}

export interface AppUser {
  id: string;
  name: string;
  username: string;
  role: 'gestor' | 'servidor' | 'master';
  department: string; // The selected department's name (e.g. "Secretaria Municipal de Saúde (SEMUSA)")
  password?: string;
  municipality?: string;
}

export const DEPARTMENTS: Department[] = [
  { id: '1', name: 'Gabinete do Prefeito', acronym: 'GAB', color: 'border-l-4 border-emerald-600' },
  { id: '2', name: 'Secretaria Municipal de Administração e Planejamento', acronym: 'SEMAP', color: 'border-l-4 border-blue-600' },
  { id: '3', name: 'Secretaria Municipal de Finanças', acronym: 'SEMOF', color: 'border-l-4 border-amber-600' },
  { id: '4', name: 'Secretaria Municipal de Educação', acronym: 'SEMED', color: 'border-l-4 border-indigo-600' },
  { id: '5', name: 'Secretaria Municipal de Saúde', acronym: 'SEMUSA', color: 'border-l-4 border-red-600' },
  { id: '6', name: 'Secretaria Municipal de Assistência Social', acronym: 'SEMAS', color: 'border-l-4 border-purple-600' },
  { id: '7', name: 'Secretaria Municipal de Obras e Serviços Públicos', acronym: 'SEMOSP', color: 'border-l-4 border-gray-600' },
  { id: '8', name: 'Secretaria Municipal de Agricultura, Pesca e Meio Ambiente', acronym: 'SEMAPA', color: 'border-l-4 border-teal-600' },
  { id: '9', name: 'Procuradoria Geral do Município', acronym: 'PGM', color: 'border-l-4 border-cyan-700' },
  { id: '10', name: 'Controladoria Geral do Município', acronym: 'CGM', color: 'border-l-4 border-orange-600' },
  { id: '11', name: 'Secretaria Municipal de Governo', acronym: 'SEMGOV', color: 'border-l-4 border-pink-605' }
];
