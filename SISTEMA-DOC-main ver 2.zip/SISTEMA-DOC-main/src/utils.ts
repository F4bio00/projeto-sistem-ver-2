/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Document, DocumentStatus } from './types';

/**
 * Baseline date for "Today" inside the application
 * Set to 2026-05-26 as provided in the metadata
 */
export const TODAY_DATE = '2026-05-26';

/**
 * Formats an ISO string or Date into Portuguese date representation
 */
export function formatDate(dateString: string, includeTime = false): string {
  try {
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return dateString;
    
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    
    if (includeTime) {
      const hours = String(date.getHours()).padStart(2, '0');
      const minutes = String(date.getMinutes()).padStart(2, '0');
      return `${day}/${month}/${year} às ${hours}:${minutes}`;
    }
    
    return `${day}/${month}/${year}`;
  } catch {
    return dateString;
  }
}

/**
 * Generates an unique DOC-style protocol
 * Format: PMC-YYYY-XXXX where XXXX is sequential or random hex
 */
export function generateProtocol(): string {
  const year = new Date(TODAY_DATE).getFullYear();
  const randNum = Math.floor(1000 + Math.random() * 9000); // 4 digits
  return `PMC-${year}-${randNum}`;
}

/**
 * Calculates remaining days from Today to the document deadline
 */
export function getRemainingDays(deadlineString: string): {
  days: number;
  label: string;
  badgeColor: string;
} {
  const today = new Date(TODAY_DATE);
  today.setHours(0, 0, 0, 0);
  
  const deadline = new Date(deadlineString);
  deadline.setHours(0, 0, 0, 0);
  
  const diffTime = deadline.getTime() - today.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  if (diffDays < 0) {
    return {
      days: diffDays,
      label: `Atrasado há ${Math.abs(diffDays)} dia(s)`,
      badgeColor: 'bg-red-50 text-red-700 border-red-200'
    };
  } else if (diffDays === 0) {
    return {
      days: 0,
      label: 'Vence Hoje!',
      badgeColor: 'bg-amber-50 text-amber-800 border-amber-300 animate-pulse'
    };
  } else if (diffDays <= 2) {
    return {
      days: diffDays,
      label: `Vence em ${diffDays} dia(s) (Urgente)`,
      badgeColor: 'bg-orange-50 text-orange-700 border-orange-200'
    };
  } else {
    return {
      days: diffDays,
      label: `${diffDays} dia(s) restante(s)`,
      badgeColor: 'bg-emerald-50 text-emerald-700 border-emerald-200'
    };
  }
}

/**
 * Calculates correct document status considering if it is overdue
 */
export function getLiveStatus(doc: Document): DocumentStatus {
  if (doc.status === 'Concluído') return 'Concluído';
  
  const today = new Date(TODAY_DATE);
  today.setHours(0, 0, 0, 0);
  
  const deadline = new Date(doc.deadlineDate);
  deadline.setHours(0, 0, 0, 0);
  
  if (today.getTime() > deadline.getTime()) {
    return 'Atrasado';
  }
  
  return doc.status;
}

/**
 * Triggers document download in client-side using Blob
 * Supports downloading genuine uploaded documents or templated text downloads
 */
export function downloadFile(fileName: string, data: string, fileType = 'text/plain') {
  try {
    let blob: Blob;
    
    if (data.includes('JVBERi0') || data.includes('UEsDBB')) {
      // Simulates loading simulated base64 or standard raw files
      const byteCharacters = atob(data.split(',')[1] || data.substr(0, 30) === 'JVBER' ? data : 'U2ltdWxhZG8=');
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      blob = new Blob([byteArray], { type: fileType });
    } else {
      // Create a nice human-readable text document representing the content
      blob = new Blob([data], { type: 'text/plain;charset=utf-8' });
    }
    
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  } catch (err) {
    console.error('Download failed', err);
  }
}
